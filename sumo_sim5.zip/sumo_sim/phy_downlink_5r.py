"""
phy_downlink_5r.py -- 5-Robot Task-Aware Downlink PHY Pipeline (Heuristic)
===========================================================================
Generalises phy_downlink_ms.py from 2 robots to 5 robots while keeping
every PHY parameter identical so that per-robot metrics are directly
comparable between the two cases.

Key differences from phy_downlink_ms.py
-----------------------------------------
  TOTAL_RBS = 17   (was 7)
    Average per robot = 17/5 = 3.4 RBs  (vs 7/2 = 3.5 in 2-robot case)
    Per-robot cap     = 5 RBs (60 SCs < N_FFT-1 = 63 -- same physical limit)

    n_sym table (160-bit payload) is identical since it only depends on rb_i:
      5 RBs QPSK -> 2 sym   4 RBs QPSK -> 2 sym
      3 RBs QPSK -> 3 sym   2 RBs QPSK -> 4 sym   1 RB QPSK -> 7 sym
      16-QAM / 64-QAM latency differentiation: same thresholds as 2-robot.

  C(5,2) = 10 collision pairs evaluated every step.
    Per-robot pc = max over all 4 pairs involving that robot.
    max_pc_global = max over all 10 pairs (used for allocation).

  RB allocation (heuristic baseline):
    score_i  = priority_i * (1 + HEURISTIC_ALPHA * pc_i)
    Integer split via largest-remainder method; each robot in [1, 5] RBs.
    HEURISTIC_ALPHA = 1.0  (fixed; RL version learns this per-state).

  Deadlock resolver:
    If >= 3 robots simultaneously receive CMD_STOP, the two lowest-priority
    stopped robots stay stopped; the rest are upgraded to CMD_SLOW.

All CRC, modulation, OFDM, and channel functions are imported unchanged
from phy_downlink_ms so the bit-level pipeline is bit-for-bit identical.

Fallback: set USE_5ROBOTS = False in run_sim.py to revert to the 2-robot
pipeline (phy_downlink_ms / phy_downlink_ms_rl) -- nothing here changes.
"""

import math
import itertools
import numpy as np

# ---- Import shared low-level functions from the 2-robot pipeline -----------
from phy_downlink_ms import (
    # CRC
    _crc8, _crc8_check,
    # Modulation / demodulation
    _bits_to_qam_symbols, _qam_symbols_to_bits,
    # OFDM framing
    _subcarrier_indices, _ofdm_modulate, _ofdm_demodulate,
    # Helpers exported to run_sim.py
    speed_angle_to_velocity, apply_actuation,
    # Shared PHY constants (all identical -- do NOT redefine)
    PAD_BITS, PAYLOAD_BITS,
    N_FFT, CP_LEN, FRAME_LEN, SCS_HZ, T_SYM_US,
    TX_POWER_W,
    TAU_LOOKAHEAD_S, D_DANGER_M, EMA_ALPHA,
    P_C_QPSK_THRESH, P_C_16QAM_THRESH, SNR_64QAM_MIN_DB, SNR_QPSK_MAX_DB,
    MCS_QPSK, MCS_16QAM, MCS_64QAM, MCS_NAMES,
    P_STOP, P_SLOW, CMD_CONTINUE, CMD_SLOW, CMD_STOP, CMD_BITS,
    HYSTERESIS_COUNT, MAX_STOP_STEPS,
    SPEED_MAX, SPEED_SLOW, SPEED_STOP,
    CRC_POLY, CRC_BITS,
)
from channel_model import apply_channel, estimate_snr_db


# ============================================================================
#  5-ROBOT SPECIFIC CONSTANTS
# ============================================================================

ROBOT_IDS   = ["robot_0", "robot_1", "robot_2", "robot_3", "robot_4"]
ROBOT_PAIRS = list(itertools.combinations(ROBOT_IDS, 2))   # 10 pairs

# RB pool -- scaled to keep average per-robot allocation equal to 2-robot case
TOTAL_RBS          = 17
MAX_RB_PER_ROBOT   = 5     # 60 SCs < N_FFT-1 = 63 (same physical cap as 2-robot)
MIN_RB_PER_ROBOT   = 1

# Fixed collision-weight for the heuristic baseline (RL version learns this)
HEURISTIC_ALPHA    = 1.0

# Threshold above which a pair counts as "high risk" (same as 2-robot boost)
HIGH_RISK_THRESHOLD = 0.5

# Maximum achievable spectral efficiency across all 5 robots (for reward norm)
# 6 bps/SC * 5 RBs_max * 12 SC/RB * 5 robots
SE_MAX_5R = 6 * MAX_RB_PER_ROBOT * 12 * len(ROBOT_IDS)    # 1800


# ============================================================================
#  ALLOCATION HELPER  -- largest-remainder integer split
# ============================================================================

def _largest_remainder_alloc(scores: dict, total: int,
                              lo: int = MIN_RB_PER_ROBOT,
                              hi: int = MAX_RB_PER_ROBOT) -> dict:
    """
    Distribute `total` indivisible units among robots proportional to `scores`.

    Uses the Largest Remainder Method with per-robot bounds [lo, hi].

    Parameters
    ----------
    scores : {rid: float}   -- raw (possibly fractional) weight per robot
    total  : int            -- total units to distribute  (= TOTAL_RBS)
    lo, hi : int            -- per-robot bounds

    Returns
    -------
    alloc  : {rid: int}     -- guaranteed sum == total, all in [lo, hi]
    """
    rids        = list(scores.keys())
    total_score = sum(scores.values())

    if total_score <= 0:
        # Degenerate: equal split
        base      = total // len(rids)
        remainder = total - base * len(rids)
        alloc     = {r: base for r in rids}
        for r in rids[:remainder]:
            alloc[r] += 1
        return alloc

    # 1. Real-valued proportional targets
    real = {r: scores[r] / total_score * total for r in rids}

    # 2. Floor and clamp to [lo, hi]
    alloc = {r: max(lo, min(hi, math.floor(real[r]))) for r in rids}
    deficit = total - sum(alloc.values())

    # 3. Resolve deficit by largest fractional remainder (respecting cap)
    fracs = sorted(
        [(real[r] - math.floor(real[r]), r) for r in rids],
        reverse=(deficit > 0)
    )
    for _, r in fracs:
        if deficit == 0:
            break
        if deficit > 0 and alloc[r] < hi:
            alloc[r] += 1
            deficit  -= 1
        elif deficit < 0 and alloc[r] > lo:
            alloc[r] -= 1
            deficit  += 1

    return alloc


# ============================================================================
#  DownlinkPHY  -- 5-robot heuristic version
# ============================================================================

class DownlinkPHY:
    """
    Stateful downlink PHY controller for the 5-robot factory simulation.

    step() signature is identical to phy_downlink_ms.DownlinkPHY.step() --
    only the keys in the returned dict differ (indexed 0..4 instead of 0..1).
    """

    def __init__(self):
        # Per-pair EMA-smoothed collision probability (10 pairs)
        self._pc_smooth_pairs = {pair: 0.0 for pair in ROBOT_PAIRS}

        # Per-robot hysteresis and stop counters (same logic as 2-robot)
        self._hyst_cnt = {rid: 0 for rid in ROBOT_IDS}
        self._stop_ctr = {rid: 0 for rid in ROBOT_IDS}

        # SC-index cache (keyed by n_rbs; same as 2-robot)
        self._sc_cache = {}

    # ------------------------------------------------------------------
    # Subcarrier index cache
    # ------------------------------------------------------------------

    def _get_sc_indices(self, n_rbs: int) -> np.ndarray:
        if n_rbs not in self._sc_cache:
            self._sc_cache[n_rbs] = _subcarrier_indices(n_rbs)
        return self._sc_cache[n_rbs]

    # ------------------------------------------------------------------
    # Stage 2 -- Collision probability (10 pairs)
    # ------------------------------------------------------------------

    def _collision_probability_all_pairs(
            self, positions: dict, velocities: dict) -> tuple:
        """
        Compute TTC-based raw collision probability for every pair, update
        the per-pair EMA, and derive per-robot pc as the max over all pairs
        involving that robot.

        Returns
        -------
        pc_raw_max      : float -- max raw pc across all 10 pairs this step
        pc_smooth_pairs : dict  -- {(rid_a, rid_b): smoothed_pc}
        per_robot_pc    : dict  -- {rid: max smoothed_pc over robot's pairs}
        """
        pc_smooth_pairs = {}
        pc_raw_max = 0.0

        for pair in ROBOT_PAIRS:
            rid_a, rid_b = pair
            xa, ya   = positions[rid_a]
            xb, yb   = positions[rid_b]
            vxa, vya = velocities[rid_a]
            vxb, vyb = velocities[rid_b]

            # Predict positions TAU_LOOKAHEAD_S seconds ahead
            tau  = TAU_LOOKAHEAD_S
            fxa  = xa + vxa * tau;  fya = ya + vya * tau
            fxb  = xb + vxb * tau;  fyb = yb + vyb * tau
            d_pred = math.sqrt((fxa - fxb) ** 2 + (fya - fyb) ** 2)

            pc_raw     = max(0.0, min(1.0 - d_pred / D_DANGER_M, 1.0))
            pc_raw_max = max(pc_raw_max, pc_raw)

            # EMA update
            self._pc_smooth_pairs[pair] = (
                EMA_ALPHA * pc_raw
                + (1.0 - EMA_ALPHA) * self._pc_smooth_pairs[pair]
            )
            pc_smooth_pairs[pair] = self._pc_smooth_pairs[pair]

        # Per-robot: max smoothed pc over all 4 pairs involving that robot
        per_robot_pc = {}
        for rid in ROBOT_IDS:
            pairs_of = [p for p in ROBOT_PAIRS if rid in p]
            per_robot_pc[rid] = max(pc_smooth_pairs[p] for p in pairs_of)

        return pc_raw_max, pc_smooth_pairs, per_robot_pc

    # ------------------------------------------------------------------
    # Stage 3a -- RB allocation (heuristic)
    # ------------------------------------------------------------------

    @staticmethod
    def _allocate_rbs(priorities: dict, per_robot_pc: dict,
                      alpha: float = HEURISTIC_ALPHA) -> dict:
        """
        Largest-remainder proportional RB split.

        score_i = priority_i * (1 + alpha * pc_i)
        Each robot gets an integer number of RBs in [1, MAX_RB_PER_ROBOT],
        summing to TOTAL_RBS.
        """
        scores = {
            rid: priorities[rid] * (1.0 + alpha * per_robot_pc[rid])
            for rid in ROBOT_IDS
        }
        return _largest_remainder_alloc(scores, TOTAL_RBS)

    # ------------------------------------------------------------------
    # Stage 3b -- MCS selection  (identical to 2-robot)
    # ------------------------------------------------------------------

    @staticmethod
    def _select_mcs(pc_smooth: float, snr_db: float) -> int:
        if pc_smooth > P_C_QPSK_THRESH or snr_db < SNR_QPSK_MAX_DB:
            return MCS_QPSK
        if pc_smooth > P_C_16QAM_THRESH:
            return MCS_16QAM
        if snr_db >= SNR_64QAM_MIN_DB:
            return MCS_64QAM
        return MCS_16QAM

    # ------------------------------------------------------------------
    # Stage 4 -- Command selection  (identical to 2-robot)
    # ------------------------------------------------------------------

    @staticmethod
    def _select_command(pc_smooth: float) -> str:
        if pc_smooth >= P_STOP:
            return CMD_STOP
        if pc_smooth >= P_SLOW:
            return CMD_SLOW
        return CMD_CONTINUE

    @staticmethod
    def _resolve_deadlock(commands: dict, priorities: dict) -> dict:
        """
        Prevent gridlock when too many robots stop simultaneously.

        If >= 3 robots have CMD_STOP: keep the 2 lowest-priority robots
        stopped (they yield right-of-way), upgrade the rest to CMD_SLOW.
        """
        stop_rids = [rid for rid, cmd in commands.items() if cmd == CMD_STOP]
        if len(stop_rids) <= 2:
            return commands
        # Sort ascending by priority (lowest first = they stay stopped)
        stop_rids.sort(key=lambda r: priorities[r])
        result = dict(commands)
        for rid in stop_rids[2:]:   # 3rd and beyond get upgraded
            result[rid] = CMD_SLOW
        return result

    # ------------------------------------------------------------------
    # Stage 5 -- Multi-symbol downlink chain  (identical to 2-robot)
    # ------------------------------------------------------------------

    def _downlink_chain(self, command: str, mcs: int,
                        n_rbs: int, x: float, y: float):
        """
        Multi-symbol OFDM downlink chain for one robot.

        Payload = 2-bit cmd + 8-bit CRC + 150 zero pad = 160 bits total.
        QAM symbol counts: QPSK->80, 16QAM->40, 64QAM->27.
        n_sym = ceil(n_qam / (n_rbs * 12)).

        Returns
        -------
        decoded_cmd : str or None
        crc_pass    : bool
        avg_snr_db  : float
        n_sym       : int
        latency_us  : float
        h_first     : complex
        """
        cmd_bits  = CMD_BITS[command]
        crc_bits  = _crc8(cmd_bits)
        payload   = cmd_bits + crc_bits + [0] * PAD_BITS   # 160 bits

        qam_symbols = _bits_to_qam_symbols(payload, mcs)
        n_qam       = len(qam_symbols)

        sc_indices = self._get_sc_indices(n_rbs)
        n_sc       = len(sc_indices)
        n_sym      = math.ceil(n_qam / n_sc)

        qam_padded          = np.zeros(n_sym * n_sc, dtype=complex)
        qam_padded[:n_qam]  = qam_symbols

        all_rx_syms = []
        snr_list    = []
        h_first     = 1 + 0j

        for i in range(n_sym):
            chunk     = qam_padded[i * n_sc : (i + 1) * n_sc]
            tx_signal = _ofdm_modulate(chunk, sc_indices)

            rx_signal, h_eff, snr_db = apply_channel(
                tx_signal, x, y, n_rbs, TX_POWER_W)

            rx_syms = _ofdm_demodulate(rx_signal, h_eff, sc_indices)
            all_rx_syms.extend(rx_syms)
            snr_list.append(snr_db)
            if i == 0:
                h_first = h_eff

        rx_bits     = _qam_symbols_to_bits(
            np.array(all_rx_syms[:n_qam]), mcs, len(payload))
        rx_cmd_bits = rx_bits[:2]
        rx_crc_bits = rx_bits[2:10]
        crc_pass    = _crc8_check(rx_cmd_bits, rx_crc_bits)

        decoded_cmd = None
        if crc_pass:
            rev_map     = {tuple(v): k for k, v in CMD_BITS.items()}
            decoded_cmd = rev_map.get(tuple(int(b) for b in rx_cmd_bits))

        avg_snr_db = float(np.mean(snr_list))
        latency_us = n_sym * T_SYM_US
        return decoded_cmd, crc_pass, avg_snr_db, n_sym, latency_us, h_first

    # ------------------------------------------------------------------
    # Stage 6 -- Actuation decision  (identical logic to 2-robot)
    # ------------------------------------------------------------------

    def _actuation_decision(self, rid: str, decoded_cmd,
                             crc_pass: bool, pc_smooth: float) -> str:
        if crc_pass and decoded_cmd is not None:
            effective = decoded_cmd
        else:
            effective = (CMD_STOP if pc_smooth > HIGH_RISK_THRESHOLD
                         else CMD_SLOW)

        if effective == CMD_STOP:
            self._stop_ctr[rid] += 1
            if self._stop_ctr[rid] > MAX_STOP_STEPS:
                self._stop_ctr[rid] = 0
                self._hyst_cnt[rid] = 0
                effective = CMD_SLOW
        else:
            self._stop_ctr[rid] = 0

        if effective == CMD_STOP:
            self._hyst_cnt[rid] = 0
        elif effective == CMD_CONTINUE:
            self._hyst_cnt[rid] += 1
            if self._hyst_cnt[rid] < HYSTERESIS_COUNT:
                effective = CMD_SLOW
        return effective

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def step(self, positions: dict, velocities: dict,
             priorities: dict) -> dict:
        """
        Run one complete downlink PHY step for all 5 robots.

        Parameters
        ----------
        positions  : {rid: (x, y)}         -- current robot positions (m)
        velocities : {rid: (vx, vy)}        -- current robot velocities (m/s)
        priorities : {rid: int}             -- task priority 1/2/3 per robot

        Returns
        -------
        dict with per-robot keys indexed 0..4 plus global PHY keys.
        See _safe_default() for the full key list.
        """
        for rid in ROBOT_IDS:
            if rid not in positions or rid not in velocities:
                return self._safe_default()

        # Stage 2 -- collision probability for all 10 pairs
        pc_raw_max, pc_smooth_pairs, per_robot_pc = \
            self._collision_probability_all_pairs(positions, velocities)

        n_high_risk = sum(
            1 for pc in pc_smooth_pairs.values() if pc > HIGH_RISK_THRESHOLD
        )
        max_pc_global = max(per_robot_pc.values())

        # Stage 3a -- RB allocation (heuristic alpha)
        rbs = self._allocate_rbs(priorities, per_robot_pc, HEURISTIC_ALPHA)

        # Stage 3b -- per-robot MCS
        mcs = {}
        snr_est = {}
        for rid in ROBOT_IDS:
            x, y       = positions[rid]
            snr_est[rid] = estimate_snr_db(x, y, rbs[rid], TX_POWER_W)
            mcs[rid]     = self._select_mcs(per_robot_pc[rid], snr_est[rid])

        # Stage 4 -- command selection + deadlock resolution
        cmds = {rid: self._select_command(per_robot_pc[rid]) for rid in ROBOT_IDS}
        cmds = self._resolve_deadlock(cmds, priorities)

        # Stage 5 -- multi-symbol downlink chain per robot
        chain_out = {}
        for rid in ROBOT_IDS:
            x, y = positions[rid]
            chain_out[rid] = self._downlink_chain(
                cmds[rid], mcs[rid], rbs[rid], x, y)

        # Stage 6 -- actuation decision per robot
        act = {}
        for rid in ROBOT_IDS:
            dec_cmd, crc_pass, _, _, _, _ = chain_out[rid]
            act[rid] = self._actuation_decision(
                rid, dec_cmd, crc_pass, per_robot_pc[rid])

        # ---- Build result dict (keys indexed by robot number 0..4) ----
        result = {
            "max_pc_global":   round(max_pc_global, 4),
            "n_high_risk_pairs": n_high_risk,
        }
        for rid in ROBOT_IDS:
            i = rid.split("_")[1]   # "0" .. "4"
            dec_cmd, crc_pass, avg_snr, n_sym, lat, h_eff = chain_out[rid]
            result[f"pc_smooth_{i}"]  = round(per_robot_pc[rid], 4)
            result[f"rb_{i}"]         = rbs[rid]
            result[f"mcs_{i}"]        = mcs[rid]
            result[f"mcs_name_{i}"]   = MCS_NAMES[mcs[rid]]
            result[f"snr_{i}_dB"]     = round(avg_snr, 2)
            result[f"cmd_{i}"]        = cmds[rid]
            result[f"crc_{i}"]        = int(crc_pass)
            result[f"actuation_{i}"]  = act[rid]
            result[f"n_sym_{i}"]      = n_sym
            result[f"latency_{i}_us"] = round(lat, 2)

        return result

    # ------------------------------------------------------------------
    def _safe_default(self) -> dict:
        base_rb  = TOTAL_RBS // len(ROBOT_IDS)
        result = {
            "max_pc_global":     0.0,
            "n_high_risk_pairs": 0,
        }
        for rid in ROBOT_IDS:
            i = rid.split("_")[1]
            result[f"pc_smooth_{i}"]  = 0.0
            result[f"rb_{i}"]         = base_rb
            result[f"mcs_{i}"]        = MCS_QPSK
            result[f"mcs_name_{i}"]   = "QPSK"
            result[f"snr_{i}_dB"]     = 0.0
            result[f"cmd_{i}"]        = CMD_CONTINUE
            result[f"crc_{i}"]        = 0
            result[f"actuation_{i}"]  = CMD_CONTINUE
            result[f"n_sym_{i}"]      = 1
            result[f"latency_{i}_us"] = round(T_SYM_US, 2)
        return result
