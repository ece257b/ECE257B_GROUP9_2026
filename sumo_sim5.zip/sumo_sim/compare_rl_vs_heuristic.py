"""
compare_rl_vs_heuristic.py
===========================
Rigorous post-hoc comparison of the UCB-RL allocator vs the static
priority-heuristic allocator, using robot_trajectories.csv produced with
USE_RL = True.

Why this comparison is non-trivial
-----------------------------------
Changing RB allocation cascades into different SNR (more SCs = wider BW),
which changes MCS and therefore CRC pass rate and throughput.  We therefore
ONLY compare metrics that are purely a function of RB counts and do NOT
depend on the channel realisation or MCS:

  1. Priority alignment deviation  -- |rb_ratio - priority_ratio|
  2. Latency ordering correctness  -- when p0 != p1, does higher-priority
                                      robot get fewer OFDM symbols?

For channel-dependent metrics (SE, CRC pass rate) we report the RL's actual
values over time as CONVERGENCE evidence, without claiming a counter-factual
heuristic baseline (which would require a separate simulation run).

Four figures are produced:
  A. RL reward convergence over time (rolling mean)
  B. Priority alignment: RL vs Heuristic over time (rolling mean)
  C. Per-state learned action vs heuristic action
     (bar charts for the top-6 most common states)
  D. Q-value evolution by quarter + exploration phase

Usage:
    python compare_rl_vs_heuristic.py [--csv robot_trajectories.csv]
"""

import math
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from collections import defaultdict

# ── Constants (must match phy_downlink_ms.py exactly) ─────────────────────────
TOTAL_RBS                 = 7
COLLISION_BOOST_THRESHOLD = 0.5
MCS_BPS                   = {0: 2, 1: 4, 2: 6}   # QPSK, 16QAM, 64QAM
SC_PER_RB                 = 12
T_SYM_US                  = 83.333
PAYLOAD_BITS              = 160
WINDOW                    = 500   # rows (~50 s) for rolling statistics

# UCB state labels
PC_BIN_LABELS    = ["pc<0.30\n(safe)", "0.30-0.50\n(caution)",
                    "0.50-0.65\n(boost)", "pc>0.65\n(stop)"]
SNR_BIN_LABELS   = ["SNR<15 dB\n(poor)", "15-20 dB\n(ok)", "SNR>20 dB\n(good)"]


# ── Heuristic RB allocation (exact copy of phy_downlink_ms._allocate_rbs) ─────

def heuristic_alloc(p0: int, p1: int, pc: float):
    if pc > COLLISION_BOOST_THRESHOLD:
        half_lo = TOTAL_RBS // 2
        half_hi = TOTAL_RBS - half_lo
        return (half_hi, half_lo) if p0 >= p1 else (half_lo, half_hi)
    denom = (p0 + p1) if (p0 + p1) > 0 else 1
    rb_0  = math.floor(TOTAL_RBS * p0 / denom)
    rb_0  = max(1, min(rb_0, TOTAL_RBS - 1))
    return rb_0, TOTAL_RBS - rb_0


# ── KPI helpers (RB-only, no channel dependence) ──────────────────────────────

def priority_align(rb_0, p0, p1):
    denom = (p0 + p1) if (p0 + p1) > 0 else 1
    return abs(rb_0 / TOTAL_RBS - p0 / denom)


def n_ofdm_syms(rb: int, mcs: int) -> int:
    bps = MCS_BPS[mcs]
    qam_syms = math.ceil(PAYLOAD_BITS / bps)
    sc_avail = rb * SC_PER_RB
    return math.ceil(qam_syms / sc_avail)


def latency_correct(rb_0, rb_1, mcs_0, mcs_1, p0, p1) -> float:
    """1 = correct (higher-priority has fewer symbols), 0 = wrong, nan = equal."""
    if p0 == p1:
        return float("nan")
    sym_0 = n_ofdm_syms(rb_0, mcs_0)
    sym_1 = n_ofdm_syms(rb_1, mcs_1)
    if p0 > p1:
        return 1.0 if sym_0 <= sym_1 else 0.0
    else:
        return 1.0 if sym_1 <= sym_0 else 0.0


def safe_nanmean(arr):
    a = arr[~np.isnan(arr)]
    return float(np.mean(a)) if len(a) > 0 else float("nan")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", default="robot_trajectories.csv")
    args = parser.parse_args()

    df = pd.read_csv(args.csv)
    df = df.dropna(subset=["robot_0_priority", "robot_1_priority",
                            "pc_smooth_0", "pc_smooth_1"]).reset_index(drop=True)
    n = len(df)
    print(f"Loaded {n} rows from {args.csv}")

    if "rl_reward" not in df.columns:
        print("ERROR: CSV does not contain RL columns. Re-run with USE_RL=True.")
        return

    p0_arr   = df["robot_0_priority"].astype(int).values
    p1_arr   = df["robot_1_priority"].astype(int).values
    mcs_0    = df["mcs_0"].values.astype(int)
    mcs_1    = df["mcs_1"].values.astype(int)
    rl_rb0   = df["rb_0"].values.astype(int)
    rl_rb1   = df["rb_1"].values.astype(int)
    pc_alloc = df[["pc_smooth_0", "pc_smooth_1"]].max(axis=1).values
    rl_reward  = df["rl_reward"].values
    rl_explore = df["rl_explore"].values
    rl_q_best  = df["rl_q_best"].values
    time       = df["time"].values

    # ── Heuristic counter-factual RB allocations ─────────────────────────────
    h_rb0 = np.array([heuristic_alloc(p0_arr[i], p1_arr[i], pc_alloc[i])[0]
                      for i in range(n)], dtype=int)
    h_rb1 = TOTAL_RBS - h_rb0

    # ── KPI 1: Priority alignment (lower = better) ────────────────────────────
    rl_align = np.array([priority_align(rl_rb0[i], p0_arr[i], p1_arr[i])
                         for i in range(n)])
    h_align  = np.array([priority_align(h_rb0[i], p0_arr[i], p1_arr[i])
                         for i in range(n)])

    # ── KPI 2: Latency ordering (higher = better) ─────────────────────────────
    rl_lat_ok = np.array([latency_correct(rl_rb0[i], rl_rb1[i],
                                          mcs_0[i], mcs_1[i],
                                          p0_arr[i], p1_arr[i])
                          for i in range(n)])
    h_lat_ok  = np.array([latency_correct(h_rb0[i], h_rb1[i],
                                          mcs_0[i], mcs_1[i],
                                          p0_arr[i], p1_arr[i])
                          for i in range(n)])

    # ── Per-state analysis ────────────────────────────────────────────────────
    # For each unique RL state, compute:
    #   - mean RL rb_0 (average of what the UCB chose)
    #   - heuristic rb_0 (constant per state -- deterministic)
    #   - mean RL reward
    #   - visit count
    state_stats = defaultdict(lambda: {"rl_rb0": [], "h_rb0": [], "reward": []})
    for i in range(n):
        s = df["rl_state"].iloc[i]
        state_stats[s]["rl_rb0"].append(rl_rb0[i])
        state_stats[s]["h_rb0"].append(h_rb0[i])
        state_stats[s]["reward"].append(rl_reward[i])

    state_summary = {}
    for s, v in state_stats.items():
        state_summary[s] = {
            "rl_rb0_mean": np.mean(v["rl_rb0"]),
            "h_rb0":       v["h_rb0"][0],     # deterministic
            "reward_mean": np.mean(v["reward"]),
            "count":       len(v["rl_rb0"]),
        }

    top_states = sorted(state_summary.items(), key=lambda x: -x[1]["count"])[:8]

    # ── Aggregated KPIs across quarters ──────────────────────────────────────
    quarters   = [n//4, n//2, 3*n//4, n]
    q_labels   = ["Q1 (first 25%)", "Q2", "Q3", "Q4 (last 25%)"]
    q_rl_align = []
    q_h_align  = []
    q_rl_lat   = []
    q_h_lat    = []
    q_reward   = []
    q_starts   = [0] + quarters[:-1]
    for start, end in zip(q_starts, quarters):
        s = slice(start, end)
        q_rl_align.append(safe_nanmean(rl_align[s]))
        q_h_align.append(safe_nanmean(h_align[s]))
        q_rl_lat.append(safe_nanmean(rl_lat_ok[s]))
        q_h_lat.append(safe_nanmean(h_lat_ok[s]))
        q_reward.append(np.mean(rl_reward[s]))

    # ── Print summary table ───────────────────────────────────────────────────
    print()
    print("=" * 75)
    print(f"{'Quarter':<18} {'RL align':>10} {'H align':>10} "
          f"{'RL lat_ok':>10} {'H lat_ok':>10} {'RL reward':>10}")
    print("=" * 75)
    for i, ql in enumerate(q_labels):
        rl_a_better = "^" if q_rl_align[i] <= q_h_align[i] else "v"
        rl_l_better = "^" if q_rl_lat[i] >= q_h_lat[i] else "v"
        print(f"  {ql:<16} {q_rl_align[i]:>10.4f} {q_h_align[i]:>10.4f} "
              f"{q_rl_lat[i]:>10.4f} {q_h_lat[i]:>10.4f} {q_reward[i]:>10.4f} "
              f"  align:{rl_a_better} lat:{rl_l_better}")
    print()
    print("  align: deviation from priority-ratio (lower=better)  ^ = RL better")
    print("  lat:   fraction where higher-priority robot has lower latency")
    print()
    print(f"  Danger-zone steps (pc>0.5): {(pc_alloc > 0.5).sum()} / {n}  ({100*(pc_alloc>0.5).mean():.2f}%)")
    print(f"  Unequal priority steps: {(p0_arr != p1_arr).sum()} / {n}  ({100*(p0_arr!=p1_arr).mean():.1f}%)")
    print(f"  RL exploration steps: {(rl_explore == 1).sum()} / {n}")
    print()
    print("  Top-8 states by visit count:")
    print(f"  {'State':>22}  {'Visits':>7}  {'H rb_0':>7}  {'RL rb_0 mean':>13}  {'Mean reward':>12}")
    for s, v in top_states:
        print(f"  {s:>22}  {v['count']:>7}  {v['h_rb0']:>7}  "
              f"{v['rl_rb0_mean']:>13.2f}  {v['reward_mean']:>12.4f}")
    print("=" * 75)

    # ── Plotting ──────────────────────────────────────────────────────────────
    fig = plt.figure(figsize=(16, 14))
    gs  = gridspec.GridSpec(3, 2, figure=fig, hspace=0.55, wspace=0.35)

    # ── A: Rolling reward over time ───────────────────────────────────────────
    ax_a = fig.add_subplot(gs[0, :])
    roll_reward = pd.Series(rl_reward).rolling(WINDOW, min_periods=1).mean()
    ax_a.plot(time, roll_reward, color="steelblue", lw=1.5, label="RL rolling avg reward")

    # Mark quarter boundaries
    for q in quarters[:-1]:
        ax_a.axvline(time[q], color="grey", ls=":", lw=0.8)

    # Quarter averages
    q_starts_t = [time[s] for s in q_starts]
    q_ends_t   = [time[e - 1] for e in quarters]
    for i, (qs, qe, qr) in enumerate(zip(q_starts_t, q_ends_t, q_reward)):
        ax_a.hlines(qr, qs, qe, colors="darkorange", lw=2.5,
                    label=f"Q{i+1} mean={qr:.3f}" if i == 0 else f"Q{i+1} mean={qr:.3f}")

    ax_a.set_xlabel("Simulation time (s)")
    ax_a.set_ylabel("Reward")
    ax_a.set_title("A: UCB-RL reward convergence  (window=500 steps | 50 s)\n"
                   "Orange bars = per-quarter mean reward")
    ax_a.legend(fontsize=7, ncol=3)
    ax_a.grid(alpha=0.3)

    # ── B: Priority alignment over time ───────────────────────────────────────
    ax_b = fig.add_subplot(gs[1, 0])
    roll_rl = pd.Series(rl_align).rolling(WINDOW, min_periods=1).mean()
    roll_h  = pd.Series(h_align).rolling(WINDOW, min_periods=1).mean()
    ax_b.plot(time, roll_rl, color="steelblue", lw=1.5, label="RL")
    ax_b.plot(time, roll_h,  color="tomato",    lw=1.5, ls="--", label="Heuristic")
    ax_b.set_xlabel("Simulation time (s)")
    ax_b.set_ylabel("|rb_ratio - priority_ratio|")
    ax_b.set_title("B: Priority alignment deviation\n(lower = better)")
    ax_b.legend(fontsize=9)
    ax_b.grid(alpha=0.3)

    # ── C: Latency ordering over time ─────────────────────────────────────────
    ax_c = fig.add_subplot(gs[1, 1])
    roll_rl_lat = pd.Series(rl_lat_ok).rolling(WINDOW, min_periods=1).mean()
    roll_h_lat  = pd.Series(h_lat_ok).rolling(WINDOW, min_periods=1).mean()
    ax_c.plot(time, roll_rl_lat, color="steelblue", lw=1.5, label="RL")
    ax_c.plot(time, roll_h_lat,  color="tomato",    lw=1.5, ls="--", label="Heuristic")
    ax_c.set_xlabel("Simulation time (s)")
    ax_c.set_ylabel("Fraction correct")
    ax_c.set_title("C: Latency ordering correctness\n"
                   "(high-priority robot has lower latency, higher = better)")
    ax_c.legend(fontsize=9)
    ax_c.set_ylim(-0.05, 1.10)
    ax_c.grid(alpha=0.3)

    # ── D: Per-state RL mean action vs heuristic (top-8 states) ───────────────
    ax_d = fig.add_subplot(gs[2, :])
    state_labels = [s for s, _ in top_states]
    rl_means     = [v["rl_rb0_mean"] for _, v in top_states]
    h_vals       = [v["h_rb0"]       for _, v in top_states]
    counts       = [v["count"]        for _, v in top_states]

    x     = np.arange(len(top_states))
    width = 0.35
    bars_h = ax_d.bar(x - width/2, h_vals,   width, label="Heuristic rb_0",  color="tomato",    alpha=0.85)
    bars_r = ax_d.bar(x + width/2, rl_means, width, label="RL mean rb_0",    color="steelblue", alpha=0.85)

    for bar, cnt in zip(bars_h, counts):
        ax_d.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.04,
                  f"n={cnt}", ha="center", va="bottom", fontsize=6.5, color="tomato")
    for bar, rm in zip(bars_r, rl_means):
        ax_d.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.04,
                  f"{rm:.2f}", ha="center", va="bottom", fontsize=6.5, color="steelblue")

    ax_d.set_xticks(x)
    # Decode state labels to readable form
    def decode_state(s):
        # s is like "(0, 7, 2)"
        parts = s.strip("()").split(",")
        pc_b, pp_idx, snr_b = int(parts[0]), int(parts[1]), int(parts[2])
        p0d = pp_idx // 3 + 1
        p1d = pp_idx % 3  + 1
        return f"pc:{PC_BIN_LABELS[pc_b].split(chr(10))[0]}\np=({p0d},{p1d})\nSNR:{SNR_BIN_LABELS[snr_b].split(chr(10))[0]}"
    readable = [decode_state(s) for s in state_labels]
    ax_d.set_xticklabels(readable, fontsize=7)
    ax_d.set_ylabel("rb_0 (RBs to robot_0)")
    ax_d.set_ylim(0, TOTAL_RBS + 0.5)
    ax_d.axhline(TOTAL_RBS / 2, color="grey", ls=":", lw=0.8, label=f"Neutral split ({TOTAL_RBS//2}/{TOTAL_RBS - TOTAL_RBS//2})")
    ax_d.set_title("D: Learned RL action vs Heuristic action per state  (top-8 most visited states)")
    ax_d.legend(fontsize=8)
    ax_d.grid(axis="y", alpha=0.3)

    fig.suptitle("UCB-RL vs Priority-Heuristic Allocator -- 5G Private Network RB Allocation\n"
                 "ECE 257B Industrial Robotics Project",
                 fontsize=12, fontweight="bold")

    out = "rl_vs_heuristic.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"Saved plot -> {out}")

    # ── Additional danger-zone deep dive ─────────────────────────────────────
    danger = pc_alloc > COLLISION_BOOST_THRESHOLD
    if danger.sum() > 0:
        print()
        print(f"  === Danger-zone analysis ({danger.sum()} steps) ===")
        d_rl  = rl_align[danger]
        d_h   = h_align[danger]
        d_lat_rl = rl_lat_ok[danger]
        d_lat_h  = h_lat_ok[danger]
        print(f"  Priority align: RL={safe_nanmean(d_rl):.4f}  Heuristic={safe_nanmean(d_h):.4f}")
        print(f"  Latency OK:     RL={safe_nanmean(d_lat_rl):.4f}  Heuristic={safe_nanmean(d_lat_h):.4f}")
        print(f"  RL actions in danger: {dict(pd.Series(rl_rb0[danger]).value_counts().sort_index())}")
        print(f"  H  actions in danger: {dict(pd.Series(h_rb0[danger]).value_counts().sort_index())}")


if __name__ == "__main__":
    main()
