"""
generate_plots_final.py
=======================
Produces two separate PNG files from robot_trajectories.csv:

  result_collision_latency.png  -- Packet latency during collision event
  result_priority_latency.png   -- Mean packet latency by task priority pair

Run: python generate_plots_final.py
Requires: robot_trajectories.csv generated with USE_MULTISYM=True
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Constants (must match phy_downlink_ms.py)
# ---------------------------------------------------------------------------
T_SYM_US = 80.0 / (15_000 * 64) * 1_000_000   # 83.333 us per OFDM symbol

STYLE = {
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.grid":         True,
    "grid.linestyle":    "--",
    "grid.alpha":        0.35,
    "font.family":       "DejaVu Sans",
    "font.size":         12,
}

# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------
df = pd.read_csv("robot_trajectories.csv")
df = df.dropna(subset=[
    "latency_0_us", "latency_1_us", "pc_smooth_0",
    "mcs_0", "rb_0", "rb_1",
    "robot_0_priority", "robot_1_priority",
]).reset_index(drop=True)

df["mcs_0"]             = df["mcs_0"].astype(int)
df["mcs_1"]             = df["mcs_1"].astype(int)
df["robot_0_priority"]  = df["robot_0_priority"].astype(int)
df["robot_1_priority"]  = df["robot_1_priority"].astype(int)

# ---------------------------------------------------------------------------
# Shared y-axis tick setup for both plots
# ---------------------------------------------------------------------------
SYM_VALS   = [n * T_SYM_US for n in [1, 2, 3, 4]]
SYM_LABELS = [f"{v:.0f} µs  ({n} sym)" for n, v in zip([1, 2, 3, 4], SYM_VALS)]
REF_LS     = ["-", "--", ":", "-."]


# ============================================================================
# PLOT 1 — Packet latency during collision event
# ============================================================================

ZOOM_T0, ZOOM_T1 = 476.0, 494.5
dz = df[(df["time"] >= ZOOM_T0) & (df["time"] <= ZOOM_T1)].reset_index(drop=True)
tz = dz["time"].values
pc = dz["pc_smooth_0"].values

with plt.rc_context(STYLE):
    fig1, ax = plt.subplots(figsize=(9, 5.5))

    # -- Background shading by Pc region --
    for i in range(len(tz) - 1):
        if pc[i] > 0.5:
            ax.axvspan(tz[i], tz[i+1], color="#9467bd", alpha=0.18, linewidth=0)
        elif pc[i] > 0.3:
            ax.axvspan(tz[i], tz[i+1], color="#ff7f0e", alpha=0.15, linewidth=0)

    # -- n_sym reference lines --
    for n, ls in zip([1, 2, 3, 4], REF_LS):
        ax.axhline(n * T_SYM_US, color="gray", lw=0.9, ls=ls, alpha=0.55)

    # -- Latency lines --
    ax.plot(tz, dz["latency_0_us"].values,
            color="#1f77b4", lw=2.2, label="Robot 0  (priority 1 — low)")
    ax.plot(tz, dz["latency_1_us"].values,
            color="#2ca02c", lw=2.2, ls="--", label="Robot 1  (priority 3 — high)")

    # -- Pc on right y-axis (clean, no text labels on this axis) --
    axr = ax.twinx()
    axr.plot(tz, pc, color="#888888", lw=1.4, ls=":", alpha=0.85)
    axr.axhline(0.3, color="#ff7f0e", lw=0.9, ls="--", alpha=0.7)
    axr.axhline(0.5, color="#9467bd", lw=0.9, ls="--", alpha=0.7)
    axr.set_ylim(-0.05, 1.35)
    axr.set_yticks([0.0, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0])
    axr.set_yticklabels(["0.0", "0.2", "0.3", "0.4", "0.5", "0.6", "0.8", "1.0"],
                         fontsize=10)
    axr.set_ylabel("Collision Probability  $P_c$", fontsize=11, color="#666666")
    axr.tick_params(axis="y", colors="#666666")
    axr.spines["right"].set_visible(True)
    axr.spines["right"].set_color("#bbbbbb")

    # -- Threshold labels placed inside the plot on the LEFT axis space --
    ax.text(ZOOM_T0 + 0.25, 0.31 * (440 - 40) + 40,   # mapped from Pc=0.3
            "", fontsize=1)   # placeholder to keep layout stable
    axr.text(ZOOM_T0 + 0.25, 0.32, "16-QAM forced  ($P_c$ > 0.3)",
             fontsize=9, color="#cc6600")
    axr.text(ZOOM_T0 + 0.25, 0.52, "Collision boost  ($P_c$ > 0.5)",
             fontsize=9, color="#7a4fa3")

    # -- Phase annotations (arrows into the blue Robot 0 line) --
    ax.annotate("Phase 1\nMCS drop → 333 µs",
                xy=(482.8, 333.33), xytext=(480.5, 395),
                fontsize=9, color="#cc6600", ha="center",
                arrowprops=dict(arrowstyle="->", color="#cc6600", lw=1.1))
    ax.annotate("Phase 2\nRB boost → 167 µs",
                xy=(486.6, 166.67), xytext=(486.6, 105),
                fontsize=9, color="#7a4fa3", ha="center",
                arrowprops=dict(arrowstyle="->", color="#7a4fa3", lw=1.1))
    ax.annotate("Phase 3\nBoost off → 333 µs",
                xy=(488.6, 333.33), xytext=(490.5, 395),
                fontsize=9, color="#cc6600", ha="center",
                arrowprops=dict(arrowstyle="->", color="#cc6600", lw=1.1))

    # -- Axes --
    ax.set_xlim(ZOOM_T0, ZOOM_T1)
    ax.set_ylim(40, 440)
    ax.set_yticks(SYM_VALS)
    ax.set_yticklabels(SYM_LABELS, fontsize=10)
    ax.set_xlabel("Simulation Time (s)", fontsize=12)
    ax.set_ylabel("Packet Latency", fontsize=12)
    ax.set_title("Packet Latency During Collision Event", fontsize=13, fontweight="bold", pad=12)

    handles = [
        Line2D([0],[0], color="#1f77b4", lw=2.2, label="Robot 0  (priority 1 — low)"),
        Line2D([0],[0], color="#2ca02c", lw=2.2, ls="--", label="Robot 1  (priority 3 — high)"),
        Line2D([0],[0], color="#888888", lw=1.4, ls=":", label="$P_c$ (smooth)"),
    ]
    ax.legend(handles=handles, fontsize=10, loc="upper left", framealpha=0.9)

    fig1.tight_layout()
    fig1.savefig("result_collision_latency.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig1)
    print("[OK] result_collision_latency.png")


# ============================================================================
# PLOT 2 — Mean packet latency by task priority pair (no-collision)
# ============================================================================

nc = df[df["pc_smooth_0"] < 0.3].copy()
nc["pair"] = nc.apply(
    lambda r: f"R0=p{r.robot_0_priority}\nR1=p{r.robot_1_priority}", axis=1)

nc["sort_key"] = nc.apply(
    lambda r: (r.robot_0_priority, r.robot_1_priority), axis=1)

nc_grp    = nc.groupby("pair", sort=False)
pair_stats = nc_grp[["latency_0_us", "latency_1_us"]].mean()
pair_order = (nc.groupby("pair")["sort_key"]
                .first()
                .sort_values(ascending=False)
                .index.tolist())
pair_stats = pair_stats.loc[pair_order]

with plt.rc_context(STYLE):
    fig2, ax = plt.subplots(figsize=(9, 5.5))

    n_pairs = len(pair_order)
    x = np.arange(n_pairs)
    W = 0.30

    b0 = ax.bar(x - W/2, pair_stats["latency_0_us"].values, W,
                color="#1f77b4", alpha=0.85, label="Robot 0")
    b1 = ax.bar(x + W/2, pair_stats["latency_1_us"].values, W,
                color="#2ca02c", alpha=0.85, label="Robot 1")

    # -- n_sym reference lines --
    for n, ls in zip([1, 2, 3, 4], REF_LS):
        ax.axhline(n * T_SYM_US, color="gray", lw=0.9, ls=ls, alpha=0.55)

    # -- Value labels on top of each bar --
    for bar in list(b0) + list(b1):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 3,
                f"{h:.0f}", ha="center", va="bottom", fontsize=10, fontweight="bold")

    # -- Axes --
    ax.set_xticks(x)
    ax.set_xticklabels(pair_order, fontsize=10, linespacing=1.4)
    ax.set_yticks(SYM_VALS)
    ax.set_yticklabels(SYM_LABELS, fontsize=10)
    ax.set_ylim(0, 420)
    ax.set_xlim(-0.55, n_pairs - 0.45)
    ax.set_ylabel("Mean Packet Latency", fontsize=12)
    ax.set_xlabel("Task Priority Pair", fontsize=12)
    ax.set_title("Mean Packet Latency by Task Priority Pair\n"
                 "No-collision only  ($P_c < 0.3$)",
                 fontsize=13, fontweight="bold", pad=12)
    ax.legend(fontsize=10, loc="upper right", framealpha=0.9)

    fig2.tight_layout()
    fig2.savefig("result_priority_latency.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig2)
    print("[OK] result_priority_latency.png")
