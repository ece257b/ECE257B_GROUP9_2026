"""
phy_downlink_5r_rl.py -- UCB Reinforcement Learning RB Allocator (5 Robots)
============================================================================
Drop-in replacement for phy_downlink_5r.py that swaps the fixed-alpha
heuristic RB allocator for a UCB-1 contextual bandit that LEARNS the
optimal collision-weight alpha per context.

Why this beats the heuristic
-----------------------------
The heuristic uses HEURISTIC_ALPHA = 1.0 everywhere.  In practice:
  * When no pair is at risk, a high alpha wastes RBs on collision-boosting
    instead of maximising spectral efficiency.
  * When MULTIPLE pairs are simultaneously at risk, a fixed alpha may
    under-allocate to the most critical robots.
The UCB agent observes the CURRENT GLOBAL STATE and picks the alpha that
maximises long-term reward.  With 5 robots there are C(5,2) = 10 pairs,
so high-collision states occur frequently enough for UCB to converge.

State space  (4 x 9 x 3 x 3 = 324 states)
--------------------------------------------
  max_pc_bin        [4] -- max smoothed pc across all 10 pairs
                           (<0.30 / <0.50 / <0.65 / >=0.65)
  priority_pair_bin [9] -- (p_hi, p_lo) of the highest-risk pair
                           same encoding as 2-robot priority_pair_idx
  avg_snr_bin       [3] -- average SNR across 5 robots
                           (<15 dB / <20 dB / >=20 dB)
  n_high_risk_bin   [3] -- pairs with pc_smooth > 0.5
                           (0 / 1 / 2+)

Action space  (6 actions -- same count as 2-robot UCB)
-------------------------------------------------------
  alpha in {0.0, 0.5, 1.0, 1.5, 2.0, 3.0}
  The heuristic baseline is alpha = 1.0 (action index 2).

Reward  (identical weights to 2-robot UCB for apples-to-apples comparison)
--------------------------------------------------------------------------
  R_safety   (0.35) -- penalise high max_pc, CRC failures during high risk
  R_priority (0.25) -- penalise deviation from priority-proportional split
                       + bonus when high-priority robots have lower latency
  R_spectral (0.20) -- reward total throughput (MCS * RBs summed over all 5)
  R_channel  (0.12) -- reward CRC pass rate; bonus for 64-QAM when suitable
  R_latency  (0.08) -- penalise deadlock (prolonged stops)

Extra keys added to the step() result dict
-------------------------------------------
  rl_state        -- state tuple as a string
  rl_action       -- alpha value chosen by UCB
  rl_reward       -- reward computed this step
  rl_explore      -- 1 if exploration step, 0 if exploitation, -1 if failsafe
  rl_q_best       -- best Q-value in current state
  rl_total_steps  -- cumulative steps processed by UCB
"""

import math
import numpy as np

from phy_downlink_5r import (
    DownlinkPHY as _BaseDownlinkPHY,
    _largest_remainder_alloc,
    # Re-export for run_sim.py
    apply_actuation, speed_angle_to_velocity,
    # Constants
    ROBOT_IDS, ROBOT_PAIRS,
    TOTAL_RBS, MAX_RB_PER_ROBOT, MIN_RB_PER_ROBOT,
    HIGH_RISK_THRESHOLD,
    SE_MAX_5R,
    MCS_QPSK, MCS_16QAM, MCS_64QAM,
    P_STOP, P_SLOW,
    MAX_STOP_STEPS,
    T_SYM_US,
    TX_POWER_W,
)
from channel_model import estimate_snr_db


# ============================================================================
#  UCB hyper-parameters
# ============================================================================

UCB_C = 1.5

ALPHA_ACTIONS = [0.0, 0.5, 1.0, 1.5, 2.0, 3.0]   # 6 actions
N_ACTIONS     = len(ALPHA_ACTIONS)

# Index of the heuristic alpha (used as failsafe)
_HEURISTIC_ACTION_IDX = ALPHA_ACTIONS.index(1.0)   # index 2


# ============================================================================
#  Reward weights  (identical to 2-robot UCB for comparability)
# ============================================================================

W_SAFETY   = 0.35
W_PRIORITY = 0.25
W_SPECTRAL = 0.20
W_CHANNEL  = 0.12
W_LATENCY  = 0.08

MCS_BPS = {MCS_QPSK: 2, MCS_16QAM: 4, MCS_64QAM: 6}

SNR_THRESH_LOW  = 15.0
SNR_THRESH_HIGH = 20.0


# ============================================================================
#  State discretisation
# ============================================================================

def _max_pc_bin(max_pc: float) -> int:
    """4 bins aligned to MCS and command thresholds (same as 2-robot)."""
    if max_pc < 0.30: return 0   # safe
    if max_pc < 0.50: return 1   # 16-QAM zone
    if max_pc < 0.65: return 2   # approaching STOP
    return 3                      # STOP zone


def _priority_pair_bin(pc_smooth_pairs: dict, priorities: dict) -> int:
    """
    Find the highest-risk pair and map (p_hi, p_lo) -> 0..8.

    Encoding is identical to the 2-robot priority_pair_idx:
        bin = (p_hi - 1) * 3 + (p_lo - 1)
    where p_hi = max(priorities of the two robots in the highest-pc pair).

    If all pairs have pc=0, fall back to global (max_priority, min_priority).
    """
    if not pc_smooth_pairs:
        all_p = sorted(priorities.values(), reverse=True)
        return (all_p[0] - 1) * 3 + (all_p[-1] - 1)

    best_pair = max(pc_smooth_pairs, key=pc_smooth_pairs.get)
    rid_a, rid_b = best_pair
    p_hi = max(priorities[rid_a], priorities[rid_b])
    p_lo = min(priorities[rid_a], priorities[rid_b])
    return (p_hi - 1) * 3 + (p_lo - 1)


def _avg_snr_bin(avg_snr_db: float) -> int:
    if avg_snr_db < SNR_THRESH_LOW:  return 0
    if avg_snr_db < SNR_THRESH_HIGH: return 1
    return 2


def _n_high_risk_bin(pc_smooth_pairs: dict,
                     threshold: float = HIGH_RISK_THRESHOLD) -> int:
    """3 bins: {0 pairs, 1 pair, 2+ pairs} with pc > threshold."""
    n = sum(1 for pc in pc_smooth_pairs.values() if pc > threshold)
    if n == 0: return 0
    if n == 1: return 1
    return 2


def make_state(pc_smooth_pairs: dict, priorities: dict,
               avg_snr_db: float) -> tuple:
    """Build the 4-component UCB state tuple from raw inputs."""
    max_pc = max(pc_smooth_pairs.values()) if pc_smooth_pairs else 0.0
    return (
        _max_pc_bin(max_pc),
        _priority_pair_bin(pc_smooth_pairs, priorities),
        _avg_snr_bin(avg_snr_db),
        _n_high_risk_bin(pc_smooth_pairs),
    )


# ============================================================================
#  UCBAllocator  -- contextual UCB-1 bandit (324 states x 6 actions)
# ============================================================================

class UCBAllocator:
    """
    Contextual UCB-1 bandit for alpha selection.

    State  : 4-tuple  (max_pc_bin, priority_pair_bin, avg_snr_bin, n_high_risk_bin)
    Action : index into ALPHA_ACTIONS  (0..5)

    Identical architecture to the 2-robot UCBAllocator -- only the state
    definition and action semantics differ.
    """

    def __init__(self, c: float = UCB_C):
        self.c       = c
        self._Q: dict = {}
        self._N: dict = {}
        self._total   = 0

    def _ensure(self, s: tuple):
        if s not in self._Q:
            self._Q[s] = [0.0] * N_ACTIONS
            self._N[s] = [0]   * N_ACTIONS

    def select(self, state: tuple) -> tuple:
        """
        UCB-1 action selection.

        Returns
        -------
        alpha      : float  -- collision weight to use this step
        action_idx : int    -- index into ALPHA_ACTIONS
        is_explore : bool   -- True if this was a pure-exploration step
        """
        self._ensure(state)
        n_total = sum(self._N[state])

        # Explore unvisited actions first (deterministic warm-up)
        unvisited = [i for i, n in enumerate(self._N[state]) if n == 0]
        if unvisited:
            idx = unvisited[0]
            return ALPHA_ACTIONS[idx], idx, True

        # Exploit via UCB scores
        ucb = [
            self._Q[state][i] + self.c * math.sqrt(
                math.log(n_total + 1) / (self._N[state][i] + 1)
            )
            for i in range(N_ACTIONS)
        ]
        idx = int(np.argmax(ucb))
        return ALPHA_ACTIONS[idx], idx, False

    def update(self, state: tuple, action_idx: int, reward: float):
        """Incremental mean update."""
        self._ensure(state)
        self._N[state][action_idx] += 1
        n = self._N[state][action_idx]
        self._Q[state][action_idx] += (reward - self._Q[state][action_idx]) / n
        self._total += 1

    @property
    def total_steps(self) -> int:
        return self._total

    def best_q(self, state: tuple) -> float:
        self._ensure(state)
        return max(self._Q[state])

    def q_table_summary(self) -> dict:
        return {s: max(self._Q[s]) for s in self._Q}


# ============================================================================
#  Reward computation  (5-robot generalisation)
# ============================================================================

def _compute_reward(
    max_pc:        float,
    per_robot_pc:  dict,   # {rid: float}
    priorities:    dict,   # {rid: int}
    rbs:           dict,   # {rid: int}
    mcs_dict:      dict,   # {rid: int}
    crc_dict:      dict,   # {rid: bool}
    snr_dict:      dict,   # {rid: float}
    lat_dict:      dict,   # {rid: float}
    stop_ctrs:     dict,   # {rid: int}
) -> float:
    """
    Five-component weighted reward generalised to 5 robots.

    All components use the same weights as the 2-robot UCB so that reward
    magnitudes are directly comparable between the two cases.
    """

    # ---- R_safety ---------------------------------------------------
    r_safety = 1.0 - max_pc
    if max_pc >= P_STOP:
        r_safety -= 3.0
    # Penalise CRC failures while risk is high (capped at -1.0 regardless
    # of how many robots are at risk, to avoid blow-up with 5 robots)
    if max_pc > HIGH_RISK_THRESHOLD:
        n_failed = sum(1 for rid in ROBOT_IDS if not crc_dict[rid])
        r_safety -= 0.5 * min(n_failed, 2)

    # ---- R_priority -------------------------------------------------
    total_p = sum(priorities.values()) or 1
    ideal_frac  = {rid: priorities[rid] / total_p for rid in ROBOT_IDS}
    actual_frac = {rid: rbs[rid] / TOTAL_RBS      for rid in ROBOT_IDS}
    # Normalise by n_robots so scale matches the single-robot term in 2-robot
    r_priority = -sum(
        abs(actual_frac[rid] - ideal_frac[rid]) for rid in ROBOT_IDS
    ) / len(ROBOT_IDS)

    # Latency direction bonus: across all unequal-priority pairs, reward
    # cases where the higher-priority robot has strictly lower latency.
    correct = total_pairs = 0
    for rid_a, rid_b in ROBOT_PAIRS:
        if priorities[rid_a] == priorities[rid_b]:
            continue
        total_pairs += 1
        hi = rid_a if priorities[rid_a] > priorities[rid_b] else rid_b
        lo = rid_b if priorities[rid_a] > priorities[rid_b] else rid_a
        if lat_dict[hi] <= lat_dict[lo]:
            correct += 1
    if total_pairs > 0:
        # Centred around 0: +0.5 if all correct, -0.5 if all wrong
        r_priority += 0.5 * (correct / total_pairs - 0.5)

    # ---- R_spectral -------------------------------------------------
    se_total   = sum(MCS_BPS[mcs_dict[rid]] * rbs[rid] * 12 for rid in ROBOT_IDS)
    r_spectral = se_total / SE_MAX_5R   # normalised 0..1

    # ---- R_channel --------------------------------------------------
    crc_pass_rate = sum(1 for crc in crc_dict.values() if crc) / len(ROBOT_IDS)
    r_channel     = crc_pass_rate
    avg_snr = sum(snr_dict.values()) / len(ROBOT_IDS)
    if (avg_snr >= SNR_THRESH_HIGH
            and all(mcs_dict[rid] == MCS_64QAM for rid in ROBOT_IDS)):
        r_channel += 0.3

    # ---- R_latency --------------------------------------------------
    # Penalise prolonged deadlock: mean stop-counter ratio across robots
    deadlock_ratio = sum(
        min(stop_ctrs[rid] / MAX_STOP_STEPS, 1.0) for rid in ROBOT_IDS
    ) / len(ROBOT_IDS)
    r_latency = -deadlock_ratio

    return (W_SAFETY   * r_safety
          + W_PRIORITY * r_priority
          + W_SPECTRAL * r_spectral
          + W_CHANNEL  * r_channel
          + W_LATENCY  * r_latency)


# ============================================================================
#  DownlinkPHY  -- RL version
# ============================================================================

class DownlinkPHY(_BaseDownlinkPHY):
    """
    Extends phy_downlink_5r.DownlinkPHY by replacing the fixed-alpha
    _allocate_rbs() heuristic with a UCB contextual bandit that learns
    the optimal alpha per (max_pc_bin, priority_pair_bin, snr_bin, n_risk_bin).

    Only step() is overridden.  All collision-probability, MCS, command,
    OFDM chain, and actuation logic runs unchanged from the parent class.

    Failsafe: if UCB selects an alpha that leads to a degenerate allocation
    (all robots at floor or ceiling due to rounding edge-cases), the heuristic
    alpha=1.0 is used instead and rl_explore is set to -1.
    """

    def __init__(self):
        super().__init__()
        self.ucb = UCBAllocator(c=UCB_C)

    # ------------------------------------------------------------------
    def step(self, positions: dict, velocities: dict,
             priorities: dict) -> dict:

        for rid in ROBOT_IDS:
            if rid not in positions or rid not in velocities:
                return self._safe_default()

        # Stage 2 -- collision probability (inherited)
        pc_raw_max, pc_smooth_pairs, per_robot_pc = \
            self._collision_probability_all_pairs(positions, velocities)

        n_high_risk   = sum(
            1 for pc in pc_smooth_pairs.values() if pc > HIGH_RISK_THRESHOLD)
        max_pc_global = max(per_robot_pc.values())

        # Neutral SNR estimate for state encoding (action-independent)
        neutral_rb = max(1, TOTAL_RBS // len(ROBOT_IDS))   # 3
        snr_vals   = [
            estimate_snr_db(*positions[rid], neutral_rb, TX_POWER_W)
            for rid in ROBOT_IDS
        ]
        avg_snr = sum(snr_vals) / len(snr_vals)

        # Stage 3a -- UCB selects alpha
        state               = make_state(pc_smooth_pairs, priorities, avg_snr)
        alpha, action_idx, is_explore = self.ucb.select(state)

        # Compute allocation with chosen alpha
        rbs          = self._allocate_rbs(priorities, per_robot_pc, alpha)
        failsafe_used = False

        # Sanity: every robot must get >= 1 RB
        if any(v < MIN_RB_PER_ROBOT for v in rbs.values()):
            rbs           = self._allocate_rbs(priorities, per_robot_pc, 1.0)
            action_idx    = _HEURISTIC_ACTION_IDX
            failsafe_used = True

        # Stage 3b -- per-robot MCS (using actual allocated RBs)
        mcs     = {}
        snr_act = {}
        for rid in ROBOT_IDS:
            x, y          = positions[rid]
            snr_act[rid]  = estimate_snr_db(x, y, rbs[rid], TX_POWER_W)
            mcs[rid]      = self._select_mcs(per_robot_pc[rid], snr_act[rid])

        # Stage 4 -- command + deadlock resolver (inherited)
        cmds = {rid: self._select_command(per_robot_pc[rid]) for rid in ROBOT_IDS}
        cmds = self._resolve_deadlock(cmds, priorities)

        # Stage 5 -- multi-symbol downlink chain (inherited)
        chain_out = {}
        for rid in ROBOT_IDS:
            x, y = positions[rid]
            chain_out[rid] = self._downlink_chain(
                cmds[rid], mcs[rid], rbs[rid], x, y)

        # Stage 5b -- compute reward and update UCB
        crc_dict = {rid: bool(chain_out[rid][1]) for rid in ROBOT_IDS}
        snr_dict = {rid: chain_out[rid][2]       for rid in ROBOT_IDS}
        lat_dict = {rid: chain_out[rid][4]       for rid in ROBOT_IDS}

        reward = _compute_reward(
            max_pc        = max_pc_global,
            per_robot_pc  = per_robot_pc,
            priorities    = priorities,
            rbs           = rbs,
            mcs_dict      = mcs,
            crc_dict      = crc_dict,
            snr_dict      = snr_dict,
            lat_dict      = lat_dict,
            stop_ctrs     = self._stop_ctr,
        )
        if not failsafe_used:
            self.ucb.update(state, action_idx, reward)

        # Stage 6 -- actuation decision (inherited)
        act = {}
        for rid in ROBOT_IDS:
            dec_cmd, crc_pass, _, _, _, _ = chain_out[rid]
            act[rid] = self._actuation_decision(
                rid, dec_cmd, crc_pass, per_robot_pc[rid])

        # ---- Build result dict ----
        result = {
            "max_pc_global":     round(max_pc_global, 4),
            "n_high_risk_pairs": n_high_risk,
        }
        for rid in ROBOT_IDS:
            i = rid.split("_")[1]
            dec_cmd, crc_pass, avg_snr_r, n_sym, lat, h_eff = chain_out[rid]
            result[f"pc_smooth_{i}"]  = round(per_robot_pc[rid], 4)
            result[f"rb_{i}"]         = rbs[rid]
            result[f"mcs_{i}"]        = mcs[rid]
            result[f"mcs_name_{i}"]   = {MCS_QPSK: "QPSK",
                                          MCS_16QAM: "16-QAM",
                                          MCS_64QAM: "64-QAM"}[mcs[rid]]
            result[f"snr_{i}_dB"]     = round(snr_dict[rid], 2)
            result[f"cmd_{i}"]        = cmds[rid]
            result[f"crc_{i}"]        = int(crc_pass)
            result[f"actuation_{i}"]  = act[rid]
            result[f"n_sym_{i}"]      = n_sym
            result[f"latency_{i}_us"] = round(lat, 2)

        # RL diagnostic keys
        result.update({
            "rl_state":       str(state),
            "rl_action":      alpha,
            "rl_reward":      round(reward, 4),
            "rl_explore":     -1 if failsafe_used else int(is_explore),
            "rl_q_best":      round(self.ucb.best_q(state), 4),
            "rl_total_steps": self.ucb.total_steps,
        })
        return result

    # ------------------------------------------------------------------
    def _safe_default(self) -> dict:
        base = super()._safe_default()
        base.update({
            "rl_state":       "(-,-,-,-)",
            "rl_action":      1.0,
            "rl_reward":      0.0,
            "rl_explore":     -1,
            "rl_q_best":      0.0,
            "rl_total_steps": self.ucb.total_steps,
        })
        return base
