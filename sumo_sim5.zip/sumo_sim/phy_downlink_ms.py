"""
phy_downlink_ms.py -- Multi-Symbol Task-Aware Downlink PHY Pipeline
====================================================================
Drop-in replacement for phy_downlink.py with three key changes:

  1. TOTAL_RBS = 7  (down from 52)
     Priority-proportional allocation gives:
       p=3 vs p=1  ->  5 vs 2 RBs (60 vs 24 SCs)
       p=3 vs p=2  ->  4 vs 3 RBs (48 vs 36 SCs)
     All allocations stay <= 5 RBs = 60 SCs < N_FFT-1 = 63  (no cap hit).

     NOTE: TOTAL_RBS = 5 would always produce a 3+2 split regardless of
     priority, giving BOTH robots 2 OFDM symbols at 80-bit payload --
     zero latency differentiation.  TOTAL_RBS = 7 is the minimum that
     allows a >=4 RB vs <=3 RB split, creating the 1-symbol vs 2-symbol gap.

  2. Payload = 80 bits  (2 cmd + 8 CRC + 70 zero pad; was 10 bits)
     QPSK latency table (40 QAM symbols):
       5 RBs (60 SCs): ceil(40/60) = 1 symbol  ->  83.3 us
       4 RBs (48 SCs): ceil(40/48) = 1 symbol  ->  83.3 us
       3 RBs (36 SCs): ceil(40/36) = 2 symbols -> 166.7 us
       2 RBs (24 SCs): ceil(40/24) = 2 symbols -> 166.7 us
     With 16-QAM (20 symbols) or 64-QAM (~14 symbols) the packet always
     fits in 1 OFDM symbol for any RB allocation -- latency differentiation
     is strongest when QPSK is forced (i.e., during collision events).

  3. TX_POWER_W = 0.01 W  (10 mW; was 1 W)
     Rayleigh deep fades now occasionally drop instantaneous SNR below the
     QPSK demodulation threshold, producing realistic CRC failures
     (~2-6% per packet at mid-factory distances of 60-100 m).

Fallback: set  USE_MULTISYM = False  in run_sim.py to revert to
phy_downlink.py (original 52-RB / 1-symbol / 1 W system), unchanged.
"""

import math
import numpy as np

from channel_model import apply_channel, estimate_snr_db


# ============================================================================
#  TUNABLE CONSTANTS
# ============================================================================

# --- Payload ---
PAD_BITS     = 150
PAYLOAD_BITS = 2 + 8 + PAD_BITS           # 160 bits total

# --- OFDM / latency ---
N_FFT    = 64
CP_LEN   = 16
FRAME_LEN = N_FFT + CP_LEN               # 80 samples per OFDM symbol
SCS_HZ   = 15_000                        # subcarrier spacing (NR numerology mu=0)
# T_SYM = 80 / (15000 * 64) = 83.333... us
T_SYM_US = FRAME_LEN / (SCS_HZ * N_FFT) * 1_000_000

# --- RF ---
TX_POWER_W = 0.01                        # 10 mW (reduced for realistic CRC fails)

# --- Collision probability ---
TAU_LOOKAHEAD_S  = 2.0
D_DANGER_M       = 10.0
EMA_ALPHA        = 0.3

# --- RB pool ---
TOTAL_RBS                 = 7
COLLISION_BOOST_THRESHOLD = 0.5

# --- MCS thresholds (unchanged from phy_downlink.py) ---
P_C_QPSK_THRESH  = 0.6
P_C_16QAM_THRESH = 0.3
SNR_64QAM_MIN_DB = 20.0
SNR_QPSK_MAX_DB  = 15.0

MCS_QPSK   = 0
MCS_16QAM  = 1
MCS_64QAM  = 2
MCS_NAMES  = {MCS_QPSK: "QPSK", MCS_16QAM: "16-QAM", MCS_64QAM: "64-QAM"}

# --- Command thresholds ---
P_STOP = 0.65
P_SLOW = 0.30

CMD_CONTINUE = "CONTINUE"
CMD_SLOW     = "SLOW"
CMD_STOP     = "STOP"

CMD_BITS = {CMD_CONTINUE: [0, 0], CMD_SLOW: [0, 1], CMD_STOP: [1, 0]}

# --- Hysteresis ---
HYSTERESIS_COUNT = 5
MAX_STOP_STEPS   = 40

# --- TraCI speed settings ---
SPEED_MAX  = 13.89
SPEED_SLOW = 1.0
SPEED_STOP = 0.0

# --- CRC ---
CRC_POLY = 0x07
CRC_BITS = 8


# ============================================================================
#  CRC-8  (identical to phy_downlink.py)
# ============================================================================

def _crc8(bits: list) -> list:
    padded = bits + [0] * ((-len(bits)) % 8)
    crc = 0x00
    for i in range(0, len(padded), 8):
        byte = 0
        for b in padded[i:i+8]:
            byte = (byte << 1) | int(b)
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ CRC_POLY) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return [(crc >> (7 - i)) & 1 for i in range(8)]


def _crc8_check(payload_bits: list, received_crc_bits: list) -> bool:
    return _crc8(payload_bits) == list(received_crc_bits)


# ============================================================================
#  Modulation / Demodulation  (identical to phy_downlink.py)
# ============================================================================

def _bits_to_qam_symbols(bits: list, mcs: int) -> np.ndarray:
    if mcs == MCS_QPSK:
        bps   = 2
        const = {(0,0):  1+1j, (0,1): -1+1j, (1,0):  1-1j, (1,1): -1-1j}
        scale = 1.0 / math.sqrt(2)
    elif mcs == MCS_16QAM:
        bps    = 4
        levels = {(0,0): -3, (0,1): -1, (1,1):  1, (1,0):  3}
        scale  = 1.0 / math.sqrt(10)
    else:
        bps   = 6
        _g    = {(0,0,0): -7, (0,0,1): -5, (0,1,1): -3, (0,1,0): -1,
                 (1,1,0):  1, (1,1,1):  3, (1,0,1):  5, (1,0,0):  7}
        scale = 1.0 / math.sqrt(42)

    pad  = (-len(bits)) % bps
    bits = bits + [0] * pad

    symbols = []
    for i in range(0, len(bits), bps):
        chunk = tuple(bits[i:i+bps])
        if mcs == MCS_QPSK:
            s = const[chunk]
        elif mcs == MCS_16QAM:
            re = levels[chunk[:2]];  im = levels[chunk[2:]]
            s  = complex(re, im)
        else:
            re = _g[chunk[:3]];  im = _g[chunk[3:]]
            s  = complex(re, im)
        symbols.append(s * scale)

    return np.array(symbols, dtype=complex)


def _qam_symbols_to_bits(symbols: np.ndarray, mcs: int,
                         n_payload_bits: int) -> list:
    if mcs == MCS_QPSK:
        bps   = 2
        pts   = np.array([ 1+1j, -1+1j,  1-1j, -1-1j]) / math.sqrt(2)
        codes = [(0,0), (0,1), (1,0), (1,1)]
    elif mcs == MCS_16QAM:
        scale = 1.0 / math.sqrt(10)
        lvs   = [-3, -1, 1, 3]
        lcodes= [(0,0), (0,1), (1,1), (1,0)]
        pts   = np.array([complex(r, i)*scale for r in lvs for i in lvs])
        codes = [(rc + ic) for rc in lcodes for ic in lcodes]
    else:
        scale = 1.0 / math.sqrt(42)
        lvs   = [-7, -5, -3, -1, 1, 3, 5, 7]
        lcodes= [(0,0,0), (0,0,1), (0,1,1), (0,1,0),
                 (1,1,0), (1,1,1), (1,0,1), (1,0,0)]
        pts   = np.array([complex(r, i)*scale for r in lvs for i in lvs])
        codes = [(rc + ic) for rc in lcodes for ic in lcodes]

    bits = []
    for s in symbols:
        dists = np.abs(pts - s)
        idx   = int(np.argmin(dists))
        bits.extend(codes[idx])

    return bits[:n_payload_bits]


# ============================================================================
#  OFDM framing  (identical to phy_downlink.py)
# ============================================================================

def _subcarrier_indices(n_rbs: int, n_fft: int = N_FFT) -> np.ndarray:
    n_sc  = n_rbs * 12
    n_sc  = min(n_sc, n_fft - 1)    # safety cap (DC removed); not hit for n_rbs <= 5
    half  = n_fft // 2
    upper = np.arange(1, half + 1)
    lower = np.arange(n_fft - 1, half - 1, -1)
    interleaved           = np.empty(len(upper) + len(lower), dtype=int)
    interleaved[0::2]     = upper[:len(upper)]
    interleaved[1::2]     = lower[:len(lower)]
    return interleaved[:n_sc]


def _ofdm_modulate(symbols: np.ndarray, sc_indices: np.ndarray,
                   n_fft: int = N_FFT, cp_len: int = CP_LEN) -> np.ndarray:
    freq_domain = np.zeros(n_fft, dtype=complex)
    n_syms = min(len(symbols), len(sc_indices))
    freq_domain[sc_indices[:n_syms]] = symbols[:n_syms]
    time_domain = np.fft.ifft(freq_domain)
    cp           = time_domain[-cp_len:]
    return np.concatenate([cp, time_domain])


def _ofdm_demodulate(rx_signal: np.ndarray, h: complex,
                     sc_indices: np.ndarray,
                     n_fft: int = N_FFT, cp_len: int = CP_LEN) -> np.ndarray:
    time_domain = rx_signal[cp_len:]
    freq_domain = np.fft.fft(time_domain)
    if abs(h) < 1e-9:
        h = 1e-9 + 0j
    equalised   = freq_domain / h
    return equalised[sc_indices]


# ============================================================================
#  Velocity helper  (identical to phy_downlink.py)
# ============================================================================

def speed_angle_to_velocity(speed: float, angle_deg: float):
    angle_rad = math.radians(angle_deg)
    vx =  speed * math.sin(angle_rad)
    vy =  speed * math.cos(angle_rad)
    return vx, vy


# ============================================================================
#  DownlinkPHY  -- multi-symbol version
# ============================================================================

class DownlinkPHY:
    """
    Stateful downlink PHY controller for the 2-robot factory simulation.
    Identical interface to phy_downlink.DownlinkPHY; result dict has four
    additional keys: n_sym_0, n_sym_1, latency_0_us, latency_1_us.
    """

    def __init__(self):
        self._pc_smooth = {"robot_0": 0.0, "robot_1": 0.0}
        self._hyst_cnt  = {"robot_0": 0,   "robot_1": 0}
        self._stop_ctr  = {"robot_0": 0,   "robot_1": 0}
        self._sc_cache  = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_sc_indices(self, n_rbs: int) -> np.ndarray:
        if n_rbs not in self._sc_cache:
            self._sc_cache[n_rbs] = _subcarrier_indices(n_rbs)
        return self._sc_cache[n_rbs]

    # ------------------------------------------------------------------
    # Stage 2 -- Collision probability  (unchanged)
    # ------------------------------------------------------------------

    def _collision_probability(self, pos: dict, vel: dict) -> tuple:
        x0, y0 = pos["robot_0"];  x1, y1 = pos["robot_1"]
        vx0, vy0 = vel["robot_0"];  vx1, vy1 = vel["robot_1"]
        tau  = TAU_LOOKAHEAD_S
        fx0, fy0 = x0 + vx0*tau, y0 + vy0*tau
        fx1, fy1 = x1 + vx1*tau, y1 + vy1*tau
        d_pred = math.sqrt((fx0-fx1)**2 + (fy0-fy1)**2)
        pc_raw = max(0.0, min(1.0 - d_pred / D_DANGER_M, 1.0))
        for rid in ("robot_0", "robot_1"):
            self._pc_smooth[rid] = (EMA_ALPHA * pc_raw
                                    + (1.0 - EMA_ALPHA) * self._pc_smooth[rid])
        return pc_raw, dict(self._pc_smooth)

    # ------------------------------------------------------------------
    # Stage 3 -- RB allocation + MCS  (unchanged logic, new TOTAL_RBS)
    # ------------------------------------------------------------------

    @staticmethod
    def _allocate_rbs(p0: int, p1: int, pc_smooth: float) -> tuple:
        if pc_smooth > COLLISION_BOOST_THRESHOLD:
            # Near-equal split during collision, but higher-priority robot
            # keeps the ceiling half (extra RB from odd TOTAL_RBS) so that
            # its avoidance command still arrives with lower latency.
            half_lo = TOTAL_RBS // 2
            half_hi = TOTAL_RBS - half_lo
            return (half_hi, half_lo) if p0 >= p1 else (half_lo, half_hi)
        denom = p0 + p1 if (p0 + p1) > 0 else 1
        rb_0  = math.floor(TOTAL_RBS * p0 / denom)
        rb_0  = max(1, min(rb_0, TOTAL_RBS - 1))
        return rb_0, TOTAL_RBS - rb_0

    @staticmethod
    def _select_mcs(pc_smooth: float, snr_db: float) -> int:
        if pc_smooth > P_C_QPSK_THRESH or snr_db < SNR_QPSK_MAX_DB:
            return MCS_QPSK
        if pc_smooth > P_C_16QAM_THRESH:
            return MCS_16QAM
        if snr_db >= SNR_64QAM_MIN_DB:
            return MCS_64QAM
        return MCS_16QAM

    # ------------------------------------------------------------------
    # Stage 4 -- Command selection  (unchanged)
    # ------------------------------------------------------------------

    @staticmethod
    def _select_command(pc_smooth: float) -> str:
        if pc_smooth >= P_STOP:
            return CMD_STOP
        if pc_smooth >= P_SLOW:
            return CMD_SLOW
        return CMD_CONTINUE

    # ------------------------------------------------------------------
    # Stage 5 -- Multi-symbol downlink chain  (NEW)
    # ------------------------------------------------------------------

    def _downlink_chain(self, command: str, mcs: int,
                        n_rbs: int, x: float, y: float):
        """
        Multi-symbol OFDM downlink chain for one robot.

        Payload = 2-bit cmd + 8-bit CRC + 70 zero pad = 80 bits total.
        QAM symbols needed: QPSK->40, 16QAM->20, 64QAM->14 (approx).
        n_sym = ceil(n_qam / n_sc)  where n_sc = n_rbs * 12.

        Each OFDM time symbol gets a fresh independent Rayleigh fade
        (coherence time ~2.5 ms >> step_length 100 ms is NOT the case,
        but each OFDM symbol is separated by ~83 us, and a moving robot
        at 5 m/s has a coherence time of ~2.5 ms, so multiple symbols
        within one step share the same fade. We draw one h per symbol
        as a conservative model; real behaviour is between the extremes.)

        CRC is checked on the first 10 decoded bits (cmd + CRC).
        The 70 pad bits are transmitted but ignored at the receiver.

        Returns
        -------
        decoded_cmd  : str or None
        crc_pass     : bool
        avg_snr_db   : float   -- average SNR across all OFDM time symbols
        n_sym        : int     -- number of OFDM time symbols used
        latency_us   : float   -- n_sym * T_SYM_US
        h_first      : complex -- channel coeff from first OFDM symbol (logging)
        """
        # ---- Build 80-bit payload ----
        cmd_bits_list = CMD_BITS[command]
        crc_bits_list = _crc8(cmd_bits_list)
        payload       = cmd_bits_list + crc_bits_list + [0] * PAD_BITS   # 80 bits

        # ---- Modulate to QAM symbols ----
        qam_symbols = _bits_to_qam_symbols(payload, mcs)
        n_qam       = len(qam_symbols)
        # QPSK:  40 symbols | 16QAM: 20 symbols | 64QAM: ~14 symbols

        # ---- Subcarrier assignment ----
        sc_indices = self._get_sc_indices(n_rbs)
        n_sc       = len(sc_indices)    # n_rbs * 12; max 60 for n_rbs=5, no cap

        # ---- Multi-symbol scheduling ----
        n_sym = math.ceil(n_qam / n_sc)

        # Zero-pad to fill exactly n_sym * n_sc slots
        qam_padded         = np.zeros(n_sym * n_sc, dtype=complex)
        qam_padded[:n_qam] = qam_symbols

        # ---- Transmit + receive loop ----
        all_rx_syms = []
        snr_list    = []
        h_first     = 1 + 0j

        for i in range(n_sym):
            chunk     = qam_padded[i * n_sc : (i + 1) * n_sc]
            tx_signal = _ofdm_modulate(chunk, sc_indices)

            # Fresh Rayleigh tap per OFDM symbol (independent fade model)
            rx_signal, h_eff, snr_db = apply_channel(
                tx_signal, x, y, n_rbs, TX_POWER_W)

            rx_syms = _ofdm_demodulate(rx_signal, h_eff, sc_indices)
            all_rx_syms.extend(rx_syms)
            snr_list.append(snr_db)

            if i == 0:
                h_first = h_eff

        # ---- Demap: only the first n_qam symbols carry real payload ----
        rx_bits = _qam_symbols_to_bits(
            np.array(all_rx_syms[:n_qam]), mcs, len(payload))

        # ---- CRC check on cmd + CRC bits (first 10 bits) only ----
        rx_cmd_bits = rx_bits[:2]
        rx_crc_bits = rx_bits[2:10]
        crc_pass    = _crc8_check(rx_cmd_bits, rx_crc_bits)

        decoded_cmd = None
        if crc_pass:
            rev_map     = {tuple(v): k for k, v in CMD_BITS.items()}
            decoded_cmd = rev_map.get(tuple(int(b) for b in rx_cmd_bits), None)

        avg_snr_db = float(np.mean(snr_list))
        latency_us = n_sym * T_SYM_US

        return decoded_cmd, crc_pass, avg_snr_db, n_sym, latency_us, h_first

    # ------------------------------------------------------------------
    # Stage 6 -- Actuation decision  (unchanged)
    # ------------------------------------------------------------------

    def _actuation_decision(self, rid: str, decoded_cmd,
                             crc_pass: bool, pc_smooth: float) -> str:
        if crc_pass and decoded_cmd is not None:
            effective = decoded_cmd
        else:
            effective = CMD_STOP if pc_smooth > COLLISION_BOOST_THRESHOLD else CMD_SLOW

        if effective == CMD_STOP:
            self._stop_ctr[rid] += 1
            if self._stop_ctr[rid] > MAX_STOP_STEPS:
                self._stop_ctr[rid] = 0
                self._hyst_cnt[rid] = 0
                effective = CMD_SLOW
        else:
            self._stop_ctr[rid] = 0

        if effective == CMD_STOP:
            self._hyst_cnt[rid] = 0
        elif effective == CMD_CONTINUE:
            self._hyst_cnt[rid] += 1
            if self._hyst_cnt[rid] < HYSTERESIS_COUNT:
                effective = CMD_SLOW
        return effective

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def step(self, positions: dict, velocities: dict, priorities: dict) -> dict:
        """
        Run one complete downlink PHY step for both robots.

        Identical signature to phy_downlink.DownlinkPHY.step().
        Result dict contains all original keys PLUS:
            n_sym_0, n_sym_1        int    OFDM time symbols used per robot
            latency_0_us, latency_1_us  float  packet latency in microseconds
        """
        for rid in ("robot_0", "robot_1"):
            if rid not in positions or rid not in velocities:
                return self._safe_default()

        # Stage 2
        pc_raw, pc_smooth = self._collision_probability(positions, velocities)
        pc0 = pc_smooth["robot_0"]
        pc1 = pc_smooth["robot_1"]
        pc_alloc = max(pc0, pc1)

        # Stage 3
        p0  = priorities.get("robot_0", 1)
        p1  = priorities.get("robot_1", 1)
        rb_0, rb_1 = self._allocate_rbs(p0, p1, pc_alloc)

        x0, y0 = positions["robot_0"]
        x1, y1 = positions["robot_1"]
        snr_est_0 = estimate_snr_db(x0, y0, rb_0, TX_POWER_W)
        snr_est_1 = estimate_snr_db(x1, y1, rb_1, TX_POWER_W)

        mcs_0 = self._select_mcs(pc0, snr_est_0)
        mcs_1 = self._select_mcs(pc1, snr_est_1)

        # Stage 4
        cmd_0 = self._select_command(pc0)
        cmd_1 = self._select_command(pc1)
        if cmd_0 == CMD_STOP and cmd_1 == CMD_STOP:
            if p0 >= p1:
                cmd_1 = CMD_SLOW
            else:
                cmd_0 = CMD_SLOW

        # Stage 5 -- multi-symbol downlink chain
        dec_cmd_0, crc_pass_0, snr_0, n_sym_0, lat_0, h_0 = self._downlink_chain(
            cmd_0, mcs_0, rb_0, x0, y0)
        dec_cmd_1, crc_pass_1, snr_1, n_sym_1, lat_1, h_1 = self._downlink_chain(
            cmd_1, mcs_1, rb_1, x1, y1)

        # Stage 6
        act_0 = self._actuation_decision("robot_0", dec_cmd_0, crc_pass_0, pc0)
        act_1 = self._actuation_decision("robot_1", dec_cmd_1, crc_pass_1, pc1)

        return {
            "pc_raw":       round(pc_raw, 4),
            "pc_smooth_0":  round(pc0, 4),
            "pc_smooth_1":  round(pc1, 4),
            "rb_0":         rb_0,
            "rb_1":         rb_1,
            "mcs_0":        mcs_0,
            "mcs_1":        mcs_1,
            "mcs_name_0":   MCS_NAMES[mcs_0],
            "mcs_name_1":   MCS_NAMES[mcs_1],
            "snr_0_dB":     round(snr_0, 2),
            "snr_1_dB":     round(snr_1, 2),
            "cmd_0":        cmd_0,
            "cmd_1":        cmd_1,
            "crc_0":        int(crc_pass_0),
            "crc_1":        int(crc_pass_1),
            "actuation_0":  act_0,
            "actuation_1":  act_1,
            "h_0":          h_0,
            "h_1":          h_1,
            # --- NEW keys ---
            "n_sym_0":      n_sym_0,
            "n_sym_1":      n_sym_1,
            "latency_0_us": round(lat_0, 2),
            "latency_1_us": round(lat_1, 2),
        }

    @staticmethod
    def _safe_default() -> dict:
        return {
            "pc_raw": 0.0, "pc_smooth_0": 0.0, "pc_smooth_1": 0.0,
            "rb_0": TOTAL_RBS // 2, "rb_1": TOTAL_RBS - TOTAL_RBS // 2,
            "mcs_0": MCS_QPSK, "mcs_1": MCS_QPSK,
            "mcs_name_0": "QPSK", "mcs_name_1": "QPSK",
            "snr_0_dB": 0.0, "snr_1_dB": 0.0,
            "cmd_0": CMD_CONTINUE, "cmd_1": CMD_CONTINUE,
            "crc_0": 0, "crc_1": 0,
            "actuation_0": CMD_CONTINUE, "actuation_1": CMD_CONTINUE,
            "h_0": 1+0j, "h_1": 1+0j,
            "n_sym_0": 1, "n_sym_1": 1,
            "latency_0_us": round(T_SYM_US, 2),
            "latency_1_us": round(T_SYM_US, 2),
        }


# ============================================================================
#  TraCI actuation helper  (identical to phy_downlink.py)
# ============================================================================

def apply_actuation(traci, rid: str, actuation: str, step_length: float):
    try:
        active = traci.vehicle.getIDList()
        if rid not in active:
            return
        if actuation == CMD_STOP:
            traci.vehicle.setSpeed(rid, SPEED_STOP)
        elif actuation == CMD_SLOW:
            traci.vehicle.slowDown(rid, SPEED_SLOW, step_length)
        else:
            traci.vehicle.setSpeed(rid, -1)
    except Exception:
        pass
