"""
generate_plots.py
=================
Produces two publication-quality figures from robot_trajectories.csv:

  Figure 1 -- Robot Speed vs. Actuation Command
  Figure 2 -- Network Throughput vs. Time

Run: python generate_plots.py
Outputs: figure1_speed_actuation.png, figure2_throughput.png
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------

CSV_PATH = "robot_trajectories.csv"
df = pd.read_csv(CSV_PATH)

# Drop rows with NaN in key columns (can occur on first/last step)
df = df.dropna(subset=["robot_0_speed", "robot_1_speed", "mcs_0", "mcs_1",
                        "crc_0", "crc_1", "pc_smooth_0"]).reset_index(drop=True)

t = df["time"].values

# ---------------------------------------------------------------------------
# Derived columns
# ---------------------------------------------------------------------------

# Throughput per robot (bps): bits carried per 0.1s step / 0.1
BPS = {0: 1260.0, 1: 2520.0, 2: 3780.0}   # QPSK / 16-QAM / 64-QAM
df["tp_0"] = df["mcs_0"].map(BPS) * df["crc_0"]
df["tp_1"] = df["mcs_1"].map(BPS) * df["crc_1"]
df["tp_sys"] = df["tp_0"] + df["tp_1"]          # system total (bps)
df["tp_sys_kbps"] = df["tp_sys"] / 1e3

# MCS label for colouring
MCS_LABEL = {0: "QPSK", 1: "16-QAM", 2: "64-QAM"}
MCS_COLOR = {0: "#d62728", 1: "#ff7f0e", 2: "#2ca02c"}   # red / orange / green
ACT_COLOR = {"CONTINUE": "#2ca02c", "SLOW": "#ff7f0e", "STOP": "#d62728"}

# Apply a light rolling average to speeds for visual smoothing
WIN = 10   # 1-second smoothing window
df["spd0_sm"] = df["robot_0_speed"].rolling(WIN, min_periods=1, center=True).mean()
df["spd1_sm"] = df["robot_1_speed"].rolling(WIN, min_periods=1, center=True).mean()
df["pc_sm"]   = df["pc_smooth_0"].rolling(WIN, min_periods=1, center=True).mean()

# Zoom window: the main collision event
ZOOM_T0, ZOOM_T1 = 448.0, 522.4

# ---------------------------------------------------------------------------
# Helper: shade actuation-state bands along a time axis
# ---------------------------------------------------------------------------

def shade_actuation(ax, t_arr, act_arr, alpha=0.18, height=1.0):
    """Draw coloured background bands for each actuation state."""
    colors = {"CONTINUE": "#2ca02c", "SLOW": "#ff7f0e", "STOP": "#d62728"}
    i = 0
    while i < len(act_arr):
        state = act_arr[i]
        j = i
        while j < len(act_arr) and act_arr[j] == state:
            j += 1
        if state != "CONTINUE":   # only shade non-trivial states
            ax.axvspan(t_arr[i], t_arr[min(j, len(t_arr)-1)],
                       color=colors.get(state, "gray"), alpha=alpha, linewidth=0)
        i = j


def shade_mcs(ax, t_arr, mcs_arr, alpha=0.15):
    """Draw coloured background bands for each MCS tier."""
    col = {0: "#d62728", 1: "#ff7f0e", 2: "#2ca02c"}
    i = 0
    while i < len(mcs_arr):
        m = mcs_arr[i]
        j = i
        while j < len(mcs_arr) and mcs_arr[j] == m:
            j += 1
        if m < 2:   # only shade degraded MCS
            ax.axvspan(t_arr[i], t_arr[min(j, len(t_arr)-1)],
                       color=col.get(m, "gray"), alpha=alpha, linewidth=0)
        i = j


# ---------------------------------------------------------------------------
# FIGURE 1 -- Speed vs Actuation  (3-panel: full run + zoomed + pc_smooth)
# ---------------------------------------------------------------------------

STYLE = {
    "axes.spines.top":    False,
    "axes.spines.right":  False,
    "axes.grid":          True,
    "grid.linestyle":     "--",
    "grid.alpha":         0.4,
    "font.family":        "DejaVu Sans",
    "font.size":          10,
}

with plt.rc_context(STYLE):
    fig1, axes = plt.subplots(3, 1, figsize=(13, 10),
                               gridspec_kw={"height_ratios": [2, 2, 1.2],
                                            "hspace": 0.42})

    # ---- PANEL A: Robot 0 speed (full run) ---------------------------------
    ax = axes[0]
    shade_actuation(ax, t, df["actuation_0"].values)
    ax.plot(t, df["robot_0_speed"].values, color="#aec7e8", lw=0.6, alpha=0.7)
    ax.plot(t, df["spd0_sm"].values, color="#1f77b4", lw=1.6,
            label="Robot 0 (smoothed)")
    ax.set_xlim(t[0], t[-1])
    ax.set_ylim(-0.2, 15)
    ax.set_ylabel("Speed (m/s)", fontsize=10)
    ax.set_title("(a)  Robot 0 — Speed over Full Simulation Run", fontsize=11, fontweight="bold")
    ax.xaxis.set_minor_locator(MultipleLocator(10))
    # Actuation legend patches
    p_slow = mpatches.Patch(color="#ff7f0e", alpha=0.35, label="SLOW zone")
    p_stop = mpatches.Patch(color="#d62728", alpha=0.35, label="STOP zone")
    l0 = ax.legend(handles=[ax.lines[1], p_slow, p_stop],
                   loc="upper left", fontsize=9, framealpha=0.7)
    ax.add_artist(l0)
    # Annotate zoom region
    ax.axvspan(ZOOM_T0, ZOOM_T1, color="#9467bd", alpha=0.07, linewidth=0)
    ax.annotate("zoom", xy=((ZOOM_T0+ZOOM_T1)/2, 13.5), ha="center",
                fontsize=8, color="#9467bd", fontstyle="italic")

    # ---- PANEL B: Robot 1 speed (full run) ---------------------------------
    ax = axes[1]
    shade_actuation(ax, t, df["actuation_1"].values)
    ax.plot(t, df["robot_1_speed"].values, color="#ffbb78", lw=0.6, alpha=0.7)
    ax.plot(t, df["spd1_sm"].values, color="#d62728", lw=1.6,
            label="Robot 1 (smoothed)")
    ax.set_xlim(t[0], t[-1])
    ax.set_ylim(-0.2, 15)
    ax.set_ylabel("Speed (m/s)", fontsize=10)
    ax.set_title("(b)  Robot 1 — Speed over Full Simulation Run", fontsize=11, fontweight="bold")
    ax.xaxis.set_minor_locator(MultipleLocator(10))
    l1 = ax.legend(handles=[ax.lines[1], p_slow, p_stop],
                   loc="upper left", fontsize=9, framealpha=0.7)
    ax.add_artist(l1)
    ax.axvspan(ZOOM_T0, ZOOM_T1, color="#9467bd", alpha=0.07, linewidth=0)

    # ---- PANEL C: Zoomed collision event (both robots) ---------------------
    dz = df[(df["time"] >= ZOOM_T0) & (df["time"] <= ZOOM_T1)].reset_index(drop=True)
    tz = dz["time"].values

    ax = axes[2]
    shade_actuation(ax, tz, dz["actuation_0"].values, alpha=0.25)

    ax.plot(tz, dz["robot_0_speed"].values, color="#1f77b4", lw=1.8,
            label="Robot 0")
    ax.plot(tz, dz["robot_1_speed"].values, color="#d62728", lw=1.8,
            label="Robot 1", linestyle="--")

    # Secondary y-axis: collision probability
    ax2 = ax.twinx()
    ax2.plot(tz, dz["pc_smooth_0"].values, color="#9467bd", lw=1.4,
             linestyle=":", alpha=0.85, label="P$_c$ (smooth)")
    ax2.axhline(0.30, color="#ff7f0e", lw=0.9, linestyle="--", alpha=0.7)
    ax2.axhline(0.65, color="#d62728", lw=0.9, linestyle="--", alpha=0.7)
    ax2.annotate("SLOW thr.", xy=(ZOOM_T1, 0.30), xytext=(-4, 3),
                 textcoords="offset points", fontsize=7.5, color="#ff7f0e", ha="right")
    ax2.annotate("STOP thr.", xy=(ZOOM_T1, 0.65), xytext=(-4, 3),
                 textcoords="offset points", fontsize=7.5, color="#d62728", ha="right")
    ax2.set_ylim(-0.05, 1.05)
    ax2.set_ylabel("Collision Prob. $P_c$", fontsize=9, color="#9467bd")
    ax2.tick_params(axis="y", colors="#9467bd")
    ax2.spines["right"].set_visible(True)
    ax2.spines["right"].set_color("#9467bd")

    ax.set_xlim(ZOOM_T0, ZOOM_T1)
    ax.set_ylim(-0.2, 7)
    ax.set_xlabel("Simulation Time (s)", fontsize=10)
    ax.set_ylabel("Speed (m/s)", fontsize=10)
    ax.set_title("(c)  Zoomed Collision Event — Speed Response & Collision Probability",
                 fontsize=11, fontweight="bold")

    lines_left  = [Line2D([0],[0], color="#1f77b4", lw=1.8, label="Robot 0"),
                   Line2D([0],[0], color="#d62728", lw=1.8, ls="--", label="Robot 1")]
    lines_right = [Line2D([0],[0], color="#9467bd", lw=1.4, ls=":", label="$P_c$ (smooth)"),
                   p_slow, p_stop]
    ax.legend(handles=lines_left + lines_right, loc="upper left",
              fontsize=9, framealpha=0.75, ncol=2)

    fig1.suptitle("Robot Speed vs. Actuation Command\n"
                  "Task-Aware Dynamic Resource Allocation in Industrial Private 5G",
                  fontsize=13, fontweight="bold", y=0.98)

    fig1.savefig("figure1_speed_actuation.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig1)
    print("[OK] figure1_speed_actuation.png saved")


# ---------------------------------------------------------------------------
# FIGURE 2 -- Network Throughput vs. Time
# ---------------------------------------------------------------------------

with plt.rc_context(STYLE):
    fig2, axes2 = plt.subplots(2, 1, figsize=(13, 8),
                                gridspec_kw={"height_ratios": [2.5, 1.2],
                                             "hspace": 0.42})

    # ---- PANEL A: Throughput (full run) ------------------------------------
    ax = axes2[0]

    # Smooth throughput for readability
    tp_sm = df["tp_sys_kbps"].rolling(WIN, min_periods=1, center=True).mean()

    # Shade background by MCS tier (first robot drives the story; both robots same MCS here)
    shade_mcs(ax, t, df["mcs_0"].values.astype(int), alpha=0.18)

    # Per-robot throughput stacked fill
    tp0_kb = df["tp_0"] / 1e3
    tp1_kb = df["tp_1"] / 1e3
    ax.fill_between(t, 0, tp0_kb, alpha=0.30, color="#1f77b4", label="Robot 0 throughput")
    ax.fill_between(t, tp0_kb, tp0_kb + tp1_kb,
                    alpha=0.30, color="#d62728", label="Robot 1 throughput")

    ax.plot(t, tp_sm.values, color="#333333", lw=1.8, label="System total (smoothed)")

    # Annotate MCS tier lines
    ax.axhline(2 * 3.780, color="#2ca02c", lw=0.8, ls="--", alpha=0.6)
    ax.axhline(2 * 2.520, color="#ff7f0e", lw=0.8, ls="--", alpha=0.6)
    ax.axhline(2 * 1.260, color="#d62728", lw=0.8, ls="--", alpha=0.6)
    ax.annotate("Both 64-QAM  (7.56 kbps)", xy=(5, 2*3.780+0.08),
                fontsize=8, color="#2ca02c")
    ax.annotate("Both 16-QAM  (5.04 kbps)", xy=(5, 2*2.520+0.08),
                fontsize=8, color="#ff7f0e")
    ax.annotate("Both QPSK    (2.52 kbps)", xy=(5, 2*1.260+0.08),
                fontsize=8, color="#d62728")

    ax.set_xlim(t[0], t[-1])
    ax.set_ylim(-0.2, 9.5)
    ax.set_ylabel("Throughput (kbps)", fontsize=10)
    ax.set_title("(a)  Network Throughput — Full Simulation Run\n"
                 "Shaded regions indicate MCS degradation (orange=16-QAM, red=QPSK)",
                 fontsize=11, fontweight="bold")

    # MCS legend patches
    qam64_p = mpatches.Patch(color="#2ca02c", alpha=0.3, label="64-QAM region")
    qam16_p = mpatches.Patch(color="#ff7f0e", alpha=0.3, label="16-QAM region")
    qpsk_p  = mpatches.Patch(color="#d62728", alpha=0.3, label="QPSK region")
    ax.legend(handles=[ax.lines[0],
                       ax.collections[0], ax.collections[1],
                       qam16_p, qpsk_p],
              loc="lower right", fontsize=9, framealpha=0.75, ncol=2)

    ax.xaxis.set_minor_locator(MultipleLocator(10))
    ax.annotate("zoom", xy=((ZOOM_T0+ZOOM_T1)/2, 8.8), ha="center",
                fontsize=8, color="#9467bd", fontstyle="italic")
    ax.axvspan(ZOOM_T0, ZOOM_T1, color="#9467bd", alpha=0.07, linewidth=0)

    # ---- PANEL B: Zoomed throughput + distance + Pc -----------------------
    ax = axes2[1]

    shade_mcs(ax, tz, dz["mcs_0"].values.astype(int), alpha=0.22)

    tp_sys_z = (dz["tp_sys"] / 1e3).values
    ax.plot(tz, tp_sys_z, color="#333333", lw=1.8, label="System throughput")
    ax.fill_between(tz, 0, tp_sys_z, alpha=0.15, color="#333333")

    ax.set_xlim(ZOOM_T0, ZOOM_T1)
    ax.set_ylim(-0.2, 9.5)
    ax.set_xlabel("Simulation Time (s)", fontsize=10)
    ax.set_ylabel("Throughput (kbps)", fontsize=10)
    ax.set_title("(b)  Zoomed Collision Event — Throughput Degradation During Collision Risk",
                 fontsize=11, fontweight="bold")

    # Secondary axis: Pc and inter-robot distance
    ax3 = ax.twinx()
    ax3.plot(tz, dz["pc_smooth_0"].values, color="#9467bd", lw=1.4, ls=":",
             label="$P_c$ (smooth)", alpha=0.9)
    ax3.plot(tz, dz["inter_robot_distance"].values / 50.0, color="#8c564b",
             lw=1.2, ls="-.", alpha=0.7, label="Distance / 50 (norm.)")
    ax3.set_ylim(-0.05, 1.05)
    ax3.set_ylabel("$P_c$ / Normalised Distance", fontsize=9, color="#555")
    ax3.tick_params(axis="y", colors="#555")
    ax3.spines["right"].set_visible(True)

    lines_a = [Line2D([0],[0], color="#333333", lw=1.8, label="System throughput"),
               qam16_p, qpsk_p]
    lines_b = [Line2D([0],[0], color="#9467bd", lw=1.4, ls=":", label="$P_c$ (smooth)"),
               Line2D([0],[0], color="#8c564b", lw=1.2, ls="-.", alpha=0.8,
                      label="Distance / 50")]
    ax.legend(handles=lines_a + lines_b, loc="upper left",
              fontsize=9, framealpha=0.75, ncol=2)

    fig2.suptitle("Network Throughput vs. Time\n"
                  "MCS Adapts to Collision Risk — Throughput/Reliability Trade-off",
                  fontsize=13, fontweight="bold", y=0.98)

    fig2.savefig("figure2_throughput.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig2)
    print("[OK] figure2_throughput.png saved")

print("\nDone. Both figures saved in sumo_sim/")
