"""
generate_plots_rb.py
====================
Quantitative analysis of RB allocation, latency, MCS robustness, and
spectral efficiency from robot_trajectories.csv (USE_MULTISYM=True run).

Figures produced:
  Figure 3 -- Priority-driven RB allocation and latency (no-collision)
  Figure 4 -- MCS downgrade during collision: latency increase
  Figure 5 -- QPSK robustness vs higher-order MCS
  Figure 6 -- Additional RB allocation metrics

Run: python generate_plots_rb.py
Requires: robot_trajectories.csv generated with USE_MULTISYM=True
          (columns latency_0_us, latency_1_us, n_sym_0, n_sym_1 must exist)
"""

import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Constants (must match phy_downlink_ms.py)
# ---------------------------------------------------------------------------
PAYLOAD_BITS  = 160
T_SYM_US      = 80.0 / (15_000 * 64) * 1_000_000   # 83.333... us
BW_PER_RB_HZ  = 180_000.0                            # 12 SC * 15 kHz
TOTAL_RBS     = 7

MCS_LABEL = {0: "QPSK", 1: "16-QAM", 2: "64-QAM"}
MCS_COLOR  = {0: "#d62728", 1: "#ff7f0e", 2: "#2ca02c"}
MCS_ORDER  = [0, 1, 2]
MCS_NAMES  = ["QPSK", "16-QAM", "64-QAM"]

# Theoretical QAM symbol counts for 160-bit payload
N_QAM = {0: 80, 1: 40, 2: 27}   # QPSK / 16-QAM / 64-QAM

STYLE = {
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.grid":         True,
    "grid.linestyle":    "--",
    "grid.alpha":        0.4,
    "font.family":       "DejaVu Sans",
    "font.size":         10,
}

# ---------------------------------------------------------------------------
# Load and validate data
# ---------------------------------------------------------------------------
CSV_PATH = "robot_trajectories.csv"
df = pd.read_csv(CSV_PATH)

REQUIRED_COLS = ["latency_0_us", "latency_1_us", "n_sym_0", "n_sym_1"]
for col in REQUIRED_COLS:
    if col not in df.columns:
        sys.exit(
            f"ERROR: column '{col}' not found.\n"
            "Re-run simulation with USE_MULTISYM=True first.")

df = df.dropna(subset=[
    "robot_0_priority", "robot_1_priority",
    "rb_0", "rb_1", "mcs_0", "mcs_1",
    "snr_0_dB", "snr_1_dB",
    "crc_0", "crc_1",
    "latency_0_us", "latency_1_us",
    "pc_smooth_0",
]).reset_index(drop=True)

df["robot_0_priority"] = df["robot_0_priority"].astype(int)
df["robot_1_priority"] = df["robot_1_priority"].astype(int)
df["mcs_0"] = df["mcs_0"].astype(int)
df["mcs_1"] = df["mcs_1"].astype(int)
df["crc_0"] = df["crc_0"].astype(int)
df["crc_1"] = df["crc_1"].astype(int)

t = df["time"].values
print(f"Loaded {len(df):,} rows  ({t[0]:.1f}s -- {t[-1]:.1f}s)")

# ---------------------------------------------------------------------------
# Derived columns
# ---------------------------------------------------------------------------

# Priority pair label: always list as (p0, p1) from the CSV, no reordering,
# so robot identities are preserved in bar charts.
df["prio_pair"] = df.apply(
    lambda r: f"({int(r.robot_0_priority)},{int(r.robot_1_priority)})", axis=1)

# Spectral efficiency (bits/s/Hz) -- uses actual latency from simulation
#   SE = PAYLOAD_BITS / latency_s / (rb * BW_PER_RB_HZ)
df["se_0"] = (PAYLOAD_BITS
              / (df["latency_0_us"] * 1e-6)
              / (df["rb_0"] * BW_PER_RB_HZ))
df["se_1"] = (PAYLOAD_BITS
              / (df["latency_1_us"] * 1e-6)
              / (df["rb_1"] * BW_PER_RB_HZ))

# Effective throughput per RB (kbps/RB), CRC-pass only
df["tprb_0"] = np.where(
    df["crc_0"] == 1,
    PAYLOAD_BITS / (df["latency_0_us"] * 1e-6) / df["rb_0"] / 1000,
    np.nan)
df["tprb_1"] = np.where(
    df["crc_1"] == 1,
    PAYLOAD_BITS / (df["latency_1_us"] * 1e-6) / df["rb_1"] / 1000,
    np.nan)

# Jain's fairness index on RB allocation (2-element case)
#   J = (rb0 + rb1)^2 / (2*(rb0^2 + rb1^2))
df["jain"] = ((df["rb_0"] + df["rb_1"]) ** 2
              / (2 * (df["rb_0"] ** 2 + df["rb_1"] ** 2)))

# ---------------------------------------------------------------------------
# Subset filters
# ---------------------------------------------------------------------------
# No-collision: pc_smooth < 0.3 (CONTINUE territory, MCS selection unaffected
# by collision risk).
nc = df[df["pc_smooth_0"] < 0.3].copy()

# Collision-active: pc_smooth > 0.5 (collision boost region)
col = df[df["pc_smooth_0"] > 0.5].copy()

print(f"  No-collision rows (Pc<0.3): {len(nc):,}  "
      f"({100*len(nc)/len(df):.1f}%)")
print(f"  Collision rows (Pc>0.5):    {len(col):,}  "
      f"({100*len(col)/len(df):.1f}%)")

# ---------------------------------------------------------------------------
# Priority pair ordering (descending by p0 then p1)
# ---------------------------------------------------------------------------
all_pairs = df["prio_pair"].unique().tolist()
pair_order = sorted(
    all_pairs,
    key=lambda s: tuple(int(x) for x in s.strip("()").split(",")),
    reverse=True)

# ---------------------------------------------------------------------------
# Zoom window: first significant collision block +/- 20 s
# ---------------------------------------------------------------------------
coll_times = df[df["pc_smooth_0"] > 0.5]["time"].values
if len(coll_times) > 0:
    gaps = np.where(np.diff(coll_times) > 2.0)[0]
    block_end = coll_times[gaps[0]] if len(gaps) > 0 else coll_times[-1]
    zoom_t0 = max(coll_times[0] - 20, t[0])
    zoom_t1 = min(block_end + 20, t[-1])
else:
    zoom_t0, zoom_t1 = t[0], min(t[0] + 100.0, t[-1])

dz = df[(df["time"] >= zoom_t0) & (df["time"] <= zoom_t1)].reset_index(drop=True)
tz = dz["time"].values
print(f"  Zoom window: {zoom_t0:.1f}s -- {zoom_t1:.1f}s  ({len(dz):,} rows)")

# ---------------------------------------------------------------------------
# Helper: shade MCS tier bands along a time axis
# ---------------------------------------------------------------------------
def shade_mcs_bands(ax, t_arr, mcs_arr, alpha=0.15):
    """Shade background by MCS tier: red=QPSK, orange=16QAM, green=64QAM."""
    col_map = {0: "#d62728", 1: "#ff7f0e", 2: "#2ca02c"}
    i = 0
    mcs_arr = list(mcs_arr)
    while i < len(mcs_arr):
        m = int(mcs_arr[i])
        j = i
        while j < len(mcs_arr) and int(mcs_arr[j]) == m:
            j += 1
        ax.axvspan(t_arr[i], t_arr[min(j, len(t_arr) - 1)],
                   color=col_map.get(m, "gray"), alpha=alpha, linewidth=0)
        i = j

def shade_collision_bands(ax, t_arr, pc_arr, threshold=0.5, alpha=0.18,
                          color="#9467bd"):
    """Shade regions where pc_smooth > threshold."""
    above = (np.array(pc_arr) > threshold).astype(int)
    diffs = np.diff(above, prepend=0, append=0)
    starts = np.where(diffs == 1)[0]
    ends   = np.where(diffs == -1)[0]
    for s, e in zip(starts, ends):
        ax.axvspan(t_arr[min(s, len(t_arr)-1)],
                   t_arr[min(e, len(t_arr)-1)],
                   color=color, alpha=alpha, linewidth=0)


# ============================================================================
# FIGURE 3 -- Priority-Driven RB Allocation and Latency (No-Collision)
# ============================================================================
print("\nGenerating Figure 3 ...")

with plt.rc_context(STYLE):
    fig3, axes3 = plt.subplots(1, 3, figsize=(16, 5))
    fig3.suptitle(
        "Figure 3 — Priority-Driven RB Allocation and Latency   "
        "[No-Collision: $P_c < 0.3$]",
        fontsize=13, fontweight="bold", y=1.03)

    nc_grp = nc.groupby("prio_pair")
    valid_pairs = [p for p in pair_order if p in nc_grp.groups]
    x = np.arange(len(valid_pairs))
    W = 0.35

    # ---- Panel (a): Mean RBs per priority pair -------------------------
    ax = axes3[0]
    rb0_m = [nc_grp.get_group(p)["rb_0"].mean() for p in valid_pairs]
    rb1_m = [nc_grp.get_group(p)["rb_1"].mean() for p in valid_pairs]

    b0 = ax.bar(x - W/2, rb0_m, W, color="#1f77b4", alpha=0.85, label="Robot 0")
    b1 = ax.bar(x + W/2, rb1_m, W, color="#d62728", alpha=0.85, label="Robot 1")
    ax.axhline(TOTAL_RBS / 2, color="gray", ls="--", lw=0.9, alpha=0.6,
               label="Equal split (3.5)")

    for bar in list(b0) + list(b1):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.05,
                f"{h:.1f}", ha="center", va="bottom", fontsize=8.5)

    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"p0={p[1]}\np1={p[3]}" for p in valid_pairs], fontsize=9)
    ax.set_ylabel("Mean RBs Allocated")
    ax.set_ylim(0, TOTAL_RBS + 0.8)
    ax.set_yticks(range(TOTAL_RBS + 1))
    ax.set_title("(a)  RB Allocation by Priority Pair\n"
                 "Higher priority -> more RBs", fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)

    # ---- Panel (b): Mean latency per priority pair --------------------
    ax = axes3[1]
    lat0_m = [nc_grp.get_group(p)["latency_0_us"].mean() for p in valid_pairs]
    lat1_m = [nc_grp.get_group(p)["latency_1_us"].mean() for p in valid_pairs]

    b0 = ax.bar(x - W/2, lat0_m, W, color="#1f77b4", alpha=0.85, label="Robot 0")
    b1 = ax.bar(x + W/2, lat1_m, W, color="#d62728", alpha=0.85, label="Robot 1")

    # Theoretical n_sym reference lines (for dominant MCS = 16-QAM in
    # no-collision, no-low-SNR case; 40 QAM symbols)
    line_styles = ["-", "--", ":", "-."]
    for n_sym in [1, 2, 3, 4]:
        ax.axhline(n_sym * T_SYM_US, color="gray", lw=0.8, ls=line_styles[n_sym-1],
                   alpha=0.55)
        ax.text(len(valid_pairs) - 0.5 + 0.05, n_sym * T_SYM_US + 0.8,
                f"{n_sym} sym\n({n_sym*T_SYM_US:.0f} us)",
                fontsize=7, color="gray", va="bottom")

    for bar in list(b0) + list(b1):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.5,
                f"{h:.0f}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"p0={p[1]}\np1={p[3]}" for p in valid_pairs], fontsize=9)
    ax.set_ylabel("Mean Packet Latency (us)")
    ax.set_title("(b)  Packet Latency by Priority Pair\n"
                 "More RBs -> fewer OFDM symbols -> lower latency",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)

    # ---- Panel (c): Scatter RBs vs Latency + theoretical curves -------
    ax = axes3[2]

    rb_all  = np.concatenate([nc["rb_0"].values,        nc["rb_1"].values])
    lat_all = np.concatenate([nc["latency_0_us"].values, nc["latency_1_us"].values])
    mcs_all = np.concatenate([nc["mcs_0"].values,        nc["mcs_1"].values])

    for mcs_val in [2, 1, 0]:
        mask = mcs_all == mcs_val
        ax.scatter(rb_all[mask], lat_all[mask],
                   c=MCS_COLOR[mcs_val], alpha=0.15, s=5,
                   label=MCS_LABEL[mcs_val], rasterized=True)

    # Theoretical curves: n_sym = ceil(n_qam / (rb * 12)), lat = n_sym * T_SYM
    rb_range = np.arange(1, TOTAL_RBS + 1)
    for mcs_val in [0, 1, 2]:
        n_qam_v = N_QAM[mcs_val]
        lat_th = [int(np.ceil(n_qam_v / (r * 12))) * T_SYM_US for r in rb_range]
        ax.plot(rb_range, lat_th, color=MCS_COLOR[mcs_val], lw=2.2, ls="--",
                marker="D", markersize=5, zorder=5,
                label=f"{MCS_LABEL[mcs_val]} theory")

    ax.set_xlabel("RBs Allocated")
    ax.set_ylabel("Packet Latency (us)")
    ax.set_title("(c)  Latency vs RBs Allocated\n"
                 "Dashed = theoretical; dots = simulated",
                 fontweight="bold", fontsize=9)
    ax.set_xticks(range(1, TOTAL_RBS + 1))

    # Legend: separate scatter vs theory
    scatter_handles = [
        mpatches.Patch(color=MCS_COLOR[m], alpha=0.6, label=MCS_LABEL[m])
        for m in [0, 1, 2]]
    theory_handle = Line2D([0],[0], color="gray", lw=2, ls="--",
                           marker="D", markersize=5, label="Theory curves")
    ax.legend(handles=scatter_handles + [theory_handle], fontsize=8, loc="upper right")

    fig3.tight_layout()
    fig3.savefig("figure3_priority_rb_latency.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig3)
    print("[OK] figure3_priority_rb_latency.png")


# ============================================================================
# FIGURE 4 -- MCS Downgrade During Collision: Latency Increase
# ============================================================================
print("Generating Figure 4 ...")

# Per-MCS latency pools (both robots, full run)
lat_by_mcs = {}
for mcs_val in MCS_ORDER:
    l0 = df[df["mcs_0"] == mcs_val]["latency_0_us"].values
    l1 = df[df["mcs_1"] == mcs_val]["latency_1_us"].values
    lat_by_mcs[mcs_val] = np.concatenate([l0, l1])

with plt.rc_context(STYLE):
    fig4, axes4 = plt.subplots(1, 3, figsize=(16, 5))
    fig4.suptitle(
        "Figure 4 — MCS Downgrade During Collision: Latency Increase",
        fontsize=13, fontweight="bold", y=1.03)

    # ---- Panel (a): Zoomed time series: latency + Pc + MCS shading ----
    ax = axes4[0]
    shade_mcs_bands(ax, tz, dz["mcs_0"].values, alpha=0.18)

    ax.plot(tz, dz["latency_0_us"].values, color="#1f77b4", lw=1.8,
            label="Robot 0 latency")
    ax.plot(tz, dz["latency_1_us"].values, color="#d62728", lw=1.8, ls="--",
            label="Robot 1 latency")

    for n_sym in [1, 2, 3, 4]:
        ax.axhline(n_sym * T_SYM_US, color="gray", lw=0.7,
                   ls=["-","--",":","-."][n_sym-1], alpha=0.45)
        ax.text(tz[-1], n_sym * T_SYM_US + 0.5,
                f"{n_sym}s", fontsize=7, color="gray", ha="right")

    ax2 = ax.twinx()
    ax2.plot(tz, dz["pc_smooth_0"].values, color="#9467bd", lw=1.3, ls=":",
             alpha=0.85, label="$P_c$ smooth")
    ax2.axhline(0.30, color="#ff7f0e", lw=0.8, ls="--", alpha=0.6)
    ax2.axhline(0.60, color="#d62728", lw=0.8, ls="--", alpha=0.6)
    ax2.text(tz[2], 0.32, "16-QAM thr.", fontsize=7, color="#ff7f0e")
    ax2.text(tz[2], 0.62, "QPSK thr.", fontsize=7, color="#d62728")
    ax2.set_ylim(-0.05, 1.15)
    ax2.set_ylabel("$P_c$ (smooth)", fontsize=9, color="#9467bd")
    ax2.tick_params(axis="y", colors="#9467bd")
    ax2.spines["right"].set_visible(True)
    ax2.spines["right"].set_color("#9467bd")

    ax.set_xlabel("Simulation Time (s)")
    ax.set_ylabel("Packet Latency (us)")
    ax.set_title("(a)  Latency During Collision Event\n"
                 "Background: green=64QAM, orange=16QAM, red=QPSK",
                 fontweight="bold", fontsize=9)
    handles_l = [Line2D([0],[0], color="#1f77b4", lw=1.8, label="Robot 0"),
                 Line2D([0],[0], color="#d62728", lw=1.8, ls="--", label="Robot 1"),
                 Line2D([0],[0], color="#9467bd", lw=1.3, ls=":", label="$P_c$")]
    ax.legend(handles=handles_l, fontsize=8, loc="upper left")

    # ---- Panel (b): Box plots of latency by MCS tier ------------------
    ax = axes4[1]
    data_bp = [lat_by_mcs[m] for m in MCS_ORDER]
    counts   = [len(d) for d in data_bp]

    bp = ax.boxplot(
        data_bp,
        labels=[f"{MCS_LABEL[m]}\n(n={counts[i]:,})"
                for i, m in enumerate(MCS_ORDER)],
        patch_artist=True,
        medianprops=dict(color="black", lw=2.0),
        flierprops=dict(marker=".", markersize=2, alpha=0.3),
        showfliers=True,
    )
    for patch, m in zip(bp["boxes"], MCS_ORDER):
        patch.set_facecolor(MCS_COLOR[m])
        patch.set_alpha(0.65)

    for n_sym in [1, 2, 3, 4]:
        ax.axhline(n_sym * T_SYM_US, color="gray", lw=0.8,
                   ls=["-","--",":","-."][n_sym-1], alpha=0.5)
        ax.text(3.58, n_sym * T_SYM_US + 0.3,
                f"{n_sym} sym\n({n_sym*T_SYM_US:.0f}us)", fontsize=7,
                color="gray", va="bottom")

    ax.set_ylabel("Packet Latency (us)")
    ax.set_title("(b)  Latency Distribution by MCS Tier\n"
                 "QPSK forced during collision -> higher n_sym -> longer latency",
                 fontweight="bold", fontsize=9)

    # ---- Panel (c): CDF of latency per MCS tier -----------------------
    ax = axes4[2]
    for mcs_val in MCS_ORDER:
        data = lat_by_mcs[mcs_val]
        if len(data) == 0:
            continue
        srt = np.sort(data)
        cdf = np.arange(1, len(srt) + 1) / len(srt)
        ax.plot(srt, cdf, color=MCS_COLOR[mcs_val], lw=2.0,
                label=f"{MCS_LABEL[mcs_val]} (n={len(data):,})")

    for n_sym in [1, 2, 3, 4]:
        ax.axvline(n_sym * T_SYM_US, color="gray", lw=0.8,
                   ls=["-","--",":","-."][n_sym-1], alpha=0.5)
        ax.text(n_sym * T_SYM_US + 0.3, 0.04,
                f"{n_sym}s", fontsize=7, color="gray", rotation=90, va="bottom")

    ax.set_xlabel("Packet Latency (us)")
    ax.set_ylabel("CDF")
    ax.set_title("(c)  Latency CDF by MCS\n"
                 "QPSK tail extends to 2x-4x higher latency than 64-QAM",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)
    ax.set_ylim(0, 1.05)

    fig4.tight_layout()
    fig4.savefig("figure4_collision_latency.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig4)
    print("[OK] figure4_collision_latency.png")


# ============================================================================
# FIGURE 5 -- QPSK Robustness vs Higher-Order MCS
# ============================================================================
print("Generating Figure 5 ...")

with plt.rc_context(STYLE):
    fig5, axes5 = plt.subplots(1, 3, figsize=(15, 5))
    fig5.suptitle(
        "Figure 5 — QPSK Robustness vs Higher-Order MCS",
        fontsize=13, fontweight="bold", y=1.03)

    W = 0.35
    x3 = np.arange(3)

    # ---- Panel (a): CRC pass rate by MCS tier -------------------------
    ax = axes5[0]
    crc0 = [df[df["mcs_0"] == m]["crc_0"].mean() * 100 for m in MCS_ORDER]
    crc1 = [df[df["mcs_1"] == m]["crc_1"].mean() * 100 for m in MCS_ORDER]
    n0   = [int((df["mcs_0"] == m).sum()) for m in MCS_ORDER]
    n1   = [int((df["mcs_1"] == m).sum()) for m in MCS_ORDER]

    b0 = ax.bar(x3 - W/2, crc0, W, color="#1f77b4", alpha=0.85, label="Robot 0")
    b1 = ax.bar(x3 + W/2, crc1, W, color="#d62728", alpha=0.85, label="Robot 1")
    ax.set_xticks(x3)
    ax.set_xticklabels(MCS_NAMES)
    ax.set_ylabel("CRC Pass Rate (%)")
    ax.set_ylim(0, 108)
    ax.axhline(100, color="gray", lw=0.7, ls=":", alpha=0.5)
    ax.set_title("(a)  CRC Pass Rate by MCS Tier\n"
                 "QPSK: highest reliability (most robust to noise & fading)",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)

    for bar, rate, n in zip(list(b0), crc0, n0):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                f"{rate:.1f}%\n(n={n:,})", ha="center", va="bottom", fontsize=7.5)
    for bar, rate, n in zip(list(b1), crc1, n1):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                f"{rate:.1f}%\n(n={n:,})", ha="center", va="bottom", fontsize=7.5)

    # ---- Panel (b): SNR distribution by MCS tier ----------------------
    ax = axes5[1]
    snr_by_mcs = []
    for mcs_val in MCS_ORDER:
        s0 = df[df["mcs_0"] == mcs_val]["snr_0_dB"].values
        s1 = df[df["mcs_1"] == mcs_val]["snr_1_dB"].values
        snr_by_mcs.append(np.concatenate([s0, s1]))

    bp2 = ax.boxplot(
        snr_by_mcs,
        labels=MCS_NAMES,
        patch_artist=True,
        medianprops=dict(color="black", lw=2),
        flierprops=dict(marker=".", markersize=2, alpha=0.3),
        showfliers=False,
    )
    for patch, m in zip(bp2["boxes"], MCS_ORDER):
        patch.set_facecolor(MCS_COLOR[m])
        patch.set_alpha(0.65)

    # MCS SNR decision thresholds from phy_downlink_ms.py
    ax.axhline(15.0, color="#ff7f0e", lw=1.1, ls="--", alpha=0.8,
               label="SNR<15 -> QPSK forced")
    ax.axhline(20.0, color="#2ca02c", lw=1.1, ls="--", alpha=0.8,
               label="SNR>=20 -> 64-QAM eligible")

    ax.set_ylabel("Received SNR (dB)")
    ax.set_title("(b)  SNR Distribution by MCS Tier\n"
                 "QPSK is used at lower SNRs — yet still achieves high pass rate",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8, loc="upper left")

    # ---- Panel (c): CRC pass rate vs SNR bin, one curve per MCS ------
    ax = axes5[2]

    snr_all = np.concatenate([df["snr_0_dB"].values, df["snr_1_dB"].values])
    bins = np.linspace(np.nanpercentile(snr_all, 1),
                       np.nanpercentile(snr_all, 99), 22)
    bin_centers = (bins[:-1] + bins[1:]) / 2

    for mcs_val in MCS_ORDER:
        d0 = df[df["mcs_0"] == mcs_val][["snr_0_dB", "crc_0"]].rename(
            columns={"snr_0_dB": "snr", "crc_0": "crc"})
        d1 = df[df["mcs_1"] == mcs_val][["snr_1_dB", "crc_1"]].rename(
            columns={"snr_1_dB": "snr", "crc_1": "crc"})
        d = pd.concat([d0, d1], ignore_index=True)

        pass_rates = []
        for i in range(len(bins) - 1):
            sub = d[(d["snr"] >= bins[i]) & (d["snr"] < bins[i+1])]
            pass_rates.append(sub["crc"].mean() * 100 if len(sub) >= 10 else np.nan)

        ax.plot(bin_centers, pass_rates, color=MCS_COLOR[mcs_val], lw=2.0,
                marker="o", markersize=4, label=MCS_LABEL[mcs_val])

    ax.axhline(100, color="gray", lw=0.7, ls=":", alpha=0.5)
    ax.axvline(15.0, color="#ff7f0e", lw=0.9, ls="--", alpha=0.6,
               label="15 dB threshold")
    ax.axvline(20.0, color="#2ca02c", lw=0.9, ls="--", alpha=0.6,
               label="20 dB threshold")
    ax.set_xlabel("Received SNR (dB)")
    ax.set_ylabel("CRC Pass Rate (%)")
    ax.set_ylim(0, 105)
    ax.set_title("(c)  CRC Pass Rate vs SNR\n"
                 "QPSK remains near-100% at low SNR where 64-QAM degrades",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)

    fig5.tight_layout()
    fig5.savefig("figure5_qpsk_robustness.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig5)
    print("[OK] figure5_qpsk_robustness.png")


# ============================================================================
# FIGURE 6 -- Additional RB Allocation Metrics
# ============================================================================
print("Generating Figure 6 ...")

with plt.rc_context(STYLE):
    fig6, axes6 = plt.subplots(2, 2, figsize=(14, 10),
                                gridspec_kw={"hspace": 0.46, "wspace": 0.38})
    fig6.suptitle(
        "Figure 6 — Additional RB Allocation Metrics",
        fontsize=13, fontweight="bold", y=1.01)

    # ---- Panel (a): Spectral efficiency by MCS tier -------------------
    ax = axes6[0, 0]
    se_by_mcs = []
    for mcs_val in MCS_ORDER:
        s0 = df[df["mcs_0"] == mcs_val]["se_0"].values
        s1 = df[df["mcs_1"] == mcs_val]["se_1"].values
        se_by_mcs.append(np.concatenate([s0, s1]))

    bp3 = ax.boxplot(
        se_by_mcs,
        labels=MCS_NAMES,
        patch_artist=True,
        medianprops=dict(color="black", lw=2),
        flierprops=dict(marker=".", markersize=2, alpha=0.3),
        showfliers=False,
    )
    for patch, m in zip(bp3["boxes"], MCS_ORDER):
        patch.set_facecolor(MCS_COLOR[m])
        patch.set_alpha(0.65)

    # Annotate medians
    for i, mcs_val in enumerate(MCS_ORDER):
        med = float(np.median(se_by_mcs[i]))
        ax.text(i + 1, med, f" {med:.2f}", va="center", fontsize=8.5, color="black")

    ax.set_ylabel("Spectral Efficiency (bits/s/Hz)")
    ax.set_title("(a)  Spectral Efficiency by MCS Tier\n"
                 "64-QAM: more bits per Hz; QPSK: fewer but needed during collision",
                 fontweight="bold", fontsize=9)

    # ---- Panel (b): Jain's fairness index over time -------------------
    ax = axes6[0, 1]
    jain_sm = df["jain"].rolling(30, min_periods=1, center=True).mean()

    # Shade collision boost periods
    shade_collision_bands(ax, t, df["pc_smooth_0"].values,
                          threshold=0.5, alpha=0.20, color="#9467bd")

    ax.fill_between(t, df["jain"].values, alpha=0.10, color="#1f77b4")
    ax.plot(t, jain_sm.values, color="#1f77b4", lw=1.6, label="Fairness (smoothed)")

    # Expected values for each priority scenario
    scenarios = {
        "p3 vs p1\n(5+2 RBs)": (5, 2),
        "p3 vs p2\n(4+3 RBs)": (4, 3),
        "Equal\n(3+4 RBs)":    (3, 4),
        "Boost\n(4+3 RBs)":    (4, 3),
    }
    jain_ref = {
        label: (a + b)**2 / (2 * (a**2 + b**2))
        for label, (a, b) in scenarios.items()
    }
    colors_ref = ["#d62728", "#ff7f0e", "#2ca02c", "#9467bd"]
    for (label, j_val), c in zip(jain_ref.items(), colors_ref):
        ax.axhline(j_val, color=c, lw=0.9, ls="--", alpha=0.65,
                   label=f"{label}: J={j_val:.3f}")

    ax.set_xlim(t[0], t[-1])
    ax.set_ylim(0.75, 1.02)
    ax.set_xlabel("Simulation Time (s)")
    ax.set_ylabel("Jain's Fairness Index")
    ax.set_title("(b)  Jain's Fairness Index Over Time\n"
                 "Purple shading = collision boost active; dashed = expected values",
                 fontweight="bold", fontsize=9)
    collision_patch = mpatches.Patch(color="#9467bd", alpha=0.35,
                                     label="Collision boost ($P_c>0.5$)")
    ax.legend(fontsize=7.5, loc="lower right", ncol=2)

    # ---- Panel (c): RB allocation time series (zoomed) ----------------
    ax = axes6[1, 0]
    shade_collision_bands(ax, tz, dz["pc_smooth_0"].values,
                          threshold=0.5, alpha=0.22, color="#9467bd")

    ax.step(tz, dz["rb_0"].values, where="post", color="#1f77b4", lw=2.0,
            label="Robot 0 RBs")
    ax.step(tz, dz["rb_1"].values, where="post", color="#d62728", lw=2.0,
            ls="--", label="Robot 1 RBs")

    ax.axhline(TOTAL_RBS / 2, color="gray", lw=0.8, ls=":", alpha=0.5,
               label="Equal split (3.5)")

    ax2c = ax.twinx()
    ax2c.plot(tz, dz["pc_smooth_0"].values, color="#9467bd", lw=1.2, ls=":",
              alpha=0.75, label="$P_c$ smooth")
    ax2c.axhline(0.5, color="#9467bd", lw=0.7, ls="--", alpha=0.5)
    ax2c.set_ylim(-0.05, 1.15)
    ax2c.set_ylabel("$P_c$ (smooth)", fontsize=9, color="#9467bd")
    ax2c.tick_params(axis="y", colors="#9467bd")
    ax2c.spines["right"].set_visible(True)
    ax2c.spines["right"].set_color("#9467bd")

    ax.set_xlim(tz[0], tz[-1])
    ax.set_ylim(0, TOTAL_RBS + 0.5)
    ax.set_yticks(range(TOTAL_RBS + 1))
    ax.set_xlabel("Simulation Time (s)")
    ax.set_ylabel("RBs Allocated")
    ax.set_title("(c)  RB Allocation During Collision Event\n"
                 "Collision boost (purple) drives toward 4+3 equal split",
                 fontweight="bold", fontsize=9)
    handles_c = [
        Line2D([0],[0], color="#1f77b4", lw=2, label="Robot 0"),
        Line2D([0],[0], color="#d62728", lw=2, ls="--", label="Robot 1"),
        Line2D([0],[0], color="gray", lw=0.8, ls=":", label="Equal split"),
        mpatches.Patch(color="#9467bd", alpha=0.35, label="Boost ($P_c>0.5$)"),
    ]
    ax.legend(handles=handles_c, fontsize=8, loc="lower left")

    # ---- Panel (d): Throughput per RB by priority pair ----------------
    ax = axes6[1, 1]
    nc_grp = nc.groupby("prio_pair")
    valid_pairs_d = [p for p in pair_order if p in nc_grp.groups]
    x4 = np.arange(len(valid_pairs_d))

    tprb0_m, tprb1_m = [], []
    tprb0_e, tprb1_e = [], []
    for p in valid_pairs_d:
        g = nc_grp.get_group(p)
        v0 = g["tprb_0"].dropna()
        v1 = g["tprb_1"].dropna()
        tprb0_m.append(v0.mean() if len(v0) else 0)
        tprb1_m.append(v1.mean() if len(v1) else 0)
        tprb0_e.append(v0.std() / np.sqrt(max(len(v0),1)))
        tprb1_e.append(v1.std() / np.sqrt(max(len(v1),1)))

    b0 = ax.bar(x4 - W/2, tprb0_m, W, color="#1f77b4", alpha=0.85,
                yerr=tprb0_e, capsize=3, label="Robot 0")
    b1 = ax.bar(x4 + W/2, tprb1_m, W, color="#d62728", alpha=0.85,
                yerr=tprb1_e, capsize=3, label="Robot 1")

    ax.set_xticks(x4)
    ax.set_xticklabels(
        [f"p0={p[1]}\np1={p[3]}" for p in valid_pairs_d], fontsize=9)
    ax.set_ylabel("Throughput per RB (kbps/RB)")
    ax.set_title("(d)  Throughput per RB by Priority Pair\n"
                 "Error bars = std error; CRC-pass steps only",
                 fontweight="bold", fontsize=9)
    ax.legend(fontsize=8)

    for bar, val in zip(list(b0), tprb0_m):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    f"{val:.0f}", ha="center", va="bottom", fontsize=8)
    for bar, val in zip(list(b1), tprb1_m):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    f"{val:.0f}", ha="center", va="bottom", fontsize=8)

    fig6.savefig("figure6_rb_metrics.png", dpi=180, bbox_inches="tight",
                 facecolor="white")
    plt.close(fig6)
    print("[OK] figure6_rb_metrics.png")

print("\nDone. Figures 3-6 saved to sumo_sim/")
print("  figure3_priority_rb_latency.png")
print("  figure4_collision_latency.png")
print("  figure5_qpsk_robustness.png")
print("  figure6_rb_metrics.png")
