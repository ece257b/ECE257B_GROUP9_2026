@echo off
"C:\Users\soham\anaconda3\python.exe" "%~dp0run_sim.py"
pause
