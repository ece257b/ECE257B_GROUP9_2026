#!/usr/bin/env python3
"""
run_forced_collision.py
=======================
Headless SUMO simulation that forces frequent robot collisions by routing
both robots on opposing diagonal paths across the factory floor so they
meet head-on every trip.

  Robot 0: n_0_0 (loading, p=3)  <-->  n_4_4 (assembly, p=1)
  Robot 1: n_4_4 (assembly, p=1) <-->  n_0_0 (loading,  p=3)

Runs silently (no GUI) for SIM_DURATION_S seconds.
Outputs: collision_forced_trajectories.csv

Two extra columns vs the normal CSV:
  arrived_0 / arrived_1            1 if robot completed a workstation trip this step
  arrival_priority_0 / _1          priority of the just-completed workstation (else 0)
"""

import sys
import os
import math
import csv

SUMO_TOOLS = "C:/Program Files (x86)/Eclipse/Sumo/tools"
sys.path.insert(0, SUMO_TOOLS)

import traci
import traci.exceptions
import sumolib

from phy_downlink_ms import DownlinkPHY, apply_actuation, speed_angle_to_velocity

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
STEP_LENGTH    = 0.1        # seconds (must match factory.sumocfg)
SIM_DURATION_S = 600        # 10 minutes headless

TASK_INFO = {
    "n_0_0": ("loading",    3),
    "n_0_2": ("loading",    3),
    "n_0_4": ("loading",    3),
    "n_2_0": ("processing", 2),
    "n_2_2": ("processing", 2),
    "n_2_4": ("processing", 2),
    "n_4_0": ("assembly",   1),
    "n_4_2": ("assembly",   1),
    "n_4_4": ("assembly",   1),
    "n_1_1": ("storage",    2),
    "n_1_3": ("storage",    2),
    "n_3_1": ("inspection", 3),
    "n_3_3": ("inspection", 3),
}

# Forced waypoint cycles — both robots travel the center column (x=100) in
# opposite directions so they are guaranteed to meet head-on every trip.
#   Robot 0: n_0_2 (loading p=3, y=0)   <--> n_4_2 (assembly p=1, y=200)
#   Robot 1: n_4_2 (assembly p=1, y=200) <--> n_0_2 (loading p=3, y=0)
# Both use the same x=100 corridor, so physical distance when they cross < 5 m.
FORCED_WAYPOINTS = {
    "robot_0": ["n_4_2", "n_0_2"],   # starts at n_0_2, first dest n_4_2
    "robot_1": ["n_0_2", "n_4_2"],   # starts at n_4_2, first dest n_0_2
}

ROBOT_INIT_NODE = {
    "robot_0": "n_0_2",   # bottom-center (loading, p=3)
    "robot_1": "n_4_2",   # top-center    (assembly, p=1)
}

ROBOT_COLORS = {
    "robot_0": (255, 120,   0, 255),
    "robot_1": (  0, 120, 255, 255),
}

OUTPUT_CSV = "collision_forced_trajectories.csv"

# ---------------------------------------------------------------------------
# Routing helper (identical to run_sim.py)
# ---------------------------------------------------------------------------

def find_route(net, from_node_id, to_node_id):
    if from_node_id == to_node_id:
        return None
    from_node = net.getNode(from_node_id)
    to_node   = net.getNode(to_node_id)
    start_edges = list(from_node.getOutgoing())
    end_edges   = list(to_node.getIncoming())
    if not start_edges or not end_edges:
        return None
    best_route, best_cost = None, float("inf")
    for s in start_edges:
        for e in end_edges:
            result = net.getShortestPath(s, e)
            if result is None:
                continue
            path, cost = result
            if path and cost < best_cost:
                best_route = [edge.getID() for edge in path]
                best_cost  = cost
    return best_route


# ---------------------------------------------------------------------------
# Robot with forced waypoint cycling
# ---------------------------------------------------------------------------

class ForcedRobot:
    """Cycles through a fixed list of waypoint destinations indefinitely."""

    def __init__(self, rid, init_node, waypoints):
        self.rid       = rid
        self.waypoints = waypoints   # destinations to cycle through
        self.wp_idx    = 0           # index of CURRENT destination
        self.dest_node = waypoints[0]
        self.task, self.priority = TASK_INFO[self.dest_node]
        self._route_ctr = 0

    def on_arrival(self):
        """
        Called when this robot arrives at its current destination.
        Records the just-completed (task, priority), advances to next waypoint.
        Returns (completed_priority, from_node, to_node).
        """
        completed_priority = self.priority          # priority of trip just finished
        from_node          = self.dest_node         # where we just arrived

        self.wp_idx    = (self.wp_idx + 1) % len(self.waypoints)
        self.dest_node = self.waypoints[self.wp_idx]
        self.task, self.priority = TASK_INFO[self.dest_node]

        return completed_priority, from_node, self.dest_node

    def next_route_id(self):
        rid = f"{self.rid}_r{self._route_ctr}"
        self._route_ctr += 1
        return rid


def spawn_robot(net, robot, from_node, to_node, depart="0"):
    edges = find_route(net, from_node, to_node)
    if not edges:
        print(f"  WARNING: no route {from_node} -> {to_node}")
        return False
    route_id = robot.next_route_id()
    traci.route.add(route_id, edges)
    traci.vehicle.add(robot.rid, route_id, typeID="robot",
                      depart=depart, departPos="0", departSpeed="0")
    traci.vehicle.setColor(robot.rid, ROBOT_COLORS[robot.rid])
    return True


# ---------------------------------------------------------------------------
# CSV schema
# ---------------------------------------------------------------------------
CSV_FIELDS = [
    "time",
    "robot_0_x", "robot_0_y", "robot_0_speed",
    "robot_0_dest", "robot_0_task", "robot_0_priority",
    "robot_1_x", "robot_1_y", "robot_1_speed",
    "robot_1_dest", "robot_1_task", "robot_1_priority",
    "inter_robot_distance",
    "pc_raw", "pc_smooth_0", "pc_smooth_1",
    "rb_0", "rb_1",
    "mcs_0", "mcs_1",
    "snr_0_dB", "snr_1_dB",
    "cmd_0", "cmd_1",
    "crc_0", "crc_1",
    "actuation_0", "actuation_1",
    "n_sym_0", "n_sym_1",
    "latency_0_us", "latency_1_us",
    # Workstation productivity columns
    "arrived_0", "arrived_1",
    "arrival_priority_0", "arrival_priority_1",
]

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    print("Loading network ...")
    net = sumolib.net.readNet("factory.net.xml")

    print(f"Starting headless SUMO for {SIM_DURATION_S}s ...")
    traci.start(["sumo", "-c", "factory.sumocfg",
                 "--collision.action", "warn",
                 "--time-to-teleport", "-1",
                 "--no-step-log"])

    # Spawn both robots toward each other
    robots = {}
    for rid in ("robot_0", "robot_1"):
        init  = ROBOT_INIT_NODE[rid]
        robot = ForcedRobot(rid, init, FORCED_WAYPOINTS[rid])
        robots[rid] = robot
        spawn_robot(net, robot, from_node=init, to_node=robot.dest_node, depart="0")

    phy       = DownlinkPHY()
    csv_rows  = []
    max_steps = int(SIM_DURATION_S / STEP_LENGTH)

    total_arrivals = {"robot_0": 0, "robot_1": 0}

    try:
        for step in range(1, max_steps + 1):
            traci.simulationStep()
            t_sim = round(step * STEP_LENGTH, 1)

            # -- Detect workstation arrivals BEFORE re-routing --
            step_arrived          = {"robot_0": 0, "robot_1": 0}
            step_arrival_priority = {"robot_0": 0, "robot_1": 0}

            for rid in traci.simulation.getArrivedIDList():
                if rid not in robots:
                    continue
                robot = robots[rid]
                completed_priority, from_node, to_node = robot.on_arrival()

                step_arrived[rid]          = 1
                step_arrival_priority[rid] = completed_priority
                total_arrivals[rid]        += 1

                spawn_robot(net, robot, from_node=from_node,
                            to_node=to_node, depart="now")

            # -- Read positions --
            active     = set(traci.vehicle.getIDList())
            positions  = {}
            velocities = {}
            row        = {"time": t_sim}

            for rid in ("robot_0", "robot_1"):
                robot = robots[rid]
                if rid in active:
                    x, y  = traci.vehicle.getPosition(rid)
                    speed = traci.vehicle.getSpeed(rid)
                    angle = traci.vehicle.getAngle(rid)
                    vx, vy = speed_angle_to_velocity(speed, angle)
                    positions[rid]  = (x, y)
                    velocities[rid] = (vx, vy)
                    row[f"{rid}_x"]        = round(x, 2)
                    row[f"{rid}_y"]        = round(y, 2)
                    row[f"{rid}_speed"]    = round(speed, 3)
                    row[f"{rid}_dest"]     = robot.dest_node
                    row[f"{rid}_task"]     = robot.task
                    row[f"{rid}_priority"] = robot.priority
                else:
                    for key in ("_x", "_y", "_speed", "_dest", "_task", "_priority"):
                        row[f"{rid}{key}"] = None

            # -- Inter-robot distance --
            if len(positions) == 2:
                dx = positions["robot_0"][0] - positions["robot_1"][0]
                dy = positions["robot_0"][1] - positions["robot_1"][1]
                row["inter_robot_distance"] = round(math.sqrt(dx*dx + dy*dy), 2)
            else:
                row["inter_robot_distance"] = None

            # -- PHY pipeline --
            if len(positions) == 2:
                priorities = {rid: robots[rid].priority for rid in ("robot_0", "robot_1")}
                phy_result = phy.step(positions, velocities, priorities)

                apply_actuation(traci, "robot_0", phy_result["actuation_0"], STEP_LENGTH)
                apply_actuation(traci, "robot_1", phy_result["actuation_1"], STEP_LENGTH)

                for key in ("pc_raw", "pc_smooth_0", "pc_smooth_1",
                            "rb_0", "rb_1", "mcs_0", "mcs_1",
                            "snr_0_dB", "snr_1_dB",
                            "cmd_0", "cmd_1", "crc_0", "crc_1",
                            "actuation_0", "actuation_1",
                            "n_sym_0", "n_sym_1",
                            "latency_0_us", "latency_1_us"):
                    row[key] = phy_result[key]
            else:
                for key in ("pc_raw", "pc_smooth_0", "pc_smooth_1",
                            "rb_0", "rb_1", "mcs_0", "mcs_1",
                            "snr_0_dB", "snr_1_dB",
                            "cmd_0", "cmd_1", "crc_0", "crc_1",
                            "actuation_0", "actuation_1",
                            "n_sym_0", "n_sym_1",
                            "latency_0_us", "latency_1_us"):
                    row[key] = None

            # -- Arrival columns --
            row["arrived_0"]          = step_arrived["robot_0"]
            row["arrived_1"]          = step_arrived["robot_1"]
            row["arrival_priority_0"] = step_arrival_priority["robot_0"]
            row["arrival_priority_1"] = step_arrival_priority["robot_1"]

            csv_rows.append(row)

            if step % 1000 == 0:
                print(f"  t={t_sim:.0f}s  arrivals R0={total_arrivals['robot_0']}  "
                      f"R1={total_arrivals['robot_1']}")

    except (traci.exceptions.FatalTraCIError, ConnectionResetError) as exc:
        print(f"TraCI error at step {step}: {exc}")

    finally:
        try:
            traci.close()
        except Exception:
            pass

        if csv_rows:
            with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=CSV_FIELDS,
                                        extrasaction="ignore")
                writer.writeheader()
                writer.writerows(csv_rows)
            print(f"\nSaved {len(csv_rows):,} rows -> {OUTPUT_CSV}")
            print(f"Total arrivals: Robot 0 = {total_arrivals['robot_0']}, "
                  f"Robot 1 = {total_arrivals['robot_1']}")
        else:
            print("No data collected.")


if __name__ == "__main__":
    run()
