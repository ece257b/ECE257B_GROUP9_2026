"""
make_comparison_plot.py
Two-panel comparison: 2-IR vs 5-IR UCB-RL performance.
Panel A: rl_q_best over time (convergence)
Panel B: Mean downlink latency by task priority (5-IR pooled)
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.chdir(os.path.dirname(os.path.abspath(__file__)))

# ── Load CSVs ────────────────────────────────────────────────────────────────
df2 = pd.read_csv("robot_trajectories.csv")
df5 = pd.read_csv("robot_trajectories_5r.csv")

df2 = df2.dropna(subset=["rl_q_best", "time"])
df5 = df5.dropna(subset=["rl_q_best", "time"])

# ── Figure layout ────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
fig.subplots_adjust(wspace=0.35)

BLUE   = "#2c7bb6"
ORANGE = "#d7191c"
GRAY   = "#888888"

# ============================================================
# Panel A  --  rl_q_best rolling mean over simulation time
# ============================================================
ax = axes[0]

WINDOW = 150   # 15 s of simulated time

q2 = df2["rl_q_best"].rolling(WINDOW, min_periods=1).mean().values
q5 = df5["rl_q_best"].rolling(WINDOW, min_periods=1).mean().values
t2 = df2["time"].values
t5 = df5["time"].values

ax.plot(t2, q2, color=BLUE,   lw=1.4, label=r"2-IR  ($N_\mathrm{RB}=7$,  action = $\mathrm{rb}_0$)")
ax.plot(t5, q5, color=ORANGE, lw=1.4, label=r"5-IR  ($N_\mathrm{RB}=17$, action = $\alpha$)")
ax.axhline(0, color=GRAY, ls="--", lw=0.8)

# Annotate collapse
collapse_t = 717
ax.axvline(collapse_t, color=BLUE, ls=":", lw=0.9, alpha=0.7)
ax.annotate("2-IR\ncollapse", xy=(collapse_t, -0.3),
            xytext=(collapse_t + 60, -0.05),
            fontsize=7, color=BLUE,
            arrowprops=dict(arrowstyle="-|>", color=BLUE, lw=0.8))

ax.set_xlabel("Simulation time (s)", fontsize=10)
ax.set_ylabel("Best Q-value  (150-step rolling mean)", fontsize=9)
ax.set_title("(a)  UCB Agent Convergence", fontsize=10, fontweight="bold")
ax.legend(fontsize=8, loc="lower left")
ax.set_ylim(-1.1, 1.0)
ax.grid(True, alpha=0.25)
ax.tick_params(labelsize=8)

# ============================================================
# Panel B  --  Mean latency per task-priority  (5-IR pooled)
# ============================================================
ax2 = axes[1]

lat_by_p = {1: [], 2: [], 3: []}
for i in range(5):
    pc = f"robot_{i}_priority"
    lc = f"latency_{i}_us"
    if pc not in df5.columns or lc not in df5.columns:
        continue
    sub = df5[[pc, lc]].dropna()
    sub.columns = ["priority", "latency"]
    for p in [1, 2, 3]:
        lat_by_p[p].extend(sub.loc[sub["priority"] == p, "latency"].tolist())

priorities = [3, 2, 1]
labels     = ["P3  (High)\nLoading / Inspection",
              "P2  (Med)\nProcessing / Storage",
              "P1  (Low)\nAssembly"]
bar_colors = ["#2ca02c", "#ff7f0e", "#1f77b4"]

means = [np.mean(lat_by_p[p]) for p in priorities]
sems  = [np.std(lat_by_p[p]) / np.sqrt(len(lat_by_p[p])) * 3
         for p in priorities]   # 3-sigma error bars for visibility

bars = ax2.bar(labels, means, yerr=sems, capsize=5,
               color=bar_colors, edgecolor="black", linewidth=0.7,
               error_kw=dict(elinewidth=1.2, ecolor="black"),
               width=0.5)

ax2.axhline(83.33, color=GRAY, ls="--", lw=0.9,
            label=r"Min latency (1 OFDM sym = 83.3 $\mu$s)")

# Annotate bar heights
for bar, mean in zip(bars, means):
    ax2.text(bar.get_x() + bar.get_width() / 2,
             bar.get_height() + 2,
             f"{mean:.0f} µs",
             ha="center", va="bottom", fontsize=9, fontweight="bold")

ax2.set_ylabel(r"Mean downlink latency ($\mu$s)", fontsize=9)
ax2.set_title("(b)  Latency vs. Task Priority\n(5-IR, pooled across all robots)",
              fontsize=10, fontweight="bold")
ax2.legend(fontsize=8)
ax2.set_ylim(0, max(means) * 1.25)
ax2.grid(True, alpha=0.25, axis="y")
ax2.tick_params(labelsize=8)

# ── Save ─────────────────────────────────────────────────────────────────────
out = "comparison_rl_5r.png"
plt.savefig(out, dpi=180, bbox_inches="tight")
print(f"Saved -> {out}")

# ── Print key numbers for sanity check ───────────────────────────────────────
print(f"\n2-IR  q_best final 10%: {q2[-len(q2)//10:].mean():.3f}")
print(f"5-IR  q_best final 10%: {q5[-len(q5)//10:].mean():.3f}")
for p, lbl in zip(priorities, ["P3", "P2", "P1"]):
    print(f"5-IR  {lbl} mean latency: {np.mean(lat_by_p[p]):.1f} us  (n={len(lat_by_p[p])})")
