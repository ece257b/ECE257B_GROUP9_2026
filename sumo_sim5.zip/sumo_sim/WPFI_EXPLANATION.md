# WPFI Panel (a) — Detailed Dissection

## What WPFI Measures

WPFI (Workstation Productivity and Fairness Index) is a single number that answers:
**"How productively are the robots completing high-priority work right now?"**

It is computed as a **rolling 60-second sum of priority-weighted workstation arrivals**:

```
WPFI(t) = sum of arrival_priority for all arrivals in the last 60 seconds
```

Each time a robot completes a trip and docks at a workstation, it contributes that
workstation's priority value (1, 2, or 3) to the running total.

- Robot arrives at **loading** station (p=3) → contributes **3 points**
- Robot arrives at **assembly** station (p=1) → contributes **1 point**

The priority recorded is the priority of the **destination** (workstation just arrived at),
not the origin.

---

## Forced Collision Scenario Setup

Both robots are locked on a single shared corridor (center column, x = 100 m):

| Robot   | Route                     | Start node         | Priority alternation |
|---------|---------------------------|--------------------|----------------------|
| Robot 0 | n_0_2 (loading) ↔ n_4_2 (assembly) | n_0_2 (bottom) | p=1, p=3, p=1, p=3 ... |
| Robot 1 | n_4_2 (assembly) ↔ n_0_2 (loading) | n_4_2 (top)    | p=3, p=1, p=3, p=1 ... |

Collision crossings occur every ~35 s (once per robot per direction), peak Pc ≈ 0.597.

### Arrival timestamps (from collision_forced_trajectories.csv)

**Robot 0:**
| # | Time (s) | Priority |
|---|----------|----------|
| 1 | 70.0     | 1 (assembly) |
| 2 | 140.9    | 3 (loading)  |
| 3 | 211.5    | 1            |
| 4 | 282.2    | 3            |
| 5 | 356.2    | 1            |
| 6 | 426.7    | 3            |
| 7 | 496.9    | 1            |
| 8 | 568.1    | 3            |

**Robot 1:**
| # | Time (s) | Priority |
|---|----------|----------|
| 1 | 75.1     | 3 (loading)  |
| 2 | 145.3    | 1 (assembly) |
| 3 | 227.1    | 3            |
| 4 | 304.3    | 1            |
| 5 | 384.4    | 3            |
| 6 | 454.4    | 1            |
| 7 | 525.8    | 3            |

### Collision zone timestamps (Pc > 0.3)

| Zone | Start (s) | End (s) | Peak Pc |
|------|-----------|---------|---------|
| 1    | 32.6      | 39.9    | 0.596   |
| 2    | 104.0     | 111.4   | 0.596   |
| 3    | 176.9     | 184.3   | 0.596   |
| 4    | 251.8     | 259.1   | 0.596   |
| 5    | 327.4     | 334.7   | 0.596   |
| 6    | 401.6     | 408.9   | 0.596   |
| 7    | 472.2     | 479.5   | 0.597   |
| 8    | 543.5     | 550.8   | 0.596   |

---

## Left-to-Right Dissection of Panel (a)

### t = 0 → 70 s — WPFI = 0

Both robots spawn and travel toward each other for the first time.

- At **t = 32.6 – 39.9 s**: first head-on crossing → orange/purple shading, both robots
  SLOW/STOP for ~7 seconds, adding delay to the first trip.
- No workstation has been reached yet.
- `arrival_priority_0 + arrival_priority_1 = 0` at every step.
- Rolling 60 s sum = 0. **WPFI = 0.**

---

### t = 70.0 s — WPFI jumps 0 → 1

**Robot 0 arrives at n_4_2 (assembly, p = 1).**

- Contributes +1 to the rolling sum.
- 60 s window now contains one arrival worth 1 priority point.
- **WPFI = 1.**

> Why p=1? Robot 0 departed from the *loading* end (n_0_2, p=3) but its destination was
> n_4_2 (assembly, p=1). WPFI records the priority of the workstation just *arrived at*.

---

### t = 75.1 s — WPFI jumps 1 → 4

**Robot 1 arrives at n_0_2 (loading, p = 3)**, only 5.1 seconds after Robot 0.

- Contributes +3.
- 60 s window now contains both arrivals: 1 + 3 = **WPFI = 4.**

This is the 0 → 1 → 4 jump visible at the left edge of the plot. Both robots finished
their first trip within 5 seconds of each other because they started from opposite ends of
the same 200 m corridor at similar speeds.

---

### t = 75.1 → 135.1 s — WPFI holds at 4, then decays

No new arrivals. The rolling window is carrying both events.

- At **t = 130.0 s** (= 70.0 + 60): Robot 0's t=70 arrival ages out. WPFI drops to **3**.
- At **t = 135.1 s** (= 75.1 + 60): Robot 1's t=75.1 arrival ages out. **WPFI = 0.**

Second collision crossing at **t = 104.0 – 111.4 s** (orange/purple shading) adds ~7 s
delay to the trips in progress.

---

### t = 140.9 s → 145.3 s — WPFI 0 → 3 → 4

- **t = 140.9 s**: Robot 0 arrives at n_0_2 (loading, p=3) — now travelling back down.
  Contributes +3. **WPFI = 3.**
- **t = 145.3 s**: Robot 1 arrives at n_4_2 (assembly, p=1).
  Contributes +1. **WPFI = 4.**

Same double-spike pattern as before, but priorities are flipped — Robot 0 scores the
high-priority arrival first this time.

---

### t = 140 → 600 s — Repeating pattern

The pattern locks in. Every ~70 s, both robots complete one trip. Each pair of arrivals
contributes p=3 + p=1 = **4 total WPFI points** regardless of order.

The WPFI spike cycle per ~70 s block:

1. One robot arrives → WPFI jumps to 1 or 3
2. The other robot arrives 4–10 s later → WPFI jumps to 4
3. Both arrivals age out of the 60 s window → WPFI collapses to 0
4. Repeat

---

## Key Takeaway

The zero-WPFI gaps are the **productivity dead time**: both robots are in transit, slowed
by the collision crossing in the middle of the corridor, and no workstation visits are
accumulating.

Without collision avoidance (full speed ~8 m/s), a 200 m trip would take ~25 s.
With SLOW/STOP commands during the crossing, each trip takes ~70 s — nearly 3× longer.
Arrivals would come twice as often without avoidance, and the WPFI would spend far less
time at zero.

Panel (b) of the figure quantifies this as the cumulative productivity loss — the area
between the actual cumulative WPFI curve and the linear no-collision baseline.
