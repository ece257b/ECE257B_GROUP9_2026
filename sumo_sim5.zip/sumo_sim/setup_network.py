#!/usr/bin/env python3
"""
setup_network.py
================
Generate SUMO XML files for the factory warehouse simulation and run netconvert.

Warehouse layout (5x5 node grid, 50 m spacing):

  (4,0)-(4,1)-(4,2)-(4,3)-(4,4)   y=200 m  [Assembly stations]
    |     |     |     |     |
  (3,0)-(3,1)-(3,2)-(3,3)-(3,4)   y=150 m
    |     |     |     |     |
  (2,0)-(2,1)-(2,2)-(2,3)-(2,4)   y=100 m  [Processing stations]
    |     |     |     |     |
  (1,0)-(1,1)-(1,2)-(1,3)-(1,4)   y= 50 m
    |     |     |     |     |
  (0,0)-(0,1)-(0,2)-(0,3)-(0,4)   y=  0 m  [Loading docks]
  x=0   x=50  x=100 x=150 x=200

  * Green squares = workstations
  * Brown rectangles = warehouse racks

Run:
    python setup_network.py
"""

import subprocess
import sys
import os
import xml.etree.ElementTree as ET

# ── Configuration ──────────────────────────────────────────────────────────────
GRID_ROWS  = 5       # rows of nodes
GRID_COLS  = 5       # columns of nodes
SPACING    = 50.0    # metres between adjacent nodes
SPEED      = 3.0     # m/s  — typical AGV speed
LANE_WIDTH = 4.0     # metres — single-lane aisle width
NETCONVERT = "netconvert"   # must be on PATH

# Workstation nodes (row, col) and their task metadata
WORKSTATIONS = {
    # (row, col) : (task_name, priority)   priority: 3=high, 2=medium, 1=low
    (0, 0): ("loading",    3),
    (0, 2): ("loading",    3),
    (0, 4): ("loading",    3),
    (2, 0): ("processing", 2),
    (2, 2): ("processing", 2),
    (2, 4): ("processing", 2),
    (4, 0): ("assembly",   1),
    (4, 2): ("assembly",   1),
    (4, 4): ("assembly",   1),
    (1, 1): ("storage",    2),
    (1, 3): ("storage",    2),
    (3, 1): ("inspection", 3),
    (3, 3): ("inspection", 3),
}

RACK_MARGIN = 7.0   # metres inset from node position to rack edge
WS_HALF    = 4.0    # half-size (metres) of the workstation square marker


# ── Helpers ────────────────────────────────────────────────────────────────────
def node_id(r, c):
    return f"n_{r}_{c}"


def write_xml(root, filepath):
    ET.indent(root, space="  ")
    tree = ET.ElementTree(root)
    tree.write(filepath, xml_declaration=True, encoding="utf-8")


# ── File generators ────────────────────────────────────────────────────────────
def write_nodes(filepath="factory.nod.xml"):
    root = ET.Element("nodes")
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            ET.SubElement(root, "node",
                id=node_id(r, c),
                x=str(c * SPACING),
                y=str(r * SPACING),
                type="priority"
            )
    write_xml(root, filepath)
    print(f"[OK] {filepath}  ({GRID_ROWS * GRID_COLS} nodes)")


def write_edges(filepath="factory.edg.xml"):
    root = ET.Element("edges")
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            attrs = dict(speed=str(SPEED), numLanes="1", width=str(LANE_WIDTH))

            # Horizontal: (r,c) → (r, c+1)  and reverse
            if c + 1 < GRID_COLS:
                ET.SubElement(root, "edge",
                    id=f"h_{r}_{c}_f",
                    **{"from": node_id(r, c), "to": node_id(r, c + 1)},
                    **attrs)
                ET.SubElement(root, "edge",
                    id=f"h_{r}_{c}_b",
                    **{"from": node_id(r, c + 1), "to": node_id(r, c)},
                    **attrs)

            # Vertical: (r,c) → (r+1, c)  and reverse
            if r + 1 < GRID_ROWS:
                ET.SubElement(root, "edge",
                    id=f"v_{r}_{c}_f",
                    **{"from": node_id(r, c), "to": node_id(r + 1, c)},
                    **attrs)
                ET.SubElement(root, "edge",
                    id=f"v_{r}_{c}_b",
                    **{"from": node_id(r + 1, c), "to": node_id(r, c)},
                    **attrs)

    n_h = (GRID_COLS - 1) * GRID_ROWS * 2
    n_v = (GRID_ROWS - 1) * GRID_COLS * 2
    write_xml(root, filepath)
    print(f"[OK] {filepath}  ({n_h + n_v} directed edges)")


def write_polys(filepath="factory.poly.xml"):
    root = ET.Element("additional")

    # Rack polygons — one per grid block (between 4 nodes)
    for r in range(GRID_ROWS - 1):
        for c in range(GRID_COLS - 1):
            x1 = c * SPACING + RACK_MARGIN
            y1 = r * SPACING + RACK_MARGIN
            x2 = (c + 1) * SPACING - RACK_MARGIN
            y2 = (r + 1) * SPACING - RACK_MARGIN
            shape = f"{x1},{y1} {x2},{y1} {x2},{y2} {x1},{y2}"
            ET.SubElement(root, "poly",
                id=f"rack_{r}_{c}",
                type="warehouse.rack",
                color="160,90,40",
                shape=shape,
                fill="1",
                layer="10.0"
            )

    # Workstation markers (green squares at workstation nodes)
    for (r, c), (task, priority) in WORKSTATIONS.items():
        cx, cy = c * SPACING, r * SPACING
        shape = (f"{cx - WS_HALF},{cy - WS_HALF} "
                 f"{cx + WS_HALF},{cy - WS_HALF} "
                 f"{cx + WS_HALF},{cy + WS_HALF} "
                 f"{cx - WS_HALF},{cy + WS_HALF}")
        # Colour by priority: high=green, medium=yellow, low=cyan
        colour = {3: "0,200,80", 2: "220,200,0", 1: "0,180,200"}[priority]
        ET.SubElement(root, "poly",
            id=f"ws_{r}_{c}",
            type=f"warehouse.workstation.{task}",
            color=colour,
            shape=shape,
            fill="1",
            layer="10.0"
        )

    n_racks = (GRID_ROWS - 1) * (GRID_COLS - 1)
    write_xml(root, filepath)
    print(f"[OK] {filepath}  ({n_racks} racks, {len(WORKSTATIONS)} workstations)")


def write_routes(filepath="factory.rou.xml"):
    """Vehicle type definition only — routes are assigned dynamically via TraCI."""
    content = """\
<?xml version="1.0" encoding="UTF-8"?>
<routes xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/routes_file.xsd">

    <!-- AGV robot vehicle type -->
    <vType id="robot"
           accel="0.5"
           decel="1.0"
           maxSpeed="3.0"
           length="0.8"
           width="0.8"
           minGap="0.5"
           sigma="0.0"
           color="0,100,255"/>

</routes>
"""
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[OK] {filepath}")


def write_sumocfg(filepath="factory.sumocfg"):
    content = """\
<?xml version="1.0" encoding="UTF-8"?>
<configuration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
               xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/sumoConfiguration.xsd">

    <input>
        <net-file value="factory.net.xml"/>
        <route-files value="factory.rou.xml"/>
        <additional-files value="factory.poly.xml"/>
    </input>

    <time>
        <begin value="0"/>
        <end value="86400"/>
        <step-length value="0.1"/>
    </time>

    <processing>
        <collision.action value="warn"/>
        <collision.mingap-factor value="0"/>
    </processing>

    <report>
        <no-step-log value="true"/>
    </report>

</configuration>
"""
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[OK] {filepath}")


def run_netconvert():
    cmd = [
        NETCONVERT,
        "-n", "factory.nod.xml",
        "-e", "factory.edg.xml",
        "-o", "factory.net.xml",
        "--no-warnings",
        "--junctions.corner-detail", "0",
    ]
    print(f"\nRunning: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("netconvert STDERR:\n", result.stderr)
        sys.exit(1)
    print("[OK] factory.net.xml")


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    write_nodes()
    write_edges()
    write_polys()
    write_routes()
    write_sumocfg()
    run_netconvert()

    print("\n" + "="*55)
    print("Setup complete!")
    print("  Visual run  : python run_sim.py")
    print("  Headless run: python run_sim.py --nogui")
    print("="*55)
