"""
generate_plots_wpfi.py
======================
Computes and plots the Workstation Productivity and Fairness Index (WPFI)
from collision_forced_trajectories.csv (produced by run_forced_collision.py).

WPFI(t) = rolling sum over the last 60 seconds of priority-weighted workstation
           completions = priority-weighted tasks completed per minute.

  High WPFI  -> robots completing high-priority tasks without interruption.
  WPFI dip   -> collision avoidance (SLOW/STOP) is delaying task completion.

Output: result_wpfi.png
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
CSV_PATH    = "collision_forced_trajectories.csv"
STEP_LENGTH = 0.1          # seconds per simulation step
WINDOW_S    = 60.0         # rolling window for WPFI (seconds)
WINDOW_STEPS = int(WINDOW_S / STEP_LENGTH)   # 600 steps

STYLE = {
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.grid":         True,
    "grid.linestyle":    "--",
    "grid.alpha":        0.30,
    "font.family":       "DejaVu Sans",
    "font.size":         12,
}

# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------
df = pd.read_csv(CSV_PATH)
# Keep ALL rows — arrival steps have NaN PHY columns (robot was transitioning)
# so we must NOT dropna on PHY columns before reading arrivals.
df["pc_smooth_0"]        = df["pc_smooth_0"].fillna(0.0)
df["arrived_0"]          = df["arrived_0"].fillna(0).astype(int)
df["arrived_1"]          = df["arrived_1"].fillna(0).astype(int)
df["arrival_priority_0"] = df["arrival_priority_0"].fillna(0.0)
df["arrival_priority_1"] = df["arrival_priority_1"].fillna(0.0)

t = df["time"].values

# ---------------------------------------------------------------------------
# Compute WPFI
# ---------------------------------------------------------------------------
# Per-step contribution: priority of completed trip, 0 if no arrival this step
df["weighted_arrival"] = df["arrival_priority_0"] + df["arrival_priority_1"]

# Rolling sum over last WINDOW_S seconds = priority-weighted completions per minute
df["wpfi"] = (df["weighted_arrival"]
              .rolling(WINDOW_STEPS, min_periods=1)
              .sum())

# Cumulative WPFI (total priority-weighted completions over full run)
df["wpfi_cumulative"] = df["weighted_arrival"].cumsum()

# Baseline: linear extrapolation assuming no collisions
# (final cumulative value spread uniformly over time)
final_cum = df["wpfi_cumulative"].iloc[-1]
total_time = t[-1]
df["wpfi_baseline"] = final_cum * t / total_time

# Identify arrival events for both robots
arrivals_0 = df[df["arrived_0"] == 1]
arrivals_1 = df[df["arrived_1"] == 1]

# Identify collision regions (Pc > 0.3)
pc = df["pc_smooth_0"].values

print(f"Loaded {len(df):,} rows  ({t[0]:.1f}s -- {t[-1]:.1f}s)")
print(f"Robot 0 arrivals: {len(arrivals_0)}  (priorities: "
      f"{arrivals_0['arrival_priority_0'].tolist()})")
print(f"Robot 1 arrivals: {len(arrivals_1)}  (priorities: "
      f"{arrivals_1['arrival_priority_1'].tolist()})")
print(f"Collision rows (Pc>0.3): {(df.pc_smooth_0>0.3).sum()}")
print(f"Max Pc: {df.pc_smooth_0.max():.3f}")
print(f"Final WPFI cumulative: {final_cum:.0f} priority-pts")

# ---------------------------------------------------------------------------
# Draw figure
# ---------------------------------------------------------------------------
with plt.rc_context(STYLE):
    fig, (ax_top, ax_bot) = plt.subplots(
        2, 1, figsize=(11, 8),
        gridspec_kw={"height_ratios": [1.6, 1], "hspace": 0.42})

    fig.suptitle("Workstation Productivity and Fairness Index (WPFI)\n"
                 "Forced head-on collision scenario — center corridor",
                 fontsize=13, fontweight="bold", y=1.01)

    # ========================================================================
    # TOP: WPFI rolling window
    # ========================================================================

    # Shade collision regions
    above = pc > 0.3
    diffs = np.diff(above.astype(int), prepend=0, append=0)
    for s, e in zip(np.where(diffs == 1)[0], np.where(diffs == -1)[0]):
        ts = t[min(s, len(t)-1)]
        te = t[min(e, len(t)-1)]
        col = "#9467bd" if pc[min(s, len(pc)-1)] > 0.5 else "#ff7f0e"
        ax_top.axvspan(ts, te, color=col, alpha=0.18, linewidth=0)

    # WPFI line
    ax_top.plot(t, df["wpfi"].values, color="#1f77b4", lw=2.2,
                label="WPFI  (60 s rolling window)")
    ax_top.fill_between(t, 0, df["wpfi"].values, alpha=0.12, color="#1f77b4")

    # Mark individual arrivals as vertical ticks on the x-axis
    for _, row_ in arrivals_0.iterrows():
        ax_top.axvline(row_["time"], color="#1f77b4", lw=1.4, ls="--", alpha=0.6)
        ax_top.text(row_["time"], df["wpfi"].max() * 1.02,
                    f"R0\np={int(row_['arrival_priority_0'])}",
                    ha="center", va="bottom", fontsize=7.5,
                    color="#1f77b4")

    for _, row_ in arrivals_1.iterrows():
        ax_top.axvline(row_["time"], color="#d62728", lw=1.4, ls=":", alpha=0.6)
        ax_top.text(row_["time"], -0.6,
                    f"R1\np={int(row_['arrival_priority_1'])}",
                    ha="center", va="top", fontsize=7.5,
                    color="#d62728")

    # Pc on twin y-axis
    axr = ax_top.twinx()
    axr.plot(t, pc, color="#888888", lw=1.2, ls=":", alpha=0.8)
    axr.axhline(0.3, color="#ff7f0e", lw=0.8, ls="--", alpha=0.6)
    axr.axhline(0.5, color="#9467bd", lw=0.8, ls="--", alpha=0.6)
    axr.set_ylim(-0.05, 1.2)
    axr.set_yticks([0.0, 0.3, 0.5, 0.6, 0.8, 1.0])
    axr.set_yticklabels(["0.0", "0.3", "0.5", "0.6", "0.8", "1.0"], fontsize=9)
    axr.set_ylabel("Collision Probability  $P_c$", fontsize=10, color="#666666")
    axr.tick_params(axis="y", colors="#666666")
    axr.spines["right"].set_visible(True)
    axr.spines["right"].set_color("#cccccc")

    ax_top.set_xlim(t[0], t[-1])
    ax_top.set_ylim(-1.2, df["wpfi"].max() + 1.5)
    ax_top.set_ylabel("WPFI\n(priority-weighted visits / 60 s)", fontsize=11)
    ax_top.set_title("(a)  WPFI Over Time — Dips During Collision Avoidance Events",
                     fontsize=11, fontweight="bold")

    legend_handles = [
        Line2D([0],[0], color="#1f77b4", lw=2.2, label="WPFI (rolling 60 s)"),
        Line2D([0],[0], color="#888888", lw=1.2, ls=":", label="$P_c$ (smooth)"),
        Line2D([0],[0], color="#1f77b4", lw=1.4, ls="--", alpha=0.7,
               label="Robot 0 arrival"),
        Line2D([0],[0], color="#d62728", lw=1.4, ls=":",  alpha=0.7,
               label="Robot 1 arrival"),
        mpatches.Patch(color="#ff7f0e", alpha=0.35, label="Collision zone  ($P_c$>0.3)"),
        mpatches.Patch(color="#9467bd", alpha=0.35, label="Boost zone  ($P_c$>0.5)"),
    ]
    ax_top.legend(handles=legend_handles, fontsize=9, loc="upper left",
                  framealpha=0.9, ncol=2)

    # ========================================================================
    # BOTTOM: Cumulative WPFI vs no-collision baseline
    # ========================================================================

    # Shade collision regions (same as top)
    for s, e in zip(np.where(diffs == 1)[0], np.where(diffs == -1)[0]):
        ts = t[min(s, len(t)-1)]
        te = t[min(e, len(t)-1)]
        col = "#9467bd" if pc[min(s, len(pc)-1)] > 0.5 else "#ff7f0e"
        ax_bot.axvspan(ts, te, color=col, alpha=0.18, linewidth=0)

    ax_bot.plot(t, df["wpfi_baseline"].values, color="#aaaaaa", lw=1.6, ls="--",
                label="Ideal baseline (no collisions)")
    ax_bot.plot(t, df["wpfi_cumulative"].values, color="#2ca02c", lw=2.2,
                label="Actual cumulative WPFI")
    ax_bot.fill_between(t,
                        df["wpfi_baseline"].values,
                        df["wpfi_cumulative"].values,
                        where=df["wpfi_cumulative"].values < df["wpfi_baseline"].values,
                        alpha=0.20, color="#d62728",
                        label="Productivity loss from collision avoidance")

    # Annotate final gap
    gap = df["wpfi_baseline"].iloc[-1] - df["wpfi_cumulative"].iloc[-1]
    if gap > 0:
        ax_bot.annotate(f"Total loss\n= {gap:.1f} pts",
                        xy=(t[-1], df["wpfi_cumulative"].iloc[-1]),
                        xytext=(t[-1] - 80, df["wpfi_cumulative"].iloc[-1] - 3),
                        fontsize=9, color="#d62728",
                        arrowprops=dict(arrowstyle="->", color="#d62728", lw=1.0))

    ax_bot.set_xlim(t[0], t[-1])
    ax_bot.set_xlabel("Simulation Time (s)", fontsize=12)
    ax_bot.set_ylabel("Cumulative WPFI\n(priority-weighted visits)", fontsize=11)
    ax_bot.set_title("(b)  Cumulative WPFI vs Ideal Baseline — Productivity Loss Quantified",
                     fontsize=11, fontweight="bold")
    ax_bot.legend(fontsize=9, loc="upper left", framealpha=0.9)

    fig.savefig("result_wpfi.png", dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("\n[OK] result_wpfi.png saved")
