"""
channel_model.py -- Downlink channel model: pathloss + Rayleigh fading + AWGN
===============================================================================
Models the BS-to-robot downlink channel for each simulation step.

Channel chain (per robot, per step):
  tx_signal  ->  apply_channel()  ->  rx_signal  (+ noise)

All functions are stateless -- caller passes robot position and n_rbs each step.
Precomputed constants (noise floor, subcarrier BW) are module-level for speed.

Physical parameters (NR numerology mu=0):
  Subcarrier spacing : 15 kHz
  Subcarriers per RB : 12
  BW per RB          : 180 kHz
  Noise figure       : 7 dB
  BS position        : (100, 100, 5) m
  Carrier frequency  : 3.5 GHz  (for coherence time reference only)
"""

import numpy as np

# ---------------------------------------------------------------------------
# Physical constants -- edit here to tune the channel model
# ---------------------------------------------------------------------------

BS_X      = 100.0   # m  (centre of 200x200 factory floor)
BS_Y      = 100.0   # m
BS_Z      =   5.0   # m  (antenna height)
ROBOT_Z   =   0.0   # m  (ground-level robots)

BW_PER_RB_HZ   = 180_000.0   # 12 subcarriers * 15 kHz
NOISE_FIGURE_DB =     7.0     # dB
THERMAL_NOISE_DBM_HZ = -174.0 # dBm/Hz  (kTB at 290 K)

# Precomputed noise floor per RB in linear (Watts)
_THERMAL_W_HZ = 10 ** ((THERMAL_NOISE_DBM_HZ - 30) / 10)   # W/Hz
_NF_LINEAR    = 10 ** (NOISE_FIGURE_DB / 10)
NOISE_POWER_PER_RB_W = _THERMAL_W_HZ * _NF_LINEAR * BW_PER_RB_HZ

MIN_DISTANCE_M = 0.5   # clamp distance to avoid log(0)


# ---------------------------------------------------------------------------
# Pathloss
# ---------------------------------------------------------------------------

def pathloss_linear(x_robot: float, y_robot: float) -> float:
    """
    Return linear pathloss (dimensionless, >= 1) from BS to robot.

    Model: L_dB = 38 + 30 * log10(d_3D)
    where d_3D = sqrt((x-BS_X)^2 + (y-BS_Y)^2 + (ROBOT_Z - BS_Z)^2)

    Returns:
        L (float): linear pathloss factor (signal divided by L at receiver)
    """
    d_horiz = np.sqrt((x_robot - BS_X)**2 + (y_robot - BS_Y)**2)
    d_3d    = np.sqrt(d_horiz**2 + (ROBOT_Z - BS_Z)**2)
    d_3d    = max(d_3d, MIN_DISTANCE_M)
    L_dB    = 38.0 + 30.0 * np.log10(d_3d)
    return 10 ** (L_dB / 10.0)


def pathloss_db(x_robot: float, y_robot: float) -> float:
    """Return pathloss in dB (for logging/debugging)."""
    return 10.0 * np.log10(pathloss_linear(x_robot, y_robot))


# ---------------------------------------------------------------------------
# Rayleigh fading channel coefficient
# ---------------------------------------------------------------------------

def rayleigh_tap() -> complex:
    """
    Draw a single-tap complex Gaussian fading coefficient h ~ CN(0, 1).

    One fresh draw per robot per time step.  Valid assumption because:
      coherence time at 3.5 GHz, 5 m/s ~ 2.5 ms  <<  100 ms step length.

    Returns:
        h (complex): fading coefficient; |h|^2 is exponentially distributed.
    """
    return (np.random.randn() + 1j * np.random.randn()) / np.sqrt(2.0)


# ---------------------------------------------------------------------------
# AWGN noise vector
# ---------------------------------------------------------------------------

def awgn_noise(n_samples: int, n_rbs: int) -> np.ndarray:
    """
    Generate complex AWGN noise scaled to the allocated bandwidth.

    Noise power = NOISE_POWER_PER_RB_W * n_rbs  (total thermal noise in band).
    Per-sample variance = total_noise_power / n_samples  (energy spread over FFT).

    Returns:
        noise (complex128 ndarray, shape [n_samples])
    """
    total_noise_W    = NOISE_POWER_PER_RB_W * n_rbs
    per_sample_std   = np.sqrt(total_noise_W / (2.0 * n_samples))
    return per_sample_std * (np.random.randn(n_samples)
                             + 1j * np.random.randn(n_samples))


# ---------------------------------------------------------------------------
# Full channel application
# ---------------------------------------------------------------------------

def apply_channel(tx_signal: np.ndarray,
                  x_robot: float,
                  y_robot: float,
                  n_rbs: int,
                  tx_power_W: float = 1.0):
    """
    Apply pathloss + Rayleigh fading + AWGN to tx_signal.

    tx_signal  : complex time-domain signal (after IFFT + CP)
    tx_power_W : BS transmit power (default 1 W = 30 dBm)

    Returns:
        rx_signal (ndarray, same shape as tx_signal) -- complex received samples
        h         (complex)                          -- fading coefficient used
        snr_dB    (float)                            -- received SNR in dB
    """
    L_lin = pathloss_linear(x_robot, y_robot)
    h     = rayleigh_tap()

    # Received signal power after pathloss and fading: P_rx = P_tx * |h|^2 / L
    signal_power_rx = tx_power_W * (abs(h)**2) / L_lin

    # Scale tx_signal to match intended rx power
    # tx_signal is unit-normalised by the modulator, so scale by sqrt of power
    rx_clean = h * tx_signal * np.sqrt(tx_power_W / L_lin)

    noise    = awgn_noise(len(tx_signal), n_rbs)
    rx_signal = rx_clean + noise

    # SNR estimate (linear signal power / total noise power)
    total_noise_W = NOISE_POWER_PER_RB_W * n_rbs
    snr_lin  = signal_power_rx / total_noise_W if total_noise_W > 0 else 1e6
    snr_dB   = 10.0 * np.log10(max(snr_lin, 1e-12))

    # Effective channel coefficient seen by the receiver:
    # h_eff = h * sqrt(P_tx / L), so the equalizer (which divides by h_eff)
    # correctly undoes BOTH the Rayleigh fading AND the path-loss scaling.
    h_eff = h * np.sqrt(tx_power_W / L_lin)

    return rx_signal, h_eff, snr_dB


# ---------------------------------------------------------------------------
# Convenience: SNR given position and RBs (without full signal chain)
# ---------------------------------------------------------------------------

def estimate_snr_db(x_robot: float, y_robot: float,
                    n_rbs: int, tx_power_W: float = 1.0) -> float:
    """
    Estimate expected SNR in dB at a given position using mean channel gain
    (E[|h|^2] = 1 for CN(0,1)).  Used by MCS selector before signal build.

    SNR_expected = P_tx / (L * N0 * BW_per_RB * n_rbs)
    """
    L_lin         = pathloss_linear(x_robot, y_robot)
    total_noise_W = NOISE_POWER_PER_RB_W * n_rbs
    if total_noise_W <= 0 or L_lin <= 0:
        return 40.0   # fallback: assume good channel
    snr_lin = tx_power_W / (L_lin * total_noise_W)
    return 10.0 * np.log10(max(snr_lin, 1e-12))
