"""
phy_downlink.py -- Task-Aware Downlink PHY Pipeline
=====================================================
Implements the full per-step pipeline described in Downlink_Pipeline_Design.md:

  Stage 2  Collision probability  (kinematic lookahead + EMA smoothing)
  Stage 3  Rule-based RB allocation + MCS selection
  Stage 4  Command selection (STOP / SLOW / CONTINUE)
  Stage 5  OFDM packet: build -> channel -> receive -> CRC decode
  Stage 6  Actuation decision (with hysteresis and fail-safe)

Usage (from run_sim.py):

    from phy_downlink import DownlinkPHY
    phy = DownlinkPHY()                  # once, before the loop

    # inside the step loop:
    result = phy.step(
        positions   = positions,         # {"robot_0": (x,y), "robot_1": (x,y)}
        velocities  = velocities,        # {"robot_0": (vx,vy), "robot_1": (vx,vy)}
        priorities  = priorities,        # {"robot_0": int, "robot_1": int}
    )
    # result is a dict -- see DownlinkPHY.step() docstring for keys
"""

import math
import numpy as np
from channel_model import apply_channel, estimate_snr_db

# ============================================================================
#  TUNABLE CONSTANTS  -- all magic numbers live here
# ============================================================================

# --- Collision probability ---
TAU_LOOKAHEAD_S  = 2.0     # seconds ahead to project positions
D_DANGER_M       = 10.0    # metres: distance at which P_c = 1
EMA_ALPHA        = 0.3     # smoothing factor (higher = more reactive)

# --- RB pool ---
TOTAL_RBS        = 52      # 10 MHz / 180 kHz per RB
COLLISION_BOOST_THRESHOLD = 0.5   # P_c above this -> equal split

# --- MCS thresholds ---
P_C_QPSK_THRESH  = 0.6     # P_c > this -> QPSK (most robust)
P_C_16QAM_THRESH = 0.3     # P_c > this (and <= QPSK) -> 16-QAM
SNR_64QAM_MIN_DB = 20.0    # SNR must be >= this for 64-QAM
SNR_QPSK_MAX_DB  = 15.0    # SNR < this -> force QPSK

MCS_QPSK   = 0
MCS_16QAM  = 1
MCS_64QAM  = 2
MCS_NAMES  = {MCS_QPSK: "QPSK", MCS_16QAM: "16-QAM", MCS_64QAM: "64-QAM"}

# --- Command thresholds ---
P_STOP = 0.65
P_SLOW = 0.30

CMD_CONTINUE = "CONTINUE"
CMD_SLOW     = "SLOW"
CMD_STOP     = "STOP"

# 2-bit command encoding
CMD_BITS = {CMD_CONTINUE: [0, 0], CMD_SLOW: [0, 1], CMD_STOP: [1, 0]}

# --- OFDM frame ---
N_FFT    = 64
CP_LEN   = 16     # cyclic prefix length (samples)
FRAME_LEN = N_FFT + CP_LEN   # 80 samples per OFDM symbol

# --- Hysteresis ---
HYSTERESIS_COUNT = 5    # consecutive CONTINUE decisions before resuming speed
MAX_STOP_STEPS   = 40   # deadlock breaker: force SLOW after this many STOP steps

# --- TraCI speed settings ---
SPEED_MAX  = 13.89    # m/s  (~50 km/h -- SUMO robot type max)
SPEED_SLOW = 1.0      # m/s  (SLOW command target speed)
SPEED_STOP = 0.0      # m/s

# --- CRC polynomial (CRC-8 / ITU) ---
CRC_POLY   = 0x07
CRC_BITS   = 8

# ============================================================================
#  CRC-8
# ============================================================================

def _crc8(bits: list) -> list:
    """
    Compute CRC-8/ITU over a list of bits (ints 0/1).
    Returns an 8-element list of CRC bits (MSB first).
    """
    # Pack bits into bytes (pad to multiple of 8)
    padded = bits + [0] * ((-len(bits)) % 8)
    crc = 0x00
    for i in range(0, len(padded), 8):
        byte = 0
        for b in padded[i:i+8]:
            byte = (byte << 1) | int(b)
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ CRC_POLY) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return [(crc >> (7 - i)) & 1 for i in range(8)]


def _crc8_check(payload_bits: list, received_crc_bits: list) -> bool:
    """Return True if CRC over payload matches received_crc_bits."""
    expected = _crc8(payload_bits)
    return expected == list(received_crc_bits)


# ============================================================================
#  Modulation / Demodulation
# ============================================================================

def _bits_to_qam_symbols(bits: list, mcs: int) -> np.ndarray:
    """
    Map a list of bits to complex QAM symbols.

    QPSK   : 2 bits/symbol  -- Gray coded, unit circle
    16-QAM : 4 bits/symbol  -- Gray coded, normalised to unit avg power
    64-QAM : 6 bits/symbol  -- Gray coded, normalised to unit avg power

    Pads bits to a multiple of bits_per_symbol before mapping.
    Returns complex128 ndarray.
    """
    if mcs == MCS_QPSK:
        bps      = 2
        # Constellation: 00->NE, 01->NW, 10->SE, 11->SW (Gray coded)
        const    = {(0,0):  1+1j,
                    (0,1): -1+1j,
                    (1,0):  1-1j,
                    (1,1): -1-1j}
        scale    = 1.0 / math.sqrt(2)

    elif mcs == MCS_16QAM:
        bps      = 4
        # 4x4 QAM: Gray-coded rows and columns over {-3,-1,+1,+3}
        levels   = {(0,0): -3, (0,1): -1, (1,1):  1, (1,0):  3}
        scale    = 1.0 / math.sqrt(10)   # normalise avg power to 1

    else:  # MCS_64QAM
        bps      = 6
        # 8x8 QAM: Gray-coded over {-7,-5,-3,-1,+1,+3,+5,+7}
        _g       = {(0,0,0): -7, (0,0,1): -5, (0,1,1): -3, (0,1,0): -1,
                    (1,1,0):  1, (1,1,1):  3, (1,0,1):  5, (1,0,0):  7}
        scale    = 1.0 / math.sqrt(42)

    # Pad bits
    pad   = (-len(bits)) % bps
    bits  = bits + [0] * pad

    symbols = []
    for i in range(0, len(bits), bps):
        chunk = tuple(bits[i:i+bps])
        if mcs == MCS_QPSK:
            s = const[chunk]
        elif mcs == MCS_16QAM:
            re = levels[chunk[:2]]
            im = levels[chunk[2:]]
            s  = complex(re, im)
        else:
            re = _g[chunk[:3]]
            im = _g[chunk[3:]]
            s  = complex(re, im)
        symbols.append(s * scale)

    return np.array(symbols, dtype=complex)


def _qam_symbols_to_bits(symbols: np.ndarray, mcs: int,
                         n_payload_bits: int) -> list:
    """
    Hard-decision demap QAM symbols back to bits.
    Returns exactly n_payload_bits bits.
    """
    if mcs == MCS_QPSK:
        bps   = 2
        pts   = np.array([ 1+1j, -1+1j,  1-1j, -1-1j]) / math.sqrt(2)
        codes = [(0,0), (0,1), (1,0), (1,1)]

    elif mcs == MCS_16QAM:
        scale = 1.0 / math.sqrt(10)
        lvs   = [-3, -1, 1, 3]
        lcodes= [(0,0), (0,1), (1,1), (1,0)]   # Gray code per axis
        pts   = np.array([complex(r, i)*scale
                          for r in lvs for i in lvs])
        codes = [(rc + ic) for rc in lcodes for ic in lcodes]

    else:  # 64-QAM
        scale = 1.0 / math.sqrt(42)
        lvs   = [-7, -5, -3, -1, 1, 3, 5, 7]
        lcodes= [(0,0,0), (0,0,1), (0,1,1), (0,1,0),
                 (1,1,0), (1,1,1), (1,0,1), (1,0,0)]
        pts   = np.array([complex(r, i)*scale
                          for r in lvs for i in lvs])
        codes = [(rc + ic) for rc in lcodes for ic in lcodes]

    bits = []
    for s in symbols:
        dists = np.abs(pts - s)
        idx   = int(np.argmin(dists))
        bits.extend(codes[idx])

    return bits[:n_payload_bits]


# ============================================================================
#  OFDM framing helpers
# ============================================================================

def _subcarrier_indices(n_rbs: int, n_fft: int = N_FFT) -> np.ndarray:
    """
    Map n_rbs resource blocks to subcarrier indices in the FFT grid.
    Allocates from the centre of the band outward (DC-centred OFDM).
    Each RB carries 12 subcarriers.

    Returns integer index array of length n_rbs * 12, within [0, n_fft).
    """
    n_sc      = n_rbs * 12
    n_sc      = min(n_sc, n_fft - 1)   # safety cap (DC removed)
    half      = n_fft // 2
    # Upper half: indices 1 .. half;  Lower half: N_FFT-1 downward
    upper     = np.arange(1, half + 1)
    lower     = np.arange(n_fft - 1, half - 1, -1)
    interleaved = np.empty(len(upper) + len(lower), dtype=int)
    interleaved[0::2] = upper[:len(upper)]
    interleaved[1::2] = lower[:len(lower)]
    return interleaved[:n_sc]


def _ofdm_modulate(symbols: np.ndarray, sc_indices: np.ndarray,
                   n_fft: int = N_FFT, cp_len: int = CP_LEN) -> np.ndarray:
    """
    Place symbols on sc_indices, IFFT, prepend cyclic prefix.
    Returns real-valued (as complex) time-domain signal of length n_fft + cp_len.
    """
    freq_domain = np.zeros(n_fft, dtype=complex)
    n_syms = min(len(symbols), len(sc_indices))
    freq_domain[sc_indices[:n_syms]] = symbols[:n_syms]
    time_domain = np.fft.ifft(freq_domain)
    cp           = time_domain[-cp_len:]
    return np.concatenate([cp, time_domain])


def _ofdm_demodulate(rx_signal: np.ndarray, h: complex,
                     sc_indices: np.ndarray,
                     n_fft: int = N_FFT, cp_len: int = CP_LEN) -> np.ndarray:
    """
    Remove CP, FFT, equalise (1-tap zero-forcing: divide by h), extract symbols.
    Returns complex symbol array on the allocated subcarriers.
    """
    time_domain  = rx_signal[cp_len:]           # strip CP
    freq_domain  = np.fft.fft(time_domain)
    # Zero-forcing equalisation
    if abs(h) < 1e-9:
        h = 1e-9 + 0j   # guard against near-zero channel
    equalised    = freq_domain / h
    return equalised[sc_indices]


# ============================================================================
#  Velocity extraction from TraCI speed + angle
# ============================================================================

def speed_angle_to_velocity(speed: float, angle_deg: float):
    """
    Convert SUMO speed (m/s) + heading angle (degrees, 0=North, CW) to (vx, vy).

    SUMO angle convention: 0 = North (+Y), 90 = East (+X), clockwise.
    """
    angle_rad = math.radians(angle_deg)
    vx =  speed * math.sin(angle_rad)
    vy =  speed * math.cos(angle_rad)
    return vx, vy


# ============================================================================
#  DownlinkPHY  -- main class
# ============================================================================

class DownlinkPHY:
    """
    Stateful downlink PHY controller for the 2-robot factory simulation.

    Maintains per-robot EMA state and hysteresis counters across steps.
    Call step() once per simulation step from run_sim.py.
    """

    def __init__(self):
        # Per-robot persistent state
        self._pc_smooth  = {"robot_0": 0.0, "robot_1": 0.0}
        self._hyst_cnt   = {"robot_0": 0,   "robot_1": 0}
        self._stop_ctr   = {"robot_0": 0,   "robot_1": 0}   # deadlock breaker
        # Precompute subcarrier index arrays for all possible RB counts
        self._sc_cache   = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_sc_indices(self, n_rbs: int) -> np.ndarray:
        """Cached subcarrier index lookup."""
        if n_rbs not in self._sc_cache:
            self._sc_cache[n_rbs] = _subcarrier_indices(n_rbs)
        return self._sc_cache[n_rbs]

    # ------------------------------------------------------------------
    # Stage 2 -- Collision probability
    # ------------------------------------------------------------------

    def _collision_probability(self, pos: dict, vel: dict) -> tuple:
        """
        Compute raw and smoothed collision probability.

        Returns:
            pc_raw    (float) [0,1]
            pc_smooth (dict)  {robot_id: float [0,1]} -- updated EMA values
        """
        x0, y0 = pos["robot_0"]
        x1, y1 = pos["robot_1"]
        vx0, vy0 = vel["robot_0"]
        vx1, vy1 = vel["robot_1"]

        # Kinematic projection tau seconds ahead
        tau = TAU_LOOKAHEAD_S
        fx0, fy0 = x0 + vx0 * tau, y0 + vy0 * tau
        fx1, fy1 = x1 + vx1 * tau, y1 + vy1 * tau

        d_pred = math.sqrt((fx0 - fx1)**2 + (fy0 - fy1)**2)
        pc_raw = max(0.0, 1.0 - d_pred / D_DANGER_M)
        pc_raw = min(pc_raw, 1.0)

        # EMA: both robots share the same P_c (symmetric collision risk)
        for rid in ("robot_0", "robot_1"):
            self._pc_smooth[rid] = (EMA_ALPHA * pc_raw
                                    + (1.0 - EMA_ALPHA) * self._pc_smooth[rid])

        return pc_raw, dict(self._pc_smooth)

    # ------------------------------------------------------------------
    # Stage 3 -- RB allocation + MCS
    # ------------------------------------------------------------------

    @staticmethod
    def _allocate_rbs(p0: int, p1: int, pc_smooth: float) -> tuple:
        """
        Compute RB allocation for each robot.

        Returns:
            rb_0 (int), rb_1 (int)  -- must sum to TOTAL_RBS
        """
        if pc_smooth > COLLISION_BOOST_THRESHOLD:
            return TOTAL_RBS // 2, TOTAL_RBS - TOTAL_RBS // 2
        denom = p0 + p1
        if denom == 0:
            denom = 1
        rb_0 = math.floor(TOTAL_RBS * p0 / denom)
        rb_1 = TOTAL_RBS - rb_0
        # Clamp to at least 1 RB per robot
        rb_0 = max(1, min(rb_0, TOTAL_RBS - 1))
        rb_1 = TOTAL_RBS - rb_0
        return rb_0, rb_1

    @staticmethod
    def _select_mcs(pc_smooth: float, snr_db: float) -> int:
        """
        Rule-based MCS selection.

        Priority: safety (P_c) > channel quality (SNR).
        """
        if pc_smooth > P_C_QPSK_THRESH or snr_db < SNR_QPSK_MAX_DB:
            return MCS_QPSK
        if pc_smooth > P_C_16QAM_THRESH:
            return MCS_16QAM
        if snr_db >= SNR_64QAM_MIN_DB:
            return MCS_64QAM
        return MCS_16QAM   # default mid-tier

    # ------------------------------------------------------------------
    # Stage 4 -- Command selection
    # ------------------------------------------------------------------

    @staticmethod
    def _select_command(pc_smooth: float) -> str:
        if pc_smooth >= P_STOP:
            return CMD_STOP
        if pc_smooth >= P_SLOW:
            return CMD_SLOW
        return CMD_CONTINUE

    # ------------------------------------------------------------------
    # Stage 5 -- Build, transmit, receive, decode
    # ------------------------------------------------------------------

    def _downlink_chain(self, command: str, mcs: int,
                        n_rbs: int, x: float, y: float):
        """
        Full OFDM downlink chain for one robot.

        Returns:
            decoded_cmd (str or None)  -- decoded command; None = CRC fail
            crc_pass    (bool)
            snr_db      (float)        -- realised SNR this step
            h           (complex)      -- channel coefficient drawn
        """
        # --- Build payload: 2-bit command + 8-bit CRC ---
        cmd_bits = CMD_BITS[command]
        crc_bits = _crc8(cmd_bits)
        payload  = cmd_bits + crc_bits            # 10 bits total

        # --- Modulate ---
        symbols     = _bits_to_qam_symbols(payload, mcs)
        sc_indices  = self._get_sc_indices(n_rbs)

        # Pad symbols to fit allocated subcarriers if needed
        n_sc = len(sc_indices)
        if len(symbols) < n_sc:
            symbols = np.concatenate([symbols,
                                      np.zeros(n_sc - len(symbols),
                                               dtype=complex)])

        # --- OFDM frame ---
        tx_signal = _ofdm_modulate(symbols, sc_indices)

        # --- Channel ---
        rx_signal, h, snr_db = apply_channel(tx_signal, x, y, n_rbs)

        # --- Receive ---
        rx_symbols  = _ofdm_demodulate(rx_signal, h, sc_indices)
        rx_bits     = _qam_symbols_to_bits(rx_symbols, mcs, len(payload))

        # --- CRC check ---
        rx_cmd_bits = rx_bits[:2]
        rx_crc_bits = rx_bits[2:10]
        crc_pass    = _crc8_check(rx_cmd_bits, rx_crc_bits)

        # --- Decode command ---
        decoded_cmd = None
        if crc_pass:
            rev_map = {tuple(v): k for k, v in CMD_BITS.items()}
            decoded_cmd = rev_map.get(tuple(int(b) for b in rx_cmd_bits),
                                      None)

        return decoded_cmd, crc_pass, snr_db, h

    # ------------------------------------------------------------------
    # Stage 6 -- Actuation decision
    # ------------------------------------------------------------------

    def _actuation_decision(self, rid: str, decoded_cmd,
                             crc_pass: bool, pc_smooth: float) -> str:
        """
        Apply hysteresis, fail-safe, and deadlock-breaker logic.

        Returns actuation label (same vocabulary as CMD_*).
        """
        if crc_pass and decoded_cmd is not None:
            effective = decoded_cmd
        else:
            # Fail-safe: conservative based on P_c
            effective = CMD_STOP if pc_smooth > COLLISION_BOOST_THRESHOLD else CMD_SLOW

        # Deadlock breaker: if stopped for too many consecutive steps, nudge forward
        if effective == CMD_STOP:
            self._stop_ctr[rid] += 1
            if self._stop_ctr[rid] > MAX_STOP_STEPS:
                self._stop_ctr[rid] = 0   # reset so it can STOP again afterward
                self._hyst_cnt[rid] = 0
                effective = CMD_SLOW
        else:
            self._stop_ctr[rid] = 0

        # Hysteresis: STOP -> CONTINUE requires HYSTERESIS_COUNT clean steps
        if effective == CMD_STOP:
            self._hyst_cnt[rid] = 0
        elif effective == CMD_CONTINUE:
            self._hyst_cnt[rid] += 1
            if self._hyst_cnt[rid] < HYSTERESIS_COUNT:
                effective = CMD_SLOW   # not enough clean steps yet
        else:
            # SLOW does not reset the counter, but does not advance it either
            pass

        return effective

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def step(self, positions: dict, velocities: dict, priorities: dict) -> dict:
        """
        Run one complete downlink PHY step for both robots.

        Parameters
        ----------
        positions  : {"robot_0": (x, y), "robot_1": (x, y)}   metres
        velocities : {"robot_0": (vx, vy), "robot_1": (vx, vy)} m/s
        priorities : {"robot_0": int, "robot_1": int}           1/2/3

        Returns
        -------
        result dict with keys:
            pc_raw          float   raw collision probability [0,1]
            pc_smooth_0     float   EMA-smoothed P_c for robot 0
            pc_smooth_1     float   EMA-smoothed P_c for robot 1
            rb_0, rb_1      int     RBs allocated per robot
            mcs_0, mcs_1    int     MCS index (0=QPSK, 1=16-QAM, 2=64-QAM)
            mcs_name_0/1    str     "QPSK" / "16-QAM" / "64-QAM"
            snr_0_dB        float   realised SNR robot 0 (dB)
            snr_1_dB        float   realised SNR robot 1 (dB)
            cmd_0, cmd_1    str     command sent (before channel)
            crc_0, crc_1    int     1=pass, 0=fail
            actuation_0/1   str     final actuation applied
            h_0, h_1        complex channel coefficients (for logging)
        """
        # Validate inputs -- both robots must be present
        for rid in ("robot_0", "robot_1"):
            if rid not in positions or rid not in velocities:
                # If a robot is not yet active, return safe default
                return self._safe_default()

        # Stage 2 -- collision probability
        pc_raw, pc_smooth = self._collision_probability(positions, velocities)
        # Both robots share the same P_c (symmetric pair risk)
        pc0 = pc_smooth["robot_0"]
        pc1 = pc_smooth["robot_1"]
        # Use the higher of the two smoothed values for allocation decisions
        pc_alloc = max(pc0, pc1)

        # Stage 3 -- RB allocation
        p0  = priorities.get("robot_0", 1)
        p1  = priorities.get("robot_1", 1)
        rb_0, rb_1 = self._allocate_rbs(p0, p1, pc_alloc)

        # SNR estimate (expected, for MCS selection -- before signal build)
        x0, y0 = positions["robot_0"]
        x1, y1 = positions["robot_1"]
        snr_est_0 = estimate_snr_db(x0, y0, rb_0)
        snr_est_1 = estimate_snr_db(x1, y1, rb_1)

        mcs_0 = self._select_mcs(pc0, snr_est_0)
        mcs_1 = self._select_mcs(pc1, snr_est_1)

        # Stage 4 -- command selection (priority-aware to prevent deadlock)
        cmd_0 = self._select_command(pc0)
        cmd_1 = self._select_command(pc1)
        # If both would STOP simultaneously, give right-of-way to the higher-priority
        # robot so at least one vehicle keeps moving and clears the path.
        if cmd_0 == CMD_STOP and cmd_1 == CMD_STOP:
            if p0 >= p1:
                cmd_1 = CMD_SLOW   # robot_1 yields (lower/equal priority)
            else:
                cmd_0 = CMD_SLOW   # robot_0 yields (lower priority)

        # Stage 5 -- downlink chain
        dec_cmd_0, crc_pass_0, snr_0, h_0 = self._downlink_chain(
            cmd_0, mcs_0, rb_0, x0, y0)
        dec_cmd_1, crc_pass_1, snr_1, h_1 = self._downlink_chain(
            cmd_1, mcs_1, rb_1, x1, y1)

        # Stage 6 -- actuation with hysteresis + fail-safe
        act_0 = self._actuation_decision("robot_0", dec_cmd_0, crc_pass_0, pc0)
        act_1 = self._actuation_decision("robot_1", dec_cmd_1, crc_pass_1, pc1)

        return {
            "pc_raw":       round(pc_raw, 4),
            "pc_smooth_0":  round(pc0, 4),
            "pc_smooth_1":  round(pc1, 4),
            "rb_0":         rb_0,
            "rb_1":         rb_1,
            "mcs_0":        mcs_0,
            "mcs_1":        mcs_1,
            "mcs_name_0":   MCS_NAMES[mcs_0],
            "mcs_name_1":   MCS_NAMES[mcs_1],
            "snr_0_dB":     round(snr_0, 2),
            "snr_1_dB":     round(snr_1, 2),
            "cmd_0":        cmd_0,
            "cmd_1":        cmd_1,
            "crc_0":        int(crc_pass_0),
            "crc_1":        int(crc_pass_1),
            "actuation_0":  act_0,
            "actuation_1":  act_1,
            "h_0":          h_0,
            "h_1":          h_1,
        }

    @staticmethod
    def _safe_default() -> dict:
        """Return a safe all-zeros/CONTINUE result when robots are not active."""
        return {
            "pc_raw": 0.0, "pc_smooth_0": 0.0, "pc_smooth_1": 0.0,
            "rb_0": 26, "rb_1": 26,
            "mcs_0": MCS_QPSK, "mcs_1": MCS_QPSK,
            "mcs_name_0": "QPSK", "mcs_name_1": "QPSK",
            "snr_0_dB": 0.0, "snr_1_dB": 0.0,
            "cmd_0": CMD_CONTINUE, "cmd_1": CMD_CONTINUE,
            "crc_0": 0, "crc_1": 0,
            "actuation_0": CMD_CONTINUE, "actuation_1": CMD_CONTINUE,
            "h_0": 1+0j, "h_1": 1+0j,
        }


# ============================================================================
#  TraCI actuation helper  -- called from run_sim.py
# ============================================================================

def apply_actuation(traci, rid: str, actuation: str, step_length: float):
    """
    Apply a STOP / SLOW / CONTINUE command to a vehicle via TraCI.

    Parameters
    ----------
    traci      : the traci module (passed in to avoid circular imports)
    rid        : vehicle ID string
    actuation  : one of CMD_STOP / CMD_SLOW / CMD_CONTINUE
    step_length: simulation step length in seconds (e.g. 0.1)
    """
    try:
        active = traci.vehicle.getIDList()
        if rid not in active:
            return
        if actuation == CMD_STOP:
            traci.vehicle.setSpeed(rid, SPEED_STOP)
        elif actuation == CMD_SLOW:
            traci.vehicle.slowDown(rid, SPEED_SLOW, step_length)
        else:  # CONTINUE
            traci.vehicle.setSpeed(rid, -1)   # -1 = release speed override
    except Exception:
        # TraCI errors during actuation should not crash the sim loop
        pass
