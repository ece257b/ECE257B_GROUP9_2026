#!/usr/bin/env python3
"""
run_sim.py — Factory Warehouse Real-Time Simulation
====================================================
Opens sumo-gui and runs the warehouse simulation indefinitely.
Python reads robot coordinates in real time via TraCI at every 0.1s step.

Close the sumo-gui window to stop — robot_trajectories.csv is saved
automatically with all data collected up to that point.

Prerequisites:
    Run setup_network.py once first to generate factory.net.xml.

Usage:
    python run_sim.py
"""

import sys
import os
import random
import math
import csv
import itertools

# ── SUMO tools path ───────────────────────────────────────────────────────────
SUMO_TOOLS = "C:/Program Files (x86)/Eclipse/Sumo/tools"
sys.path.insert(0, SUMO_TOOLS)

import traci
import traci.exceptions
import sumolib

# ── PHY version selector ──────────────────────────────────────────────────────
# USE_5ROBOTS  : True  -> 5-robot PHY (phy_downlink_5r / phy_downlink_5r_rl)
#                False -> 2-robot PHY (original behaviour, unchanged)
#
# USE_MULTISYM : True  -> multi-symbol OFDM pipeline (phy_downlink_ms.py)
#                False -> legacy single-symbol / 52-RB / 1W (phy_downlink.py)
#                (only used when USE_5ROBOTS = False)
#
# USE_RL       : True  -> UCB RL allocator
#                False -> heuristic allocator
#                (applies to whichever robot-count mode is active)
USE_5ROBOTS  = True        # <-- flip to False to revert to the 2-robot case
USE_MULTISYM = True
USE_RL       = True

if USE_5ROBOTS:
    if USE_RL:
        from phy_downlink_5r_rl import (
            DownlinkPHY, apply_actuation, speed_angle_to_velocity)
        print("[PHY] 5-Robot UCB-RL allocator active (phy_downlink_5r_rl.py)")
    else:
        from phy_downlink_5r import (
            DownlinkPHY, apply_actuation, speed_angle_to_velocity)
        print("[PHY] 5-Robot heuristic allocator active (phy_downlink_5r.py)")
else:
    if not USE_MULTISYM:
        from phy_downlink import DownlinkPHY, apply_actuation, speed_angle_to_velocity
    elif USE_RL:
        from phy_downlink_ms_rl import DownlinkPHY, apply_actuation, speed_angle_to_velocity
        print("[PHY] UCB-RL allocator active (phy_downlink_ms_rl.py)")
    else:
        from phy_downlink_ms import DownlinkPHY, apply_actuation, speed_angle_to_velocity
        print("[PHY] Heuristic allocator active (phy_downlink_ms.py)")


# ══════════════════════════════════════════════════════════════════════════════
#  EDIT THIS SECTION — warehouse layout & robot configuration
# ══════════════════════════════════════════════════════════════════════════════

STEP_LENGTH = 0.1   # seconds per simulation step (must match factory.sumocfg)

# Workstation node IDs → (task name, priority level)
# Priority: 3 = high, 2 = medium, 1 = low
TASK_INFO = {
    "n_0_0": ("loading",    3),
    "n_0_2": ("loading",    3),
    "n_0_4": ("loading",    3),
    "n_2_0": ("processing", 2),
    "n_2_2": ("processing", 2),
    "n_2_4": ("processing", 2),
    "n_4_0": ("assembly",   1),
    "n_4_2": ("assembly",   1),
    "n_4_4": ("assembly",   1),
    "n_1_1": ("storage",    2),
    "n_1_3": ("storage",    2),
    "n_3_1": ("inspection", 3),
    "n_3_3": ("inspection", 3),
}

# Static (x, y) coordinates of each workstation in metres.
# Derived from the 5x5 grid: node n_r_c is at x = c*50, y = r*50.
# These never change — safe to read from anywhere in your RA code.
WORKSTATION_COORDS = {
    nid: (int(nid.split("_")[2]) * 50,   # x = col * 50
          int(nid.split("_")[1]) * 50)   # y = row * 50
    for nid in TASK_INFO
}

# Robot definitions
# 2-robot configuration (original -- unchanged)
_ROBOT_IDS_2R = ["robot_0", "robot_1"]
_ROBOT_INIT_NODE_2R = {
    "robot_0": "n_0_0",   # bottom-left corner
    "robot_1": "n_4_4",   # top-right corner
}

# 5-robot configuration -- spread across all four corners + centre
_ROBOT_IDS_5R = ["robot_0", "robot_1", "robot_2", "robot_3", "robot_4"]
_ROBOT_INIT_NODE_5R = {
    "robot_0": "n_0_0",   # (0,   0)   bottom-left
    "robot_1": "n_0_4",   # (200, 0)   bottom-right
    "robot_2": "n_2_2",   # (100, 100) centre
    "robot_3": "n_4_0",   # (0,   200) top-left
    "robot_4": "n_4_4",   # (200, 200) top-right
}

ROBOT_IDS = _ROBOT_IDS_5R if USE_5ROBOTS else _ROBOT_IDS_2R
ROBOT_INIT_NODE = _ROBOT_INIT_NODE_5R if USE_5ROBOTS else _ROBOT_INIT_NODE_2R

ROBOT_COLORS = {
    "robot_0": (255, 120,   0, 255),   # orange
    "robot_1": (  0, 120, 255, 255),   # blue
    "robot_2": (  0, 200,   0, 255),   # green
    "robot_3": (255,   0,   0, 255),   # red
    "robot_4": (180,   0, 255, 255),   # purple
}

# Output file written when sumo-gui is closed
OUTPUT_CSV = "robot_trajectories_5r.csv" if USE_5ROBOTS else "robot_trajectories.csv"

# ── CSV field definitions ──────────────────────────────────────────────────────

# 2-robot CSV schema (original -- unchanged)
_CSV_BASE_2R = [
    "time",
    "robot_0_x", "robot_0_y", "robot_0_speed",
    "robot_0_dest", "robot_0_task", "robot_0_priority",
    "robot_1_x", "robot_1_y", "robot_1_speed",
    "robot_1_dest", "robot_1_task", "robot_1_priority",
    "inter_robot_distance",
    "pc_raw", "pc_smooth_0", "pc_smooth_1",
    "rb_0", "rb_1",
    "mcs_0", "mcs_1",
    "snr_0_dB", "snr_1_dB",
    "cmd_0", "cmd_1",
    "crc_0", "crc_1",
    "actuation_0", "actuation_1",
]
_CSV_MS_EXTRA_2R = ["n_sym_0", "n_sym_1", "latency_0_us", "latency_1_us"]
_CSV_RL_EXTRA    = ["rl_state", "rl_action", "rl_reward",
                    "rl_explore", "rl_q_best", "rl_total_steps"]

# 5-robot CSV schema
_N5 = range(5)
_CSV_BASE_5R = (
    ["time"]
    + [f"robot_{i}_x"        for i in _N5]
    + [f"robot_{i}_y"        for i in _N5]
    + [f"robot_{i}_speed"    for i in _N5]
    + [f"robot_{i}_dest"     for i in _N5]
    + [f"robot_{i}_task"     for i in _N5]
    + [f"robot_{i}_priority" for i in _N5]
    + ["min_pairwise_distance", "max_pc_global", "n_high_risk_pairs"]
    + [f"pc_smooth_{i}"  for i in _N5]
    + [f"rb_{i}"         for i in _N5]
    + [f"mcs_{i}"        for i in _N5]
    + [f"snr_{i}_dB"     for i in _N5]
    + [f"cmd_{i}"        for i in _N5]
    + [f"crc_{i}"        for i in _N5]
    + [f"actuation_{i}"  for i in _N5]
    + [f"n_sym_{i}"      for i in _N5]
    + [f"latency_{i}_us" for i in _N5]
)

if USE_5ROBOTS:
    CSV_FIELDS = _CSV_BASE_5R + (_CSV_RL_EXTRA if USE_RL else [])
else:
    CSV_FIELDS = (
        _CSV_BASE_2R
        + (_CSV_MS_EXTRA_2R if USE_MULTISYM else [])
        + (_CSV_RL_EXTRA if (USE_MULTISYM and USE_RL) else [])
)

# All robot pairs (used for pairwise distance in 5-robot mode)
_ALL_PAIRS = list(itertools.combinations(ROBOT_IDS, 2))

# ══════════════════════════════════════════════════════════════════════════════
#  ROUTING  — no need to edit unless you change the network topology
# ══════════════════════════════════════════════════════════════════════════════

def find_route(net, from_node_id, to_node_id):
    """
    Return an ordered list of SUMO edge IDs for the shortest path
    from from_node to to_node. Returns None if no path exists.
    """
    if from_node_id == to_node_id:
        return None

    from_node = net.getNode(from_node_id)
    to_node   = net.getNode(to_node_id)

    start_edges = list(from_node.getOutgoing())
    end_edges   = list(to_node.getIncoming())

    if not start_edges or not end_edges:
        return None

    best_route, best_cost = None, float("inf")
    for s in start_edges:
        for e in end_edges:
            result = net.getShortestPath(s, e)
            if result is None:
                continue
            path, cost = result
            if path and cost < best_cost:
                best_route = [edge.getID() for edge in path]
                best_cost  = cost

    return best_route


def pick_next_workstation(current_node):
    """Pick a random workstation different from current_node."""
    return random.choice([ws for ws in TASK_INFO if ws != current_node])


# ══════════════════════════════════════════════════════════════════════════════
#  ROBOT STATE  — tracks per-robot metadata across steps
# ══════════════════════════════════════════════════════════════════════════════

class Robot:
    def __init__(self, rid, start_node):
        self.rid        = rid
        self.dest_node  = start_node
        self.task, self.priority = TASK_INFO[start_node]
        self._route_ctr = 0

    def assign_dest(self, node):
        self.dest_node            = node
        self.task, self.priority  = TASK_INFO[node]

    def next_route_id(self):
        rid = f"{self.rid}_r{self._route_ctr}"
        self._route_ctr += 1
        return rid


def spawn_robot(net, robot, from_node, to_node, depart="0"):
    """Compute a route and insert the robot into the live simulation."""
    edges = find_route(net, from_node, to_node)
    if not edges:
        print(f"  WARNING: no route {from_node} -> {to_node}")
        return False
    robot.assign_dest(to_node)
    route_id = robot.next_route_id()
    traci.route.add(route_id, edges)
    traci.vehicle.add(robot.rid, route_id, typeID="robot",
                      depart=depart, departPos="0", departSpeed="0")
    traci.vehicle.setColor(robot.rid, ROBOT_COLORS[robot.rid])
    return True


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN LOOP
# ══════════════════════════════════════════════════════════════════════════════

def run():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    print("Loading network...")
    net = sumolib.net.readNet("factory.net.xml")

    print("Starting sumo-gui  (close the window to stop and save CSV)...")
    traci.start(["sumo-gui", "-c", "factory.sumocfg",
                 "--collision.action", "warn",
                 "--time-to-teleport", "-1",   # disable teleportation
                 "--no-step-log"])

    # Spawn all robots with initial random destinations
    robots = {rid: Robot(rid, ROBOT_INIT_NODE[rid]) for rid in ROBOT_IDS}
    for rid, robot in robots.items():
        dest = pick_next_workstation(ROBOT_INIT_NODE[rid])
        spawn_robot(net, robot, from_node=ROBOT_INIT_NODE[rid],
                    to_node=dest, depart="0")

    phy = DownlinkPHY()

    csv_rows = []
    step     = 0

    try:
        while True:
            traci.simulationStep()
            step += 1
            t_sim = round(step * STEP_LENGTH, 1)

            # ── Re-route robots that just arrived at their destination ─────────
            for rid in traci.simulation.getArrivedIDList():
                if rid not in robots:
                    continue
                robot     = robots[rid]
                prev_dest = robot.dest_node
                new_dest  = pick_next_workstation(prev_dest)
                spawn_robot(net, robot,
                            from_node=prev_dest, to_node=new_dest,
                            depart="now")

            # ── Read real-time coordinates from live simulation ───────────────
            active     = set(traci.vehicle.getIDList())
            positions  = {}
            velocities = {}
            row        = {"time": t_sim}

            for rid in ROBOT_IDS:
                robot = robots[rid]
                if rid in active:
                    x, y    = traci.vehicle.getPosition(rid)
                    speed   = traci.vehicle.getSpeed(rid)
                    angle   = traci.vehicle.getAngle(rid)
                    vx, vy  = speed_angle_to_velocity(speed, angle)
                    positions[rid]  = (x, y)
                    velocities[rid] = (vx, vy)
                    row[f"{rid}_x"]        = round(x, 2)
                    row[f"{rid}_y"]        = round(y, 2)
                    row[f"{rid}_speed"]    = round(speed, 3)
                    row[f"{rid}_dest"]     = robot.dest_node
                    row[f"{rid}_task"]     = robot.task
                    row[f"{rid}_priority"] = robot.priority
                else:
                    for key in ("_x", "_y", "_speed", "_dest", "_task", "_priority"):
                        row[f"{rid}{key}"] = None

            # ── Distance metrics ──────────────────────────────────────────────
            if USE_5ROBOTS:
                if len(positions) == len(ROBOT_IDS):
                    min_dist = float("inf")
                    for rid_a, rid_b in _ALL_PAIRS:
                        dx = positions[rid_a][0] - positions[rid_b][0]
                        dy = positions[rid_a][1] - positions[rid_b][1]
                        min_dist = min(min_dist, math.sqrt(dx*dx + dy*dy))
                    row["min_pairwise_distance"] = round(min_dist, 2)
                else:
                    row["min_pairwise_distance"] = None
            else:
                # 2-robot case (original -- unchanged)
                if len(positions) == 2:
                    dx = positions["robot_0"][0] - positions["robot_1"][0]
                    dy = positions["robot_0"][1] - positions["robot_1"][1]
                    row["inter_robot_distance"] = round(
                        math.sqrt(dx*dx + dy*dy), 2)
                else:
                    row["inter_robot_distance"] = None

            # ── Downlink PHY pipeline ─────────────────────────────────────────
            n_expected = len(ROBOT_IDS)
            if len(positions) == n_expected:
                priorities = {rid: robots[rid].priority for rid in ROBOT_IDS}
                phy_result = phy.step(positions, velocities, priorities)

                if USE_5ROBOTS:
                    # Apply TraCI actuation to all 5 robots
                    for rid in ROBOT_IDS:
                        i = rid.split("_")[1]
                        apply_actuation(traci, rid,
                                        phy_result[f"actuation_{i}"],
                                        STEP_LENGTH)
                    # Write 5-robot PHY keys to row
                    _phy_keys_5r = (
                        ["max_pc_global", "n_high_risk_pairs"]
                        + [f"pc_smooth_{i}" for i in range(5)]
                        + [f"rb_{i}"        for i in range(5)]
                        + [f"mcs_{i}"       for i in range(5)]
                        + [f"snr_{i}_dB"    for i in range(5)]
                        + [f"cmd_{i}"       for i in range(5)]
                        + [f"crc_{i}"       for i in range(5)]
                        + [f"actuation_{i}" for i in range(5)]
                        + [f"n_sym_{i}"     for i in range(5)]
                        + [f"latency_{i}_us" for i in range(5)]
                    )
                    if USE_RL:
                        _phy_keys_5r += ["rl_state", "rl_action", "rl_reward",
                                         "rl_explore", "rl_q_best",
                                         "rl_total_steps"]
                    for key in _phy_keys_5r:
                        row[key] = phy_result[key]

                else:
                    # 2-robot case: original actuation + key logging
                    apply_actuation(traci, "robot_0",
                                    phy_result["actuation_0"], STEP_LENGTH)
                    apply_actuation(traci, "robot_1",
                                    phy_result["actuation_1"], STEP_LENGTH)
                    _phy_keys = (
                        "pc_raw", "pc_smooth_0", "pc_smooth_1",
                        "rb_0", "rb_1", "mcs_0", "mcs_1",
                        "snr_0_dB", "snr_1_dB",
                        "cmd_0", "cmd_1", "crc_0", "crc_1",
                        "actuation_0", "actuation_1",
                    )
                    if USE_MULTISYM:
                        _phy_keys += ("n_sym_0", "n_sym_1",
                                      "latency_0_us", "latency_1_us")
                    if USE_MULTISYM and USE_RL:
                        _phy_keys += ("rl_state", "rl_action", "rl_reward",
                                      "rl_explore", "rl_q_best",
                                      "rl_total_steps")
                    for key in _phy_keys:
                        row[key] = phy_result[key]

            else:
                # Not all robots active yet -- fill PHY columns with None
                if USE_5ROBOTS:
                    _nil_keys = (
                        ["max_pc_global", "n_high_risk_pairs"]
                        + [f"pc_smooth_{i}" for i in range(5)]
                        + [f"rb_{i}"        for i in range(5)]
                        + [f"mcs_{i}"       for i in range(5)]
                        + [f"snr_{i}_dB"    for i in range(5)]
                        + [f"cmd_{i}"       for i in range(5)]
                        + [f"crc_{i}"       for i in range(5)]
                        + [f"actuation_{i}" for i in range(5)]
                        + [f"n_sym_{i}"     for i in range(5)]
                        + [f"latency_{i}_us" for i in range(5)]
                    )
                    if USE_RL:
                        _nil_keys += ["rl_state", "rl_action", "rl_reward",
                                      "rl_explore", "rl_q_best",
                                      "rl_total_steps"]
                else:
                    _nil_keys = (
                        "pc_raw", "pc_smooth_0", "pc_smooth_1",
                        "rb_0", "rb_1", "mcs_0", "mcs_1",
                        "snr_0_dB", "snr_1_dB",
                        "cmd_0", "cmd_1", "crc_0", "crc_1",
                        "actuation_0", "actuation_1",
                    )
                    if USE_MULTISYM:
                        _nil_keys += ("n_sym_0", "n_sym_1",
                                      "latency_0_us", "latency_1_us")
                    if USE_MULTISYM and USE_RL:
                        _nil_keys += ("rl_state", "rl_action", "rl_reward",
                                      "rl_explore", "rl_q_best",
                                      "rl_total_steps")
                for key in _nil_keys:
                    row[key] = None

            csv_rows.append(row)

    except (traci.exceptions.FatalTraCIError, ConnectionResetError):
        # User closed the sumo-gui window
        print(f"\nsumo-gui closed at t = {step * STEP_LENGTH:.1f} s  "
              f"({step:,} steps collected).")

    finally:
        try:
            traci.close()
        except Exception:
            pass

        if csv_rows:
            with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=CSV_FIELDS,
                                        extrasaction="ignore")
                writer.writeheader()
                writer.writerows(csv_rows)
            print(f"Saved {len(csv_rows):,} rows -> {OUTPUT_CSV}")
        else:
            print("No data collected — CSV not written.")


if __name__ == "__main__":
    run()
