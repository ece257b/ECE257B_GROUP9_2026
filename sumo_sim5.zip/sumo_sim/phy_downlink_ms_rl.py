"""
phy_downlink_ms_rl.py  --  UCB Reinforcement Learning RB Allocator
===================================================================
Drop-in replacement for phy_downlink_ms.py that swaps the static
priority-heuristic RB allocator for a UCB-1 contextual bandit that
learns the allocation policy entirely from the reward signal.

Only Stage 3a (RB allocation) is changed.  All other pipeline stages
(collision probability, MCS, command heuristics, OFDM chain, actuation)
are inherited unchanged from phy_downlink_ms.DownlinkPHY.

UCB State  : (pc_bin, priority_pair_idx, snr_bin)  --  108 states
UCB Actions: rb_0 in {1, 2, 3, 4, 5, 6}            --  6 actions
             rb_1 = TOTAL_RBS - rb_0  (always >= 1)

Reward = weighted sum of five components:
  R_safety   (0.35) -- penalise high Pc, CRC failures at high risk
  R_priority (0.25) -- penalise deviation from priority-proportional RB split
  R_spectral (0.20) -- reward high spectral efficiency
  R_channel  (0.12) -- reward CRC pass rate and appropriate MCS
  R_latency  (0.08) -- reward higher-priority robot having lower latency

Failsafe: if UCB selects an action that would give either robot 0 RBs
(impossible with ACTIONS = {1..6} and TOTAL_RBS=7, but checked anyway),
the heuristic allocation from phy_downlink_ms is used instead.

Extra result keys added to the step() dict (logged to CSV when USE_RL=True):
  rl_state        -- discretised state as a string "(pc_bin, pp_idx, snr_bin)"
  rl_action       -- rb_0 chosen by UCB
  rl_reward       -- reward signal computed this step
  rl_explore      -- 1 if this was a pure-exploration step, 0 if exploitation
  rl_q_best       -- best Q-value seen for this state so far
  rl_total_steps  -- cumulative steps seen by the UCB agent
"""

import math
import numpy as np

from phy_downlink_ms import (
    DownlinkPHY as _BaseDownlinkPHY,
    apply_actuation,           # re-exported for run_sim.py import
    speed_angle_to_velocity,   # re-exported for run_sim.py import
    TOTAL_RBS,
    COLLISION_BOOST_THRESHOLD,
    MCS_QPSK, MCS_16QAM, MCS_64QAM, MCS_NAMES,
    CMD_STOP, CMD_SLOW,
    P_STOP,
    T_SYM_US,
    TX_POWER_W,
    MAX_STOP_STEPS,
)

# Failsafe: fall back to the heuristic allocator for degenerate UCB outputs
_heuristic_allocate_rbs = _BaseDownlinkPHY._allocate_rbs
from channel_model import estimate_snr_db


# ============================================================================
#  UCB hyper-parameters
# ============================================================================

UCB_C     = 1.5                          # exploration width constant
ACTIONS   = list(range(1, TOTAL_RBS))    # rb_0 in {1, 2, 3, 4, 5, 6}
N_ACTIONS = len(ACTIONS)                 # 6


# ============================================================================
#  Reward weights  (must sum to 1.0)
# ============================================================================

W_SAFETY   = 0.35
W_PRIORITY = 0.25
W_SPECTRAL = 0.20
W_CHANNEL  = 0.12
W_LATENCY  = 0.08

MCS_BPS = {MCS_QPSK: 2, MCS_16QAM: 4, MCS_64QAM: 6}

# Maximum achievable spectral efficiency (bits/step, unnormalised)
# = highest MCS * most RBs one robot can get * 12 SC/RB
SE_MAX = 6 * (TOTAL_RBS - 1) * 12   # 6 bps * 6 RBs * 12 SC = 432

SNR_THRESH_LOW  = 15.0
SNR_THRESH_HIGH = 20.0

# RBs used to estimate SNR for state encoding (neutral, action-independent)
_STATE_SNR_RBS = max(1, TOTAL_RBS // 2)   # 3


# ============================================================================
#  State discretisation
# ============================================================================

def _pc_bin(pc: float) -> int:
    """4 bins aligned to the MCS and command thresholds."""
    if pc < 0.30:  return 0   # safe / CONTINUE
    if pc < 0.50:  return 1   # 16-QAM zone / SLOW
    if pc < 0.65:  return 2   # collision boost / approaching STOP
    return 3                   # STOP zone


def _priority_pair_idx(p0: int, p1: int) -> int:
    """Map (p0, p1) in {1,2,3}^2 to a unique index 0..8."""
    return (p0 - 1) * 3 + (p1 - 1)


def _snr_bin(snr_db: float) -> int:
    if snr_db < SNR_THRESH_LOW:   return 0   # poor -- QPSK territory
    if snr_db < SNR_THRESH_HIGH:  return 1   # moderate -- 16-QAM
    return 2                                   # good -- 64-QAM


def make_state(pc: float, p0: int, p1: int, snr_db: float) -> tuple:
    """Build the UCB state tuple from raw inputs."""
    return (_pc_bin(pc), _priority_pair_idx(p0, p1), _snr_bin(snr_db))


# ============================================================================
#  UCBAllocator  --  contextual UCB-1 bandit
# ============================================================================

class UCBAllocator:
    """
    Contextual UCB-1 bandit for RB allocation.

    State : tuple (pc_bin, priority_pair_idx, snr_bin)
    Action: rb_0 index -> ACTIONS[idx] = rb_0 value

    At the start every (state, action) pair is unvisited.  UCB visits
    each action once per state before switching to exploitation, giving
    a clean exploration phase that does not require tuning an epsilon
    decay schedule.
    """

    def __init__(self, c: float = UCB_C):
        self.c = c
        self._Q: dict = {}     # Q[state][action_idx]  running mean reward
        self._N: dict = {}     # N[state][action_idx]  visit count
        self._total = 0        # total steps processed

    # ------------------------------------------------------------------
    def _ensure(self, s: tuple):
        if s not in self._Q:
            self._Q[s] = [0.0] * N_ACTIONS
            self._N[s] = [0]   * N_ACTIONS

    # ------------------------------------------------------------------
    def select(self, state: tuple) -> tuple:
        """
        UCB-1 action selection.

        Returns
        -------
        rb_0       : int   -- number of RBs to assign to robot_0
        action_idx : int   -- index into ACTIONS (for the update call)
        is_explore : bool  -- True if selected purely due to zero visit count
        """
        self._ensure(state)
        n_total = sum(self._N[state])

        # Unvisited actions -- explore deterministically (no random tie-breaking
        # needed; first unvisited gives reproducible warm-up behaviour)
        unvisited = [i for i, n in enumerate(self._N[state]) if n == 0]
        if unvisited:
            idx = unvisited[0]
            return ACTIONS[idx], idx, True

        # Exploitation via UCB scores
        ucb = [
            self._Q[state][i] + self.c * math.sqrt(
                math.log(n_total + 1) / (self._N[state][i] + 1)
            )
            for i in range(N_ACTIONS)
        ]
        idx = int(np.argmax(ucb))
        return ACTIONS[idx], idx, False

    # ------------------------------------------------------------------
    def update(self, state: tuple, action_idx: int, reward: float):
        """Incremental mean update (equivalent to a decaying learning rate)."""
        self._ensure(state)
        self._N[state][action_idx] += 1
        n = self._N[state][action_idx]
        self._Q[state][action_idx] += (reward - self._Q[state][action_idx]) / n
        self._total += 1

    # ------------------------------------------------------------------
    @property
    def total_steps(self) -> int:
        return self._total

    def best_q(self, state: tuple) -> float:
        self._ensure(state)
        return max(self._Q[state])

    def q_table_summary(self) -> dict:
        """Best Q-value per visited state -- useful for convergence plots."""
        return {s: max(self._Q[s]) for s in self._Q}


# ============================================================================
#  Reward computation
# ============================================================================

def _compute_reward(
    pc:         float,
    p0:         int,   p1:     int,
    rb_0:       int,   rb_1:   int,
    mcs_0:      int,   mcs_1:  int,
    crc_0:      bool,  crc_1:  bool,
    snr_0:      float, snr_1:  float,
    lat_0:      float, lat_1:  float,
    stop_ctr_0: int,   stop_ctr_1: int,
) -> float:
    """
    Five-component weighted reward.  All components are in [-3, 1]
    before weighting; the combined reward lives roughly in [-1.5, 1].
    """

    # ---- R_safety -------------------------------------------------------
    # Base: continuous reward for low collision probability
    r_safety = 1.0 - pc
    # Hard penalty: in STOP zone a collision is imminent
    if pc >= P_STOP:
        r_safety -= 3.0
    # Extra penalty: safety-critical packet lost while risk is high
    if pc > COLLISION_BOOST_THRESHOLD and (not crc_0 or not crc_1):
        r_safety -= 1.5

    # ---- R_priority ------------------------------------------------------
    # How close is the RB split to the priority-proportional ideal?
    denom          = (p0 + p1) if (p0 + p1) > 0 else 1
    priority_ratio = p0 / denom          # ideal fraction for robot_0
    rb_ratio       = rb_0 / TOTAL_RBS   # actual fraction for robot_0
    r_priority     = -abs(rb_ratio - priority_ratio)

    # Directional latency bonus/penalty: higher priority -> lower latency
    if p0 > p1:
        r_priority += 0.5 if lat_0 < lat_1 else -0.5
    elif p1 > p0:
        r_priority += 0.5 if lat_1 < lat_0 else -0.5

    # ---- R_spectral ------------------------------------------------------
    # Spectral efficiency = bits carried per step (proportional to MCS * SCs)
    se_0 = MCS_BPS[mcs_0] * rb_0 * 12
    se_1 = MCS_BPS[mcs_1] * rb_1 * 12
    r_spectral = (se_0 + se_1) / SE_MAX   # normalised 0..1

    # Starvation penalty: giving a robot only 1 RB when the channel is safe
    # wastes the spectrum and provides no safety benefit
    if rb_0 <= 1 and pc < 0.30:
        r_spectral -= 0.5

    # ---- R_channel -------------------------------------------------------
    # Reward clean decodes
    r_channel = 0.5 * int(crc_0) + 0.5 * int(crc_1)

    avg_snr = (snr_0 + snr_1) / 2.0

    # Bonus for using 64-QAM when the channel quality supports it
    if (avg_snr >= SNR_THRESH_HIGH
            and mcs_0 == MCS_64QAM and mcs_1 == MCS_64QAM):
        r_channel += 0.3

    # Penalty for falling back to QPSK unnecessarily (not in collision zone)
    if pc < 0.30 and (mcs_0 == MCS_QPSK or mcs_1 == MCS_QPSK):
        r_channel -= 0.3

    # ---- R_latency -------------------------------------------------------
    # Penalise prolonged deadlock (both robots stopped too long)
    deadlock_ratio = (stop_ctr_0 + stop_ctr_1) / (2.0 * MAX_STOP_STEPS)
    r_latency = -min(deadlock_ratio, 1.0)   # capped at -1

    # ---- Weighted sum ----------------------------------------------------
    return (W_SAFETY   * r_safety
          + W_PRIORITY * r_priority
          + W_SPECTRAL * r_spectral
          + W_CHANNEL  * r_channel
          + W_LATENCY  * r_latency)


# ============================================================================
#  DownlinkPHY  --  RL version
# ============================================================================

class DownlinkPHY(_BaseDownlinkPHY):
    """
    Extends phy_downlink_ms.DownlinkPHY by replacing the static
    _allocate_rbs() heuristic with a UCB contextual bandit.

    Only step() is overridden; every other method (collision probability,
    MCS selection, command selection, OFDM chain, actuation decision)
    runs unchanged from the parent class.

    Failsafe: if the UCB returns an allocation that would leave either
    robot with 0 RBs, the heuristic allocation is used for that step
    and the rl_explore flag is set to -1 in the result.
    """

    def __init__(self):
        super().__init__()
        self.ucb = UCBAllocator(c=UCB_C)

    # ------------------------------------------------------------------
    def step(self, positions: dict, velocities: dict, priorities: dict) -> dict:
        for rid in ("robot_0", "robot_1"):
            if rid not in positions or rid not in velocities:
                return self._safe_default()

        # ---- Stage 2: collision probability (inherited) ----------------
        pc_raw, pc_smooth_dict = self._collision_probability(positions, velocities)
        pc0 = pc_smooth_dict["robot_0"]
        pc1 = pc_smooth_dict["robot_1"]
        pc_alloc = max(pc0, pc1)

        x0, y0 = positions["robot_0"]
        x1, y1 = positions["robot_1"]
        p0 = priorities.get("robot_0", 1)
        p1 = priorities.get("robot_1", 1)

        # SNR estimate for state encoding (neutral RB count, action-independent)
        snr_state_0 = estimate_snr_db(x0, y0, _STATE_SNR_RBS, TX_POWER_W)
        snr_state_1 = estimate_snr_db(x1, y1, _STATE_SNR_RBS, TX_POWER_W)
        avg_snr_state = (snr_state_0 + snr_state_1) / 2.0

        # ---- Stage 3a: UCB selects RB allocation -----------------------
        state = make_state(pc_alloc, p0, p1, avg_snr_state)
        rb_0, action_idx, is_explore = self.ucb.select(state)
        rb_1 = TOTAL_RBS - rb_0

        # Failsafe: reject degenerate allocations
        failsafe_used = False
        if rb_0 <= 0 or rb_1 <= 0:
            rb_0, rb_1 = _heuristic_allocate_rbs(p0, p1, pc_alloc)
            action_idx  = ACTIONS.index(rb_0) if rb_0 in ACTIONS else 0
            failsafe_used = True

        # ---- Stage 3b: MCS selection (uses actual allocated RBs) -------
        snr_est_0 = estimate_snr_db(x0, y0, rb_0, TX_POWER_W)
        snr_est_1 = estimate_snr_db(x1, y1, rb_1, TX_POWER_W)
        mcs_0 = self._select_mcs(pc0, snr_est_0)
        mcs_1 = self._select_mcs(pc1, snr_est_1)

        # ---- Stage 4: command selection (inherited) --------------------
        cmd_0 = self._select_command(pc0)
        cmd_1 = self._select_command(pc1)
        if cmd_0 == CMD_STOP and cmd_1 == CMD_STOP:
            if p0 >= p1:  cmd_1 = CMD_SLOW
            else:          cmd_0 = CMD_SLOW

        # ---- Stage 5: multi-symbol OFDM chain (inherited) --------------
        dec_cmd_0, crc_0, snr_0, n_sym_0, lat_0, h_0 = self._downlink_chain(
            cmd_0, mcs_0, rb_0, x0, y0)
        dec_cmd_1, crc_1, snr_1, n_sym_1, lat_1, h_1 = self._downlink_chain(
            cmd_1, mcs_1, rb_1, x1, y1)

        # ---- Stage 5b: compute reward and update UCB -------------------
        reward = _compute_reward(
            pc=pc_alloc,
            p0=p0,    p1=p1,
            rb_0=rb_0, rb_1=rb_1,
            mcs_0=mcs_0, mcs_1=mcs_1,
            crc_0=crc_0,  crc_1=crc_1,
            snr_0=snr_0,  snr_1=snr_1,
            lat_0=lat_0,  lat_1=lat_1,
            stop_ctr_0=self._stop_ctr["robot_0"],
            stop_ctr_1=self._stop_ctr["robot_1"],
        )
        if not failsafe_used:
            self.ucb.update(state, action_idx, reward)

        # ---- Stage 6: actuation decision (inherited) -------------------
        act_0 = self._actuation_decision("robot_0", dec_cmd_0, crc_0, pc0)
        act_1 = self._actuation_decision("robot_1", dec_cmd_1, crc_1, pc1)

        return {
            # -- Standard keys (identical to phy_downlink_ms output) --
            "pc_raw":         round(pc_raw, 4),
            "pc_smooth_0":    round(pc0, 4),
            "pc_smooth_1":    round(pc1, 4),
            "rb_0":           rb_0,
            "rb_1":           rb_1,
            "mcs_0":          mcs_0,
            "mcs_1":          mcs_1,
            "mcs_name_0":     MCS_NAMES[mcs_0],
            "mcs_name_1":     MCS_NAMES[mcs_1],
            "snr_0_dB":       round(snr_0, 2),
            "snr_1_dB":       round(snr_1, 2),
            "cmd_0":          cmd_0,
            "cmd_1":          cmd_1,
            "crc_0":          int(crc_0),
            "crc_1":          int(crc_1),
            "actuation_0":    act_0,
            "actuation_1":    act_1,
            "h_0":            h_0,
            "h_1":            h_1,
            "n_sym_0":        n_sym_0,
            "n_sym_1":        n_sym_1,
            "latency_0_us":   round(lat_0, 2),
            "latency_1_us":   round(lat_1, 2),
            # -- RL diagnostic keys --
            "rl_state":       str(state),
            "rl_action":      rb_0,
            "rl_reward":      round(reward, 4),
            "rl_explore":     -1 if failsafe_used else int(is_explore),
            "rl_q_best":      round(self.ucb.best_q(state), 4),
            "rl_total_steps": self.ucb.total_steps,
        }

    # ------------------------------------------------------------------
    def _safe_default(self) -> dict:
        base = super()._safe_default()
        base.update({
            "rl_state":       "(-,-,-)",
            "rl_action":      TOTAL_RBS // 2,
            "rl_reward":      0.0,
            "rl_explore":     -1,
            "rl_q_best":      0.0,
            "rl_total_steps": self.ucb.total_steps,
        })
        return base
